import { describe, it, expect } from "vitest";
import type { Language, LocaleStrings, SettingsSnapshot, WidgetTheme } from "./bridge";
import backendBridgeSource from "../../src-tauri/src/commands/bridge.rs?raw";
import backendSettingsSource from "../../src-tauri/src/commands/settings.rs?raw";
import backendFloatBarWindowSource from "../../src-tauri/src/floatbar/window.rs?raw";
import backendFloatBarCommandsSource from "../../src-tauri/src/floatbar/commands.rs?raw";
import backendMainSource from "../../src-tauri/src/main.rs?raw";
import backendFullscreenMonitorSource from "../../src-tauri/src/fullscreen_monitor.rs?raw";
import {
  FLOAT_BAR_CONFIG_CHANGED_EVENT,
  USAGE_WIDGET_COLLAPSED_EVENT,
  USAGE_WIDGET_EXPANDED_EVENT,
  WIDGET_VISUAL_UPDATES_RESUMED_EVENT,
  WIDGET_VISUAL_UPDATES_SUSPENDED_EVENT,
} from "../floatbar/api";

describe("Language type", () => {
  it("accepts supported locale labels as valid union members", () => {
    // Type-level assertion: this assignment must compile (tsc --noEmit gate).
    // Vitest strips types at transform time, so the runtime assertion only
    // exercises value correctness; tsc provides the RED/GREEN gate.
    const lang: Language = "spanish";
    expect(lang).toBe("spanish");
    const langKo: Language = "korean";
    expect(langKo).toBe("korean");
    const langZhTw: Language = "chinesetraditional";
    expect(langZhTw).toBe("chinesetraditional");
  });

  it("allows 'spanish' in LocaleStrings payload", () => {
    const payload: LocaleStrings = {
      language: "spanish",
      entries: { TabGeneral: "General" },
    };
    expect(payload.language).toBe("spanish");
    expect(payload.entries.TabGeneral).toBe("General");

    const payloadKo: LocaleStrings = {
      language: "korean",
      entries: { TabGeneral: "일반" },
    };
    expect(payloadKo.language).toBe("korean");
    expect(payloadKo.entries.TabGeneral).toBe("일반");

    const payloadZhTw: LocaleStrings = {
      language: "chinesetraditional",
      entries: { TabGeneral: "一般" },
    };
    expect(payloadZhTw.language).toBe("chinesetraditional");
    expect(payloadZhTw.entries.TabGeneral).toBe("一般");
  });

  it("allows 'spanish' in SettingsSnapshot.uiLanguage", () => {
    const snap: SettingsSnapshot = {
      enabledProviders: [],
      refreshIntervalSecs: 300,
      refreshAllProvidersOnMenuOpen: false,
      startAtLogin: false,
      startMinimized: false,
      showNotifications: true,
      soundEnabled: true,
      soundVolume: 100,
      highUsageThreshold: 70,
      criticalUsageThreshold: 90,
      predictivePaceWarningEnabled: false,
      trayIconMode: "single",
      switcherShowsIcons: true,
      menuBarShowsHighestUsage: true,
      menuBarShowsPercent: true,
      showAsUsed: false,
      showAllTokenAccountsInMenu: true,
      enableAnimations: true,
      resetTimeRelative: true,
      showResetWhenExhausted: false,
      menuBarDisplayMode: "compact",
      windowScalePercent: 125,
      trayScalePercent: 100,
      powertoysStatusPipeEnabled: false,
      hidePersonalInfo: false,
      autoDownloadUpdates: false,
      installUpdatesOnQuit: false,
      globalShortcut: "",
      codexCustomSessionsDirs: [],
      updateChannel: "stable",
      uiLanguage: "spanish",
      widgetTheme: "emerald",
      widgetPinned: false,
      widgetSmartTopmost: true,
      widgetHideFullscreen: true,
      theme: "dark",
      claudeAvoidKeychainPrompts: true,
      codexSparkUsageVisible: true,
      disableKeychainAccess: false,
      providerMetrics: {},
      floatBarEnabled: false,
      floatBarOpacity: 0.9,
      floatBarScale: 100,
      floatBarOrientation: "horizontal",
      floatBarStyle: "floating",
      floatBarClickThrough: false,
      floatBarProviderIds: [],
      floatBarDarkText: false,
      floatBarShowResetInline: false,
      floatBarShowCost: false,
    };
    const widgetTheme: WidgetTheme = snap.widgetTheme;
    expect(widgetTheme).toBe("emerald");
    expect(snap.widgetPinned).toBe(false);
    expect(snap.widgetSmartTopmost).toBe(true);
    expect(snap.widgetHideFullscreen).toBe(true);
    expect(snap.uiLanguage).toBe("spanish");

    const snapKo: SettingsSnapshot = {
      ...snap,
      uiLanguage: "korean",
    };
    expect(snapKo.uiLanguage).toBe("korean");

    const snapZhTw: SettingsSnapshot = {
      ...snap,
      uiLanguage: "chinesetraditional",
    };
    expect(snapZhTw.uiLanguage).toBe("chinesetraditional");
  });
});

describe("widget settings backend bridge contract", () => {
  it("shares the float-bar configuration event name with Rust", () => {
    const backendEvent = backendFloatBarWindowSource.match(
      /FLOAT_BAR_CONFIG_CHANGED_EVENT:\s*&str\s*=\s*"([^"]+)"/,
    );

    expect(backendEvent?.[1]).toBe(FLOAT_BAR_CONFIG_CHANGED_EVENT);
  });

  it.each([
    ["widget_theme", "settings.widget_theme"],
    ["widget_pinned", "settings.widget_pinned"],
  ] as const)("serializes and snapshots %s", (field, settingsField) => {
    expect(backendBridgeSource).toMatch(
      new RegExp(`${field}:\\s*codexbar::settings::WidgetTheme|${field}:\\s*bool`),
    );
    expect(backendBridgeSource).toContain(`${field}: ${settingsField}`);
  });

  it.each(["widget_theme", "widget_pinned"] as const)(
    "routes %s through the float-bar notification and settings patch",
    (field) => {
      expect(backendSettingsSource).toContain(`|| self.${field}.is_some()`);
      expect(backendSettingsSource).toMatch(
        new RegExp(`${field}:\\s*self\\.${field}`),
      );
    },
  );
});

describe("native usage widget command contract", () => {
  it.each([
    "expand_usage_widget",
    "collapse_usage_widget",
    "set_usage_widget_pinned",
    "begin_usage_widget_drag",
    "end_usage_widget_drag",
  ])("defines and registers %s", (command) => {
    expect(backendFloatBarCommandsSource).toMatch(
      new RegExp(`pub (?:async )?fn ${command}\\b`),
    );
    expect(backendMainSource).toContain(`floatbar::${command},`);
  });

  it("owns the exact collapsed and expanded logical sizes natively", () => {
    expect(backendFloatBarCommandsSource).toContain(
      "USAGE_WIDGET_MINI_WIDTH: f64 = 395.0",
    );
    expect(backendFloatBarCommandsSource).toContain(
      "USAGE_WIDGET_MINI_HEIGHT: f64 = 82.0",
    );
    expect(backendFloatBarCommandsSource).toContain(
      "USAGE_WIDGET_EXPANDED_WIDTH: f64 = 420.0",
    );
    expect(backendFloatBarCommandsSource).toContain(
      "USAGE_WIDGET_EXPANDED_HEIGHT: f64 = 520.0",
    );
  });

  it("activates the interactive widget and reserves no-activate for click-through", () => {
    expect(backendFloatBarWindowSource).toContain(
      "fn interaction_extended_style(ex_style: isize, click_through: bool) -> isize",
    );
    expect(backendFloatBarWindowSource).toContain(
      "interaction_extended_style(0, false), WS_EX_LAYERED",
    );
    expect(backendFloatBarWindowSource).toContain(
      "WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE",
    );
    expect(backendFloatBarWindowSource).not.toContain("apply_no_activate(");
  });

  it.each([
    ["USAGE_WIDGET_EXPANDED_EVENT", USAGE_WIDGET_EXPANDED_EVENT],
    ["USAGE_WIDGET_COLLAPSED_EVENT", USAGE_WIDGET_COLLAPSED_EVENT],
    [
      "WIDGET_VISUAL_UPDATES_SUSPENDED_EVENT",
      WIDGET_VISUAL_UPDATES_SUSPENDED_EVENT,
    ],
    ["WIDGET_VISUAL_UPDATES_RESUMED_EVENT", WIDGET_VISUAL_UPDATES_RESUMED_EVENT],
  ] as const)("shares the %s event name with Rust", (constant, eventName) => {
    const backendEvent = backendFloatBarCommandsSource.match(
      new RegExp(`${constant}:\\s*&str\\s*=\\s*\\n?\\s*"([^"]+)"`),
    );
    expect(backendEvent?.[1]).toBe(eventName);
  });
});

describe("native fullscreen monitor contract", () => {
  it("installs a 500ms state-driven monitor", () => {
    expect(backendMainSource).toContain("fullscreen_monitor::install(app.handle())");
    expect(backendFullscreenMonitorSource).toContain(
      "Duration::from_millis(500)",
    );
    expect(backendFullscreenMonitorSource).toContain("policy.desired(observation)");
    expect(backendFullscreenMonitorSource).toContain("policy.acknowledge(directive)");
    expect(backendFullscreenMonitorSource).toContain("run_on_main_thread");
  });

  it("consumes widget settings without starting provider refresh work", () => {
    expect(backendFullscreenMonitorSource).toContain(
      "settings.widget_hide_fullscreen",
    );
    expect(backendFullscreenMonitorSource).toContain(
      "settings.widget_smart_topmost",
    );
    expect(backendFullscreenMonitorSource).not.toContain("refresh_provider");
    expect(backendFullscreenMonitorSource).not.toContain("get_cached_providers");
  });

  it("excludes app-owned and Windows shell foreground windows", () => {
    expect(backendFullscreenMonitorSource).toContain(
      "process_id == std::process::id()",
    );
    expect(backendFullscreenMonitorSource).toContain('"Progman"');
    expect(backendFullscreenMonitorSource).toContain('"WorkerW"');
    expect(backendFullscreenMonitorSource).toContain('"Shell_TrayWnd"');
  });

  it("restores the widget without taking focus", () => {
    expect(backendFullscreenMonitorSource).toContain("SW_SHOWNOACTIVATE");
    expect(backendFullscreenMonitorSource).toContain("window.is_visible()");
    expect(backendFullscreenMonitorSource).not.toContain("set_focus");
  });

  it("restores from an exact physical monitor snapshot", () => {
    expect(backendFloatBarWindowSource).toContain(
      "struct FullscreenRestoreGeometry",
    );
    expect(backendFloatBarWindowSource).toContain(
      "monitor.position == saved.monitor_position",
    );
    expect(backendFloatBarWindowSource).toContain(
      "clamp_physical_position_to_work_area",
    );
  });
});
