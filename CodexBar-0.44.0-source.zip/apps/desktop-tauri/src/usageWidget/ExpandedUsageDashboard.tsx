import type { CSSProperties } from "react";
import { useFormattedResetTime } from "../hooks/useFormattedResetTime";
import { useLocale } from "../i18n/LocaleProvider";
import type { LocaleKey } from "../i18n/keys";
import { localeForLanguage } from "../i18n/languageLocale";
import type { Language, PaceSnapshot, WidgetTheme } from "../types/bridge";
import type { CodexWidgetModel, QuotaView } from "./model";
import "./usageWidget.css";

export type ExpandedUsageDashboardProps = {
  model: CodexWidgetModel;
  pinned: boolean;
  theme?: WidgetTheme;
  onPinChange: (pinned: boolean) => void;
  onRefresh: () => void;
  onCollapse: () => void;
  onOpenSettings: () => void;
};

const PACE_STAGE_KEYS: Record<PaceSnapshot["stage"], LocaleKey> = {
  on_track: "DetailPaceOnTrack",
  slightly_ahead: "DetailPaceSlightlyAhead",
  ahead: "DetailPaceAhead",
  far_ahead: "DetailPaceFarAhead",
  slightly_behind: "DetailPaceSlightlyBehind",
  behind: "DetailPaceBehind",
  far_behind: "DetailPaceFarBehind",
};

function statusText(model: CodexWidgetModel, t: ReturnType<typeof useLocale>["t"]) {
  switch (model.status) {
    case "stale":
      return t("WidgetRefreshFailed");
    case "signedOut":
      return t("WidgetLoginRequired");
    case "empty":
      return t("WidgetQuotaUnavailable");
    case "fresh":
      return t("WidgetSyncedJustNow");
  }
}

function QuotaCard({ label, quota }: { label: string; quota: QuotaView | null }) {
  const { t } = useLocale();
  const remaining = quota?.remainingPercent ?? null;
  const used = quota?.usedPercent ?? null;
  const resetDescription = useFormattedResetTime(
    quota?.resetsAt ?? null,
    quota?.resetDescription ?? null,
    true,
  );

  return (
    <article className="usage-dashboard__quota">
      <div className="usage-dashboard__quota-header">
        <strong>{label}</strong>
        <span>{t("WidgetRemaining")}</span>
      </div>
      {remaining == null || used == null ? (
        <p className="usage-dashboard__empty">{t("WidgetQuotaUnavailable")}</p>
      ) : (
        <>
          <div className="usage-dashboard__quota-value">
            <strong>{Math.round(remaining)}%</strong>
            <span>{`${Math.round(used)}% ${t("WidgetUsed")}`}</span>
          </div>
          <div
            className="usage-dashboard__track"
            role="progressbar"
            aria-label={`${label} ${t("WidgetRemaining")}`}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(remaining)}
          >
            <span style={{ "--usage-progress": remaining } as CSSProperties} />
          </div>
          <p className="usage-dashboard__reset">
            {resetDescription ?? t("WidgetQuotaUnavailable")}
          </p>
        </>
      )}
    </article>
  );
}

export function formatUpdatedAt(
  updatedAt: string | null,
  language: Language,
): string {
  if (!updatedAt) return "--";
  const date = new Date(updatedAt);
  if (Number.isNaN(date.getTime())) return updatedAt;
  return new Intl.DateTimeFormat(localeForLanguage(language), {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function ExpandedUsageDashboard({
  model,
  pinned,
  theme = "emerald",
  onPinChange,
  onRefresh,
  onCollapse,
  onOpenSettings,
}: ExpandedUsageDashboardProps) {
  const { t, language } = useLocale();
  const pace = model.pace;
  const paceLabel = pace
    ? t(PACE_STAGE_KEYS[pace.stage])
    : t("WidgetQuotaUnavailable");

  return (
    <section
      className={`usage-dashboard usage-dashboard--${model.tone}`}
      data-widget-theme={theme}
    >
      <header className="usage-dashboard__header">
        <div className="usage-dashboard__identity">
          <span className="usage-dashboard__logo" aria-hidden>C</span>
          <div>
            <h1>{t("WidgetTitle")}</h1>
            {model.planName && <span>{model.planName}</span>}
          </div>
        </div>
        <div className="usage-dashboard__actions">
          <button
            type="button"
            className="usage-dashboard__action"
            aria-label={t("ActionRefresh")}
            onClick={onRefresh}
          >
            <span aria-hidden>↻</span>
          </button>
          <button
            type="button"
            className={`usage-dashboard__action${pinned ? " usage-dashboard__action--active" : ""}`}
            aria-label={pinned ? t("WidgetUnpin") : t("WidgetPin")}
            aria-pressed={pinned}
            onClick={() => onPinChange(!pinned)}
          >
            <span aria-hidden>◆</span>
          </button>
          <button
            type="button"
            className="usage-dashboard__action"
            aria-label={t("ActionClose")}
            onClick={onCollapse}
          >
            <span aria-hidden>−</span>
          </button>
        </div>
      </header>

      <div className="usage-dashboard__meta">
        <div>
          <span>{t("Plan")}</span>
          <strong>{model.planName ?? "--"}</strong>
        </div>
        <div>
          <span>{t("Updated")}</span>
          <time dateTime={model.updatedAt ?? undefined}>
            {formatUpdatedAt(model.updatedAt, language)}
          </time>
        </div>
        <div>
          <span>{t("Status")}</span>
          <strong>{statusText(model, t)}</strong>
        </div>
      </div>

      <main className="usage-dashboard__content">
        <QuotaCard label={t("ProviderSession")} quota={model.session} />
        <QuotaCard label={t("ProviderWeekly")} quota={model.weekly} />

        <section className="usage-dashboard__pace">
          <div>
            <span>{t("Status")}</span>
            <strong>{paceLabel}</strong>
          </div>
          {pace ? (
            <div className="usage-dashboard__pace-metrics">
              <strong>{`${Math.round(Math.abs(pace.deltaPercent))}%`}</strong>
              <span>{`${Math.round(pace.actualUsedPercent)}% ${t("WidgetUsed")}`}</span>
            </div>
          ) : (
            <span className="usage-dashboard__empty" aria-hidden>--</span>
          )}
        </section>
      </main>

      <footer className="usage-dashboard__footer">
        <span>{t("PrivacyTitle")}</span>
        <button type="button" onClick={onOpenSettings}>
          {t("WidgetOpenSettings")}
        </button>
        <span>{t("Version")}</span>
      </footer>
    </section>
  );
}
