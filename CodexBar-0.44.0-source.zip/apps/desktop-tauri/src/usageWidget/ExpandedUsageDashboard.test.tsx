import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const tauriMocks = vi.hoisted(() => ({
  getLocaleStrings: vi.fn(),
  setUiLanguage: vi.fn(),
}));

const eventMocks = vi.hoisted(() => ({
  listen: vi.fn(),
}));

vi.mock("../lib/tauri", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../lib/tauri")>()),
  ...tauriMocks,
}));
vi.mock("@tauri-apps/api/event", () => eventMocks);

import { LocaleProvider } from "../i18n/LocaleProvider";
import { buildBundle } from "../test/localeHarness";
import type { CodexWidgetModel } from "./model";
import {
  ExpandedUsageDashboard,
  formatUpdatedAt,
} from "./ExpandedUsageDashboard";

let dateNowSpy: ReturnType<typeof vi.spyOn>;

const model: CodexWidgetModel = {
  status: "fresh",
  tone: "warning",
  planName: "Plus",
  updatedAt: "2026-07-19T11:00:00Z",
  session: {
    usedPercent: 22,
    remainingPercent: 78,
    resetsAt: null,
    resetDescription: "4小时",
  },
  weekly: {
    usedPercent: 82,
    remainingPercent: 18,
    resetsAt: null,
    resetDescription: "6天1小时",
  },
  pace: {
    stage: "behind",
    deltaPercent: 8,
    willLastToReset: true,
    etaSeconds: null,
    expectedUsedPercent: 74,
    actualUsedPercent: 82,
  },
  error: null,
};

function renderDashboard(
  overrides: Partial<React.ComponentProps<typeof ExpandedUsageDashboard>> = {},
) {
  const props: React.ComponentProps<typeof ExpandedUsageDashboard> = {
    model,
    pinned: false,
    theme: "deepBlue",
    onPinChange: vi.fn(),
    onRefresh: vi.fn(),
    onCollapse: vi.fn(),
    onOpenSettings: vi.fn(),
    ...overrides,
  };

  return {
    props,
    ...render(
      <LocaleProvider>
        <ExpandedUsageDashboard {...props} />
      </LocaleProvider>,
    ),
  };
}

describe("ExpandedUsageDashboard", () => {
  beforeEach(() => {
    dateNowSpy = vi
      .spyOn(Date, "now")
      .mockReturnValue(new Date("2026-07-19T12:00:00Z").getTime());
    vi.clearAllMocks();
    eventMocks.listen.mockResolvedValue(() => {});
    tauriMocks.getLocaleStrings.mockResolvedValue(
      buildBundle({
        ActionClose: "收起",
        ActionRefresh: "刷新",
        DetailPaceAhead: "超前",
        DetailPaceBehind: "落后",
        DetailPaceFarAhead: "远超前",
        DetailPaceFarBehind: "远落后",
        DetailPaceOnTrack: "正常",
        DetailPaceSlightlyAhead: "略超前",
        DetailPaceSlightlyBehind: "略落后",
        Plan: "套餐",
        ProviderSession: "本次会话",
        ProviderWeekly: "本周",
        Status: "状态",
        Updated: "更新时间",
        WidgetLoginRequired: "需要重新登录",
        WidgetOpenSettings: "打开设置",
        WidgetPin: "固定窗口",
        WidgetQuotaUnavailable: "账户暂未提供此额度",
        WidgetRefreshFailed: "数据更新失败，正在显示上次结果",
        WidgetRemaining: "剩余",
        WidgetSyncedJustNow: "刚刚同步",
        WidgetTitle: "Codex 用量",
        WidgetUnpin: "取消固定",
        WidgetUsed: "已使用",
        ResetsInHoursMinutes: "{}小时{}分钟后重置",
        ResetsInMinutes: "{}分钟后重置",
        ResetsInDaysHours: "{}天{}小时后重置",
        TrayResetsDueNow: "正在重置",
      }, "chinese"),
    );
  });

  afterEach(() => {
    dateNowSpy.mockRestore();
  });

  it("renders the complete quota, plan, update, status, and pace summary", async () => {
    const { container } = renderDashboard();

    expect(await screen.findByText("Codex 用量")).toBeVisible();
    expect(screen.getByText("本次会话")).toBeVisible();
    expect(screen.getByText("本周")).toBeVisible();
    expect(screen.getByText("78%")).toBeVisible();
    expect(screen.getByText("18%")).toBeVisible();
    expect(screen.getAllByText("Plus")).toHaveLength(2);
    expect(screen.getByText("刚刚同步")).toBeVisible();
    expect(screen.getByText("落后")).toBeVisible();
    expect(container.querySelector(".usage-dashboard")).toHaveAttribute(
      "data-widget-theme",
      "deepBlue",
    );
    expect(container.querySelector("[data-tauri-drag-region]")).toBeNull();
  });

  it("forwards pin, refresh, and collapse controls as UI events", async () => {
    const { props } = renderDashboard();

    fireEvent.click(await screen.findByRole("button", { name: "固定窗口" }));
    fireEvent.click(screen.getByRole("button", { name: "刷新" }));
    fireEvent.click(screen.getByRole("button", { name: "收起" }));
    fireEvent.click(screen.getByRole("button", { name: "打开设置" }));

    expect(props.onPinChange).toHaveBeenCalledWith(true);
    expect(props.onRefresh).toHaveBeenCalledTimes(1);
    expect(props.onCollapse).toHaveBeenCalledTimes(1);
    expect(props.onOpenSettings).toHaveBeenCalledTimes(1);
    for (const button of screen.getAllByRole("button")) {
      expect(button).not.toHaveAttribute("data-tauri-drag-region");
    }
  });

  it("shows localized empty quota and pace states without fabricated values", async () => {
    renderDashboard({
      model: {
        ...model,
        status: "empty",
        tone: "offline",
        planName: null,
        updatedAt: null,
        session: null,
        weekly: null,
        pace: null,
      },
    });

    expect(await screen.findAllByText("账户暂未提供此额度")).toHaveLength(4);
    expect(screen.queryByText("0%")).not.toBeInTheDocument();
  });

  it("shows the available quota while localizing a missing weekly quota", async () => {
    renderDashboard({
      model: {
        ...model,
        weekly: null,
      },
    });

    expect(await screen.findByText("78%")).toBeVisible();
    expect(screen.getByText("22% 已使用")).toBeVisible();
    expect(screen.getByText("账户暂未提供此额度")).toBeVisible();
    expect(screen.queryByText("0%")).not.toBeInTheDocument();
  });

  it("localizes reset timestamps instead of rendering provider English", async () => {
    renderDashboard({
      model: {
        ...model,
        session: {
          ...model.session!,
          resetsAt: "2026-07-19T16:30:00Z",
          resetDescription: "4h 30m",
        },
      },
    });

    expect(await screen.findByText("4小时30分钟后重置")).toBeVisible();
    expect(screen.queryByText("4h 30m")).not.toBeInTheDocument();
  });

  it("shows a localized sign-in state without treating error placeholders as quota", async () => {
    renderDashboard({
      model: {
        ...model,
        status: "signedOut",
        tone: "offline",
        session: null,
        weekly: null,
        pace: null,
      },
    });

    expect(await screen.findByText("需要重新登录")).toBeVisible();
    expect(screen.queryByText("100%")).not.toBeInTheDocument();
  });

  it.each([
    ["on_track", "正常"],
    ["slightly_ahead", "略超前"],
    ["ahead", "超前"],
    ["far_ahead", "远超前"],
    ["slightly_behind", "略落后"],
    ["behind", "落后"],
    ["far_behind", "远落后"],
  ] as const)("localizes the %s pace stage exactly", async (stage, label) => {
    renderDashboard({
      model: {
        ...model,
        pace: { ...model.pace!, stage },
      },
    });

    expect(await screen.findByText(label)).toBeVisible();
  });

  it("formats update time with the app language even when the system is English", () => {
    const format = vi.fn(() => "中文日期");
    const formatter = vi
      .spyOn(Intl, "DateTimeFormat")
      .mockImplementation(
        () => ({ format }) as unknown as Intl.DateTimeFormat,
      );

    expect(formatUpdatedAt("2026-07-19T11:00:00Z", "chinese")).toBe("中文日期");
    expect(formatter).toHaveBeenCalledWith("zh-CN", expect.any(Object));

    formatter.mockRestore();
  });
});
