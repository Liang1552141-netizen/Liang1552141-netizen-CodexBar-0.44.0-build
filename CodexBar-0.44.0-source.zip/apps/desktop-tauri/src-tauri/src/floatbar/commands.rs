//! Tauri commands that drive the floating-bar window.
//!
//! These are thin wrappers around the local `window` module. User-initiated
//! changes keep persisted settings in sync, while the resize command applies a
//! new size and the native interaction state together.

use std::sync::Mutex;

use codexbar::settings::{clamp_float_bar_opacity, normalize_float_bar_orientation, Settings};
use tauri::{AppHandle, Emitter, Manager};

use super::window as floatbar_window;
use crate::widget_policy::{decide, WidgetAction, WidgetEvent, WidgetState};

pub const USAGE_WIDGET_EXPANDED_EVENT: &str = "usage-widget-expanded";
pub const USAGE_WIDGET_COLLAPSED_EVENT: &str = "usage-widget-collapsed";
pub const WIDGET_VISUAL_UPDATES_SUSPENDED_EVENT: &str =
    "widget-visual-updates-suspended";
pub const WIDGET_VISUAL_UPDATES_RESUMED_EVENT: &str = "widget-visual-updates-resumed";

const USAGE_WIDGET_MINI_WIDTH: f64 = 395.0;
const USAGE_WIDGET_MINI_HEIGHT: f64 = 82.0;
const USAGE_WIDGET_EXPANDED_WIDTH: f64 = 420.0;
const USAGE_WIDGET_EXPANDED_HEIGHT: f64 = 520.0;

fn widget_state(app: &AppHandle) -> Result<tauri::State<'_, Mutex<WidgetState>>, String> {
    app.try_state::<Mutex<WidgetState>>()
        .ok_or_else(|| "usage widget policy state is unavailable".to_string())
}

fn resize_usage_widget(app: &AppHandle, width: f64, height: f64) -> Result<(), String> {
    let settings = Settings::load();
    if let Some(window) = app.get_webview_window(floatbar_window::FLOATBAR_LABEL) {
        floatbar_window::resize(
            &window,
            width,
            height,
            settings.float_bar_click_through,
            settings.widget_smart_topmost,
        )?;
    }
    Ok(())
}

pub(crate) fn collapse_usage_widget_window(app: &AppHandle) -> Result<(), String> {
    resize_usage_widget(app, USAGE_WIDGET_MINI_WIDTH, USAGE_WIDGET_MINI_HEIGHT)?;
    app.emit(USAGE_WIDGET_COLLAPSED_EVENT, ())
        .map_err(|error| error.to_string())
}

#[tauri::command]
pub async fn show_float_bar(app: AppHandle) -> Result<(), String> {
    let (settings, ()) = crate::settings_mutation::mutate(|settings| {
        settings.float_bar_enabled = true;
        Ok(())
    })?;

    floatbar_window::show(
        &app,
        settings.float_bar_opacity,
        &settings.float_bar_orientation,
        &settings.float_bar_style,
        settings.widget_smart_topmost,
        settings.float_bar_click_through,
    )?;
    collapse_usage_widget_window(&app)
}

#[tauri::command]
pub fn hide_float_bar(app: AppHandle) -> Result<(), String> {
    crate::settings_mutation::mutate(|settings| {
        settings.float_bar_enabled = false;
        Ok(())
    })?;
    floatbar_window::hide(&app)
}

#[tauri::command]
pub fn set_float_bar_opacity(app: AppHandle, opacity: u8) -> Result<(), String> {
    let opacity = clamp_float_bar_opacity(opacity);
    let (settings, ()) = crate::settings_mutation::mutate(|settings| {
        settings.float_bar_opacity = opacity;
        Ok(())
    })?;

    if let Some(window) = app.get_webview_window(floatbar_window::FLOATBAR_LABEL) {
        floatbar_window::apply_opacity(&window, opacity);
        floatbar_window::apply_click_through(&window, settings.float_bar_click_through);
        floatbar_window::apply_topmost(&window, settings.widget_smart_topmost);
    }
    Ok(())
}

#[tauri::command]
pub fn set_float_bar_click_through(app: AppHandle, enabled: bool) -> Result<(), String> {
    let (settings, ()) = crate::settings_mutation::mutate(|settings| {
        settings.float_bar_click_through = enabled;
        Ok(())
    })?;

    if let Some(window) = app.get_webview_window(floatbar_window::FLOATBAR_LABEL) {
        floatbar_window::apply_click_through(&window, enabled);
        floatbar_window::apply_topmost(&window, settings.widget_smart_topmost);
    }
    Ok(())
}

#[tauri::command]
pub fn resize_float_bar(app: AppHandle, width: f64, height: f64) -> Result<(), String> {
    let settings = Settings::load();
    if let Some(window) = app.get_webview_window(floatbar_window::FLOATBAR_LABEL) {
        // One native operation owns the resize + interaction-state invariant,
        // so the webview never has to repair Win32 window styles itself.
        floatbar_window::resize(
            &window,
            width,
            height,
            settings.float_bar_click_through,
            settings.widget_smart_topmost,
        )?;
    }
    Ok(())
}

#[tauri::command]
pub fn set_float_bar_orientation(app: AppHandle, orientation: String) -> Result<(), String> {
    let orientation = normalize_float_bar_orientation(&orientation);
    crate::settings_mutation::mutate(|settings| {
        settings.float_bar_orientation = orientation;
        Ok(())
    })?;

    // The webview re-reads orientation from settings on every config
    // change — emit the live-update event so it re-lays-out without us
    // needing to destroy/recreate the window (which races with Tauri's
    // async window lifecycle and can crash on Windows).
    let _ = app.emit(super::FLOAT_BAR_CONFIG_CHANGED_EVENT, ());
    Ok(())
}

#[tauri::command]
pub async fn expand_usage_widget(app: AppHandle) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || {
        resize_usage_widget(
            &app,
            USAGE_WIDGET_EXPANDED_WIDTH,
            USAGE_WIDGET_EXPANDED_HEIGHT,
        )?;
        app.emit(USAGE_WIDGET_EXPANDED_EVENT, ())
            .map_err(|error| error.to_string())
    })
    .await
    .map_err(|error| error.to_string())?
}

#[tauri::command]
pub async fn collapse_usage_widget(app: AppHandle) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || collapse_usage_widget_window(&app))
        .await
        .map_err(|error| error.to_string())?
}

#[tauri::command]
pub async fn set_usage_widget_pinned(app: AppHandle, pinned: bool) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || {
        crate::settings_mutation::mutate_with_save(
            |settings| {
                settings.widget_pinned = pinned;
                Ok(())
            },
            |settings| super::save_settings_with_widget_state(&app, settings, Some(pinned)),
        )?;

        app.emit(super::FLOAT_BAR_CONFIG_CHANGED_EVENT, ())
            .map_err(|error| error.to_string())
    })
    .await
    .map_err(|error| error.to_string())?
}

#[tauri::command]
pub fn begin_usage_widget_drag(app: AppHandle) -> Result<(), String> {
    let state = widget_state(&app)?;
    let mut state = state
        .lock()
        .map_err(|_| "usage widget policy state is poisoned".to_string())?;
    if state.dragging {
        return Ok(());
    }
    let action = decide(*state, WidgetEvent::DragStarted);
    state.dragging = true;
    drop(state);

    if action == WidgetAction::SuspendVisualUpdates {
        app.emit(WIDGET_VISUAL_UPDATES_SUSPENDED_EVENT, ())
            .map_err(|error| error.to_string())?;
    }
    Ok(())
}

#[tauri::command]
pub fn end_usage_widget_drag(app: AppHandle) -> Result<(), String> {
    let state = widget_state(&app)?;
    let mut state = state
        .lock()
        .map_err(|_| "usage widget policy state is poisoned".to_string())?;
    if !state.dragging {
        return Ok(());
    }
    let action = decide(*state, WidgetEvent::DragEnded);
    state.dragging = false;
    drop(state);

    if action == WidgetAction::ResumeVisualUpdates {
        app.emit(WIDGET_VISUAL_UPDATES_RESUMED_EVENT, ())
            .map_err(|error| error.to_string())?;
    }
    Ok(())
}
