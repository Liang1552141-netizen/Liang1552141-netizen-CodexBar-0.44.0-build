import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const repoRoot = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
const read = (path) => readFileSync(join(repoRoot, path), "utf8");

export function checkReleaseMetadata(readFile) {
  const failures = [];

  function check(condition, message) {
    if (!condition) failures.push(message);
  }

  function cargoVersion(path) {
    return readFile(path).match(/^version = "([^"]+)"/m)?.[1] ?? "";
  }

  const version =
    readFile("version.env").match(/^MARKETING_VERSION=(.+)$/m)?.[1]?.trim() ?? "";
  check(
    version === "0.44.0",
    `version.env must pin 0.44.0, got ${version || "<missing>"}`,
  );

  const packageJson = JSON.parse(readFile("apps/desktop-tauri/package.json"));
  const tauriConfig = JSON.parse(
    readFile("apps/desktop-tauri/src-tauri/tauri.conf.json"),
  );
  const versionSources = new Map([
    ["apps/desktop-tauri/package.json", packageJson.version],
    ["apps/desktop-tauri/src-tauri/tauri.conf.json", tauriConfig.version],
    [
      "apps/desktop-tauri/src-tauri/Cargo.toml",
      cargoVersion("apps/desktop-tauri/src-tauri/Cargo.toml"),
    ],
    ["rust/Cargo.toml", cargoVersion("rust/Cargo.toml")],
  ]);

  for (const [path, actual] of versionSources) {
    check(
      actual === version,
      `${path} version is ${actual || "<missing>"}, expected ${version}`,
    );
  }

  const cargoLock = readFile("Cargo.lock");
  for (const crateName of ["codexbar", "codexbar-desktop-tauri"]) {
    const escapedVersion = version.replaceAll(".", "\\.");
    const packagePattern = new RegExp(
      `\\[\\[package\\]\\]\\nname = "${crateName}"\\nversion = "${escapedVersion}"`,
    );
    check(
      packagePattern.test(cargoLock),
      `Cargo.lock is missing ${crateName} ${version}`,
    );
  }

  const inno = readFile("rust/installer/codexbar.iss");
  check(
    inno.includes(`#define AppVersion "${version}"`),
    `rust/installer/codexbar.iss default AppVersion must be ${version}`,
  );

  check(
    readFile("CHANGELOG.md").includes(`## [Windows] ${version} -`),
    `CHANGELOG.md is missing the ${version} release heading`,
  );
  check(
    readFile("README.zh-CN.md").includes(
      `Win-CodexBar ${version} 中文用量小组件升级版`,
    ),
    `README.zh-CN.md is missing the ${version} upgrade identity`,
  );

  return { version, failures };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { version, failures } = checkReleaseMetadata(read);
  if (failures.length > 0) {
    for (const failure of failures) console.error(`[fail] ${failure}`);
    process.exit(1);
  }

  console.log(`[ok] release metadata sources agree on ${version}`);
}
