#Requires -Version 7.0
<#
.SYNOPSIS
    Capture the expanded Codex usage widget in a real Windows browser.

.DESCRIPTION
    Creates an isolated preview entry point, serves the existing React
    component through Vite, captures a 520 x 650 screenshot with Microsoft
    Edge, then removes the temporary preview files. Production routes and
    bundles are not changed.
#>

param(
    [string]$RepoRoot = (Split-Path -Parent $PSScriptRoot),
    [string]$OutputPath = "CodexBar-dashboard.png"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$RepoRoot = (Resolve-Path $RepoRoot).Path
$AppDir = Join-Path $RepoRoot "apps\desktop-tauri"
$PreviewHtml = Join-Path $AppDir "qa-preview.html"
$PreviewEntry = Join-Path $AppDir "src\qaPreview.tsx"
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$ServerLog = Join-Path ([System.IO.Path]::GetTempPath()) "codexbar-widget-preview.log"
$Server = $null

$EdgeCandidates = @(
    (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
    (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe")
)
$Edge = $EdgeCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $Edge) {
    $EdgeCommand = Get-Command "msedge.exe" -ErrorAction SilentlyContinue
    if ($EdgeCommand) {
        $Edge = $EdgeCommand.Source
    }
}
if (-not $Edge) {
    throw "Microsoft Edge was not found."
}

$Html = @'
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CodexBar Widget QA</title>
    <style>
      html, body, #root {
        width: 520px;
        height: 650px;
        margin: 0;
        overflow: hidden;
        background: #08090b;
      }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/qaPreview.tsx"></script>
  </body>
</html>
'@

$Entry = @'
import React from "react";
import { createRoot } from "react-dom/client";
import { mockIPC } from "@tauri-apps/api/mocks";
import { LocaleProvider } from "./i18n/LocaleProvider";
import { ALL_LOCALE_KEYS } from "./i18n/keys";
import { ExpandedUsageDashboard } from "./usageWidget/ExpandedUsageDashboard";
import type { CodexWidgetModel } from "./usageWidget/model";
import { WEATHER_CACHE_KEY } from "./usageWidget/useWeather";

const entries = Object.fromEntries(ALL_LOCALE_KEYS.map((key) => [key, key]));
Object.assign(entries, {
  ActionClose: "收起",
  ActionRefresh: "刷新",
  DetailPaceAhead: "超前",
  DetailPaceBehind: "落后",
  DetailPaceFarAhead: "远超前",
  DetailPaceFarBehind: "远落后",
  DetailPaceOnTrack: "节奏正常",
  DetailPaceSlightlyAhead: "略超前",
  DetailPaceSlightlyBehind: "略落后",
  WidgetLoginRequired: "需要重新登录",
  WidgetOpenSettings: "打开设置",
  WidgetPin: "固定窗口",
  WidgetQuotaUnavailable: "账户暂未提供此额度",
  WidgetRefreshFailed: "更新失败，正在显示上次结果",
  WidgetRemaining: "剩余",
  WidgetSyncedJustNow: "刚刚同步",
  WidgetTitle: "Codex 用量",
  WidgetUnpin: "取消固定",
  WidgetUsed: "已使用",
  ResetsInHoursMinutes: "{}小时{}分钟后重置",
  ResetsInMinutes: "{}分钟后重置",
  ResetsInDaysHours: "{}天{}小时后重置",
  TrayResetsDueNow: "正在重置",
});

mockIPC(
  (command) => {
    if (command === "get_locale_strings") {
      return { language: "chinese", entries };
    }
    return null;
  },
  { shouldMockEvents: true },
);

localStorage.setItem(
  WEATHER_CACHE_KEY,
  JSON.stringify({
    temperatureC: 27,
    condition: "多云",
    city: "当地天气",
    fetchedAt: Date.now(),
  }),
);

const model: CodexWidgetModel = {
  status: "fresh",
  tone: "ok",
  planName: "Plus",
  updatedAt: new Date().toISOString(),
  session: {
    usedPercent: 22,
    remainingPercent: 78,
    resetsAt: null,
    resetDescription: "4小时",
  },
  weekly: {
    usedPercent: 10,
    remainingPercent: 90,
    resetsAt: null,
    resetDescription: "6天1小时",
  },
  pace: {
    stage: "on_track",
    deltaPercent: 4,
    willLastToReset: true,
    etaSeconds: null,
    expectedUsedPercent: 14,
    actualUsedPercent: 10,
  },
  error: null,
};

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <LocaleProvider>
      <ExpandedUsageDashboard
        model={model}
        pinned
        theme="deepBlue"
        onPinChange={() => {}}
        onRefresh={() => {}}
        onCollapse={() => {}}
        onOpenSettings={() => {}}
      />
    </LocaleProvider>
  </React.StrictMode>,
);
'@

try {
    Set-Content -LiteralPath $PreviewHtml -Value $Html -Encoding utf8NoBOM
    Set-Content -LiteralPath $PreviewEntry -Value $Entry -Encoding utf8NoBOM

    $ServerCommand = "pnpm exec vite --host 127.0.0.1 --port 4173 --strictPort > `"$ServerLog`" 2>&1"
    $Server = Start-Process `
        -FilePath "cmd.exe" `
        -ArgumentList @("/d", "/s", "/c", $ServerCommand) `
        -WorkingDirectory $AppDir `
        -WindowStyle Hidden `
        -PassThru

    $Ready = $false
    foreach ($Attempt in 1..30) {
        try {
            $Response = Invoke-WebRequest `
                -Uri "http://127.0.0.1:4173/qa-preview.html" `
                -UseBasicParsing `
                -TimeoutSec 2
            if ($Response.StatusCode -eq 200) {
                $Ready = $true
                break
            }
        } catch {
            Start-Sleep -Seconds 1
        }
    }
    if (-not $Ready) {
        $Details = if (Test-Path $ServerLog) { Get-Content $ServerLog -Raw } else { "" }
        throw "Widget preview did not start.`n$Details"
    }

    $OutputDirectory = Split-Path -Parent $OutputPath
    if ($OutputDirectory) {
        New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
    }
    & $Edge `
        "--headless=new" `
        "--disable-gpu" `
        "--hide-scrollbars" `
        "--force-device-scale-factor=1" `
        "--window-size=520,650" `
        "--screenshot=$OutputPath" `
        "http://127.0.0.1:4173/qa-preview.html"
    if ($LASTEXITCODE -ne 0) {
        throw "Microsoft Edge screenshot failed with exit code $LASTEXITCODE."
    }
    if (-not (Test-Path $OutputPath)) {
        throw "Widget screenshot was not created: $OutputPath"
    }
    if ((Get-Item $OutputPath).Length -lt 10KB) {
        throw "Widget screenshot is unexpectedly small: $OutputPath"
    }
    Write-Host "Widget screenshot: $OutputPath"
} finally {
    if ($Server -and -not $Server.HasExited) {
        Stop-Process -Id $Server.Id -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -LiteralPath $PreviewHtml -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $PreviewEntry -Force -ErrorAction SilentlyContinue
}
