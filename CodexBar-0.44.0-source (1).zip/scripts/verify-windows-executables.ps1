param(
    [string]$DesktopExe = "",

    [string]$CliExe = "",

    [string]$LegacyDesktopExe = "",

    [switch]$CheckCliStdout,

    [string]$AssetsDir = "C:\code\Win-CodexBar-release\assets",

    [string]$ExpectedVersion = ""
)

$ErrorActionPreference = "Stop"

function Resolve-RequiredPath {
    param(
        [string]$Path,
        [string]$Label
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Missing $Label at $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

function Get-PeSubsystem {
    param([string]$Path)

    $stream = [System.IO.File]::OpenRead($Path)
    try {
        $reader = [System.IO.BinaryReader]::new($stream)
        try {
            [void]$stream.Seek(0x3c, [System.IO.SeekOrigin]::Begin)
            $peOffset = $reader.ReadInt32()
            [void]$stream.Seek($peOffset + 4 + 20 + 68, [System.IO.SeekOrigin]::Begin)
            return $reader.ReadUInt16()
        } finally {
            $reader.Dispose()
        }
    } finally {
        $stream.Dispose()
    }
}

function Get-Sha256 {
    param([string]$Path)
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Assert-ReleaseAsset {
    param(
        [string]$Path,
        [switch]$RequireGuiSubsystem
    )

    $asset = Resolve-RequiredPath -Path $Path -Label "release asset"
    if ((Get-Item -LiteralPath $asset).Length -le 0) {
        throw "Release asset is empty: $asset"
    }

    $stream = [System.IO.File]::OpenRead($asset)
    try {
        if ($stream.ReadByte() -ne 0x4d -or $stream.ReadByte() -ne 0x5a) {
            throw "Release asset is not a PE executable: $asset"
        }
    } finally {
        $stream.Dispose()
    }

    if ($RequireGuiSubsystem -and (Get-PeSubsystem $asset) -ne 2) {
        throw "Portable executable must use the Windows GUI subsystem: $asset"
    }

    $sidecar = Resolve-RequiredPath -Path "$asset.sha256" -Label "SHA-256 sidecar"
    $fields = @((Get-Content -LiteralPath $sidecar | Select-Object -First 1).Trim() -split '\s+')
    if ($fields.Count -ne 2 -or $fields[0] -notmatch '^[0-9a-fA-F]{64}$') {
        throw "Invalid SHA-256 sidecar format: $sidecar"
    }
    $assetName = Split-Path $asset -Leaf
    if ($fields[1] -ne $assetName) {
        throw "SHA-256 sidecar names $($fields[1]), expected $assetName"
    }
    $actualHash = Get-Sha256 $asset
    if ($actualHash -ne $fields[0].ToLowerInvariant()) {
        throw "SHA-256 mismatch for $assetName"
    }
    Write-Host "Verified $assetName and $($assetName).sha256."
}

if ($DesktopExe -or $CliExe -or $LegacyDesktopExe) {
    if (-not $DesktopExe -or -not $CliExe -or -not $LegacyDesktopExe) {
        throw "DesktopExe, CliExe, and LegacyDesktopExe must be supplied together."
    }

    $desktop = Resolve-RequiredPath -Path $DesktopExe -Label "desktop executable"
    $cli = Resolve-RequiredPath -Path $CliExe -Label "CLI executable"
    $legacyDesktop = Resolve-RequiredPath -Path $LegacyDesktopExe -Label "desktop compatibility executable"

    $desktopHash = Get-Sha256 $desktop
    $cliHash = Get-Sha256 $cli
    $legacyDesktopHash = Get-Sha256 $legacyDesktop

    if ($desktopHash -eq $cliHash) {
        throw "codexbar.exe and codexbar-cli.exe must not be byte-identical; the CLI must be the console binary."
    }
    if ($desktopHash -ne $legacyDesktopHash) {
        throw "codexbar.exe and codexbar-desktop.exe should be identical desktop binaries."
    }

    $desktopSubsystem = Get-PeSubsystem $desktop
    $cliSubsystem = Get-PeSubsystem $cli
    $legacyDesktopSubsystem = Get-PeSubsystem $legacyDesktop

    if ($desktopSubsystem -ne 2) {
        throw "codexbar.exe must be a Windows GUI-subsystem desktop binary; got subsystem $desktopSubsystem."
    }
    if ($legacyDesktopSubsystem -ne 2) {
        throw "codexbar-desktop.exe must be a Windows GUI-subsystem desktop binary; got subsystem $legacyDesktopSubsystem."
    }
    if ($cliSubsystem -ne 3) {
        throw "codexbar-cli.exe must be a Windows console-subsystem CLI binary; got subsystem $cliSubsystem."
    }

    if ($CheckCliStdout) {
        $stdoutPath = Join-Path ([System.IO.Path]::GetTempPath()) "codexbar-cli-stdout-$PID.txt"
        try {
            & $cli --help > $stdoutPath
            if ($LASTEXITCODE -ne 0) {
                throw "codexbar-cli.exe --help exited with $LASTEXITCODE"
            }
            $stdout = Get-Content -Raw -LiteralPath $stdoutPath
            if (-not $stdout -or $stdout -notmatch "Usage:" -or $stdout -notmatch "diagnose") {
                throw "codexbar-cli.exe --help did not write expected CLI help to redirected stdout."
            }
        } finally {
            Remove-Item -LiteralPath $stdoutPath -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Host "Windows executable layout verified: desktop GUI binary + separate console CLI."
    return
}

$repoRoot = Split-Path -Parent $PSScriptRoot
if (-not $ExpectedVersion) {
    $versionLine = Get-Content (Join-Path $repoRoot "rust\Cargo.toml") |
        Where-Object { $_ -match '^version = "([^"]+)"' } |
        Select-Object -First 1
    if (-not $versionLine -or $versionLine -notmatch '^version = "([^"]+)"') {
        throw "Failed to determine release version from rust\Cargo.toml."
    }
    $ExpectedVersion = $Matches[1]
}

$installer = Join-Path $AssetsDir "CodexBar-$ExpectedVersion-Setup.exe"
$portable = Join-Path $AssetsDir "CodexBar-$ExpectedVersion-portable.exe"
Assert-ReleaseAsset -Path $installer
Assert-ReleaseAsset -Path $portable -RequireGuiSubsystem
Write-Host "Windows release assets verified for $ExpectedVersion."
