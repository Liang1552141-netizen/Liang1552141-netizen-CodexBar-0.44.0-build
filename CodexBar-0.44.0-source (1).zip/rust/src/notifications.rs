//! System notifications for CodexBar
//!
//! Provides Windows toast notifications for usage alerts

#![allow(dead_code)]

use crate::core::ProviderId;
use crate::core::{RateWindow, UsagePace};
use crate::locale::{self, LocaleKey};
use crate::settings::Settings;
use crate::sound::{AlertSound, play_alert};
use chrono::{DateTime, Utc};

/// Notification types
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NotificationType {
    /// Usage is approaching limit (high threshold)
    HighUsage,
    /// Usage is critical (critical threshold)
    CriticalUsage,
    /// Usage limit exhausted
    Exhausted,
    /// Provider status issue
    StatusIssue,
    /// Session quota depleted (at 100% usage)
    SessionDepleted,
    /// Session quota restored (back from 100%)
    SessionRestored,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PredictiveWarningWindow {
    Session,
    Weekly,
}

impl PredictiveWarningWindow {
    fn localized_label(self, language: crate::settings::Language) -> String {
        locale::get_text(
            language,
            match self {
                Self::Session => LocaleKey::ProviderSession,
                Self::Weekly => LocaleKey::ProviderWeekly,
            },
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct PredictiveResetWindow {
    window_minutes: Option<u32>,
    resets_at: DateTime<Utc>,
}

impl PredictiveResetWindow {
    fn belongs_to_same_cycle(&self, other: &Self) -> bool {
        if self.window_minutes != other.window_minutes {
            return false;
        }
        let tolerance_secs = self
            .window_minutes
            .map(|minutes| i64::from(minutes) * 30)
            .unwrap_or(300)
            .max(300);
        (self.resets_at - other.resets_at).num_seconds().abs() < tolerance_secs
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct PredictiveWarningKey {
    provider: ProviderId,
    identity: String,
    window: PredictiveWarningWindow,
    reset: PredictiveResetWindow,
}

impl NotificationType {
    fn title_key(self) -> LocaleKey {
        match self {
            NotificationType::HighUsage => LocaleKey::UsageNotificationHighTitle,
            NotificationType::CriticalUsage => LocaleKey::UsageNotificationCriticalTitle,
            NotificationType::Exhausted => LocaleKey::UsageNotificationExhaustedTitle,
            NotificationType::StatusIssue => LocaleKey::UsageNotificationStatusTitle,
            NotificationType::SessionDepleted => {
                LocaleKey::UsageNotificationSessionDepletedTitle
            }
            NotificationType::SessionRestored => {
                LocaleKey::UsageNotificationSessionRestoredTitle
            }
        }
    }

    pub fn title(self, language: crate::settings::Language) -> String {
        locale::get_text(language, self.title_key())
    }

    pub fn icon(&self) -> &'static str {
        match self {
            NotificationType::HighUsage => "⚠️",
            NotificationType::CriticalUsage => "🔴",
            NotificationType::Exhausted => "🚫",
            NotificationType::StatusIssue => "⚡",
            NotificationType::SessionDepleted => "🔴",
            NotificationType::SessionRestored => "✅",
        }
    }

    fn is_threshold_toast(self) -> bool {
        matches!(
            self,
            NotificationType::HighUsage
                | NotificationType::CriticalUsage
                | NotificationType::Exhausted
        )
    }
}

/// Dedupe identity for threshold toasts.
/// - `account`: stable per-account discriminator (email, token-account id, …).
///   Empty string is the legacy single-account lane.
/// - `window`: rate window id (`"session"`, `"weekly"`, …) so budgets arm independently.
/// - `reset_cycle`: stable reset identity supplied by the usage window. When a
///   provider has no reset metadata, callers use one process-lifetime lane.
type ThresholdKey = (
    ProviderId,
    String, /* account */
    String, /* window */
    String, /* reset cycle */
    NotificationType,
);

/// Process-local lane for reset timestamp stabilization.
type ThresholdResetLane = (
    ProviderId,
    String, /* account */
    String, /* window */
);

#[derive(Debug, Clone)]
struct ThresholdResetWindow {
    window_minutes: u32,
    resets_at: DateTime<Utc>,
    cycle: String,
}

impl ThresholdResetWindow {
    fn belongs_to_same_cycle(&self, window_minutes: u32, resets_at: &DateTime<Utc>) -> bool {
        if self.window_minutes != window_minutes {
            return false;
        }
        let window_millis = i64::from(window_minutes) * 60_000;
        let tolerance_millis = (window_millis / 10).clamp(1_000, 60_000);
        self.resets_at
            .timestamp_millis()
            .abs_diff(resets_at.timestamp_millis())
            <= tolerance_millis as u64
    }
}

/// Session-transition tracking key: provider + account identity.
type SessionTransitionKey = (ProviderId, String /* account */);

/// Notification manager
pub struct NotificationManager {
    /// Track which notifications have been sent to avoid spam
    sent_notifications: std::collections::HashSet<ThresholdKey>,
    /// Track previous session percent for depleted/restored transitions (per account)
    previous_session_percent: std::collections::HashMap<SessionTransitionKey, f64>,
    /// Keep one canonical reset timestamp per provider/account/window lane.
    threshold_reset_windows:
        std::collections::HashMap<ThresholdResetLane, ThresholdResetWindow>,
    predictive_warning_keys: std::collections::HashSet<PredictiveWarningKey>,
}

impl NotificationManager {
    pub fn new() -> Self {
        Self {
            sent_notifications: std::collections::HashSet::new(),
            previous_session_percent: std::collections::HashMap::new(),
            threshold_reset_windows: std::collections::HashMap::new(),
            predictive_warning_keys: std::collections::HashSet::new(),
        }
    }

    /// Return a process-local stable key for a provider reset timestamp.
    ///
    /// Small timestamp jitter is merged against the cycle's fixed anchor.
    /// The anchor must not follow each observation: doing so would make a chain
    /// of individually small corrections bridge into the next real window.
    /// A real next reset replaces the lane entry, so reset tracking stays
    /// bounded to one entry per lane.
    pub fn normalize_threshold_reset_cycle(
        &mut self,
        provider: ProviderId,
        account: &str,
        window: &str,
        resets_at: &str,
        window_minutes: Option<u32>,
    ) -> String {
        let raw_cycle = format!("resets-at:{resets_at}");
        let lane = (
            provider,
            account.to_string(),
            window.to_string(),
        );
        let Ok(parsed) = DateTime::parse_from_rfc3339(resets_at) else {
            self.threshold_reset_windows.remove(&lane);
            return raw_cycle;
        };
        let Some(window_minutes) = window_minutes.filter(|minutes| *minutes > 0) else {
            self.threshold_reset_windows.remove(&lane);
            return raw_cycle;
        };
        let resets_at = parsed.with_timezone(&Utc);

        if let Some(existing) = self.threshold_reset_windows.get(&lane)
            && existing.belongs_to_same_cycle(window_minutes, &resets_at)
        {
            return existing.cycle.clone();
        }

        self.threshold_reset_windows.insert(
            lane,
            ThresholdResetWindow {
                window_minutes,
                resets_at,
                cycle: raw_cycle.clone(),
            },
        );
        raw_cycle
    }

    /// Drop quota/reset history for provider/account/window lanes that are no
    /// longer present in the latest successful cache snapshot.
    ///
    /// `active_providers` retains provider-scoped status history.
    /// Providers whose current snapshot is an error can additionally be listed
    /// in `uncertain_providers`; their prior lane is retained until a
    /// successful observation can identify the active account without
    /// re-arming a hot window after a transient failure.
    pub fn retain_active_usage_lanes(
        &mut self,
        active_lanes: &[(ProviderId, String, String)],
        active_providers: &[ProviderId],
        uncertain_providers: &[ProviderId],
    ) {
        let lane_is_active = |provider: ProviderId, account: &str, window: &str| {
            uncertain_providers.contains(&provider)
                || active_lanes.iter().any(
                    |(active_provider, active_account, active_window)| {
                        *active_provider == provider
                            && active_account == account
                            && active_window == window
                    },
                )
        };
        let provider_is_active =
            |provider: ProviderId| active_providers.contains(&provider);

        self.threshold_reset_windows
            .retain(|lane, _| lane_is_active(lane.0, lane.1.as_str(), lane.2.as_str()));
        self.previous_session_percent
            .retain(|key, _| lane_is_active(key.0, key.1.as_str(), "session"));
        self.sent_notifications.retain(|key| match key.4 {
            NotificationType::StatusIssue => provider_is_active(key.0),
            _ => lane_is_active(key.0, key.1.as_str(), key.2.as_str()),
        });
    }

    /// Keep predictive dedupe state only for the exact provider/account/window
    /// lanes present in the latest successful snapshot.
    ///
    /// A provider in `uncertain_providers` had a transient fetch error, so its
    /// last known lanes remain valid until a successful snapshot can identify
    /// the current account and windows.
    pub fn retain_active_predictive_lanes(
        &mut self,
        active_lanes: &[(ProviderId, String, PredictiveWarningWindow)],
        uncertain_providers: &[ProviderId],
    ) {
        self.predictive_warning_keys.retain(|key| {
            uncertain_providers.contains(&key.provider)
                || active_lanes.iter().any(
                    |(provider, identity, window)| {
                        *provider == key.provider
                            && identity == &key.identity
                            && *window == key.window
                    },
                )
        });
    }

    pub fn record_predictive_observation(
        &mut self,
        enabled: bool,
        provider: ProviderId,
        identity: &str,
        window: PredictiveWarningWindow,
        rate_window: &RateWindow,
        pace: &UsagePace,
    ) -> bool {
        if !enabled {
            self.predictive_warning_keys
                .retain(|key| key.provider != provider);
            return false;
        }
        if !matches!(provider, ProviderId::Claude | ProviderId::Codex) || identity.is_empty() {
            return false;
        }
        let Some(resets_at) = rate_window.resets_at else {
            return false;
        };
        let key = PredictiveWarningKey {
            provider,
            identity: identity.to_string(),
            window,
            reset: PredictiveResetWindow {
                window_minutes: rate_window.window_minutes,
                resets_at,
            },
        };

        let warned_this_cycle = self.predictive_warning_keys.iter().any(|existing| {
            existing.provider == key.provider
                && existing.identity == key.identity
                && existing.window == key.window
                && existing.reset.belongs_to_same_cycle(&key.reset)
        });
        self.predictive_warning_keys.retain(|existing| {
            existing.provider != key.provider
                || existing.identity != key.identity
                || existing.window != key.window
        });

        if pace.will_last_to_reset {
            return false;
        }
        if !pace
            .eta_seconds
            .is_some_and(|eta| eta.is_finite() && eta > 0.0)
        {
            return false;
        }

        self.predictive_warning_keys.insert(key);
        !warned_this_cycle
    }

    pub fn set_predictive_warnings_enabled(&mut self, provider: ProviderId, enabled: bool) {
        if !enabled {
            self.predictive_warning_keys
                .retain(|key| key.provider != provider);
        }
    }

    pub fn check_predictive_pace(
        &mut self,
        provider: ProviderId,
        identity: &str,
        window: PredictiveWarningWindow,
        rate_window: &RateWindow,
        pace: &UsagePace,
        settings: &Settings,
    ) {
        if !self.record_predictive_observation(
            settings.show_notifications && settings.predictive_pace_warning_enabled,
            provider,
            identity,
            window,
            rate_window,
            pace,
        ) {
            return;
        }

        let eta = format_duration(pace.eta_seconds.unwrap_or_default());
        let provider_name = provider.display_name();
        let window_label = window.localized_label(settings.ui_language);
        let title = locale::format_locale(
            settings.ui_language,
            LocaleKey::PredictivePaceWarningTitle,
            &[provider_name, &window_label],
        );
        let body = locale::format_locale(
            settings.ui_language,
            LocaleKey::PredictivePaceWarningBody,
            &[&eta],
        );
        self.show_toast(&title, &body);
        play_alert(AlertSound::Warning, settings);
    }

    /// Check usage and send notifications if thresholds are crossed.
    ///
    /// `account` is a stable account discriminator (email, token-account id, …).
    /// Pass `""` for single-account providers when no identity is available.
    /// `reset_cycle` must prefer the window's ISO `resets_at`, then its stable
    /// reset description, and otherwise use a process-lifetime fallback.
    pub fn check_and_notify(
        &mut self,
        provider: ProviderId,
        account: &str,
        window: &str,
        reset_cycle: &str,
        used_percent: f64,
        settings: &Settings,
    ) {
        if let Some(notification_type) = self.evaluate(
            provider,
            account,
            window,
            reset_cycle,
            used_percent,
            settings,
        ) {
            self.send_notification(
                provider,
                window,
                used_percent,
                notification_type,
                settings,
            );
        }
    }

    fn evaluate(
        &mut self,
        provider: ProviderId,
        account: &str,
        window: &str,
        reset_cycle: &str,
        used_percent: f64,
        settings: &Settings,
    ) -> Option<NotificationType> {
        if !settings.show_notifications {
            return None;
        }

        // Retain only the current reset cycle for this lane. Together with the
        // one-entry reset tracker above, this prevents cycle history from
        // growing for the lifetime of the process.
        self.sent_notifications.retain(|key| {
            !key.4.is_threshold_toast()
                || key.0 != provider
                || key.1 != account
                || key.2 != window
                || key.3 == reset_cycle
        });

        let thresholds = settings.usage_thresholds(provider, window);
        let notification_type = if used_percent >= 100.0 {
            NotificationType::Exhausted
        } else if used_percent >= thresholds.critical {
            NotificationType::CriticalUsage
        } else if used_percent >= thresholds.high {
            NotificationType::HighUsage
        } else {
            return None;
        };
        let lane = (
            provider,
            account.to_string(),
            window.to_string(),
            reset_cycle.to_string(),
        );

        // Once a stronger tier has fired in this reset cycle, a later lower
        // reading must not create a backwards notification.
        let stronger_already_sent = match notification_type {
            NotificationType::HighUsage => [
                NotificationType::CriticalUsage,
                NotificationType::Exhausted,
            ]
            .into_iter()
            .any(|kind| {
                self.sent_notifications.contains(&(
                    lane.0,
                    lane.1.clone(),
                    lane.2.clone(),
                    lane.3.clone(),
                    kind,
                ))
            }),
            NotificationType::CriticalUsage => self.sent_notifications.contains(&(
                lane.0,
                lane.1.clone(),
                lane.2.clone(),
                lane.3.clone(),
                NotificationType::Exhausted,
            )),
            _ => false,
        };
        if stronger_already_sent {
            return None;
        }

        let key = (
            lane.0,
            lane.1,
            lane.2,
            lane.3,
            notification_type,
        );
        if self.sent_notifications.insert(key) {
            Some(notification_type)
        } else {
            None
        }
    }

    /// Send a notification for a status issue
    pub fn notify_status_issue(
        &mut self,
        provider: ProviderId,
        description: &str,
        settings: &Settings,
    ) {
        let key = (
            provider,
            String::new(),
            String::new(),
            String::new(),
            NotificationType::StatusIssue,
        );
        if !self.sent_notifications.contains(&key) {
            self.send_status_notification(provider, description, settings);
            self.sent_notifications.insert(key);
        }
    }

    /// Clear status issue notification (when resolved)
    pub fn clear_status_issue(&mut self, provider: ProviderId) {
        self.sent_notifications.remove(&(
            provider,
            String::new(),
            String::new(),
            String::new(),
            NotificationType::StatusIssue,
        ));
    }

    /// Check session quota transitions (depleted/restored)
    /// Call this with each usage update to detect transitions.
    ///
    /// `account` scopes depleted/restored state so multi-account providers do not
    /// cross-arm session transitions.
    pub fn check_session_transition(
        &mut self,
        provider: ProviderId,
        account: &str,
        current_percent: f64,
        settings: &Settings,
    ) {
        if !settings.show_notifications {
            return;
        }

        const DEPLETED_THRESHOLD: f64 = 99.99; // Consider depleted at 99.99%+

        let transition_key: SessionTransitionKey = (provider, account.to_string());
        let previous_percent = self
            .previous_session_percent
            .get(&transition_key)
            .copied()
            .unwrap_or(0.0);

        // Check for depleted transition: was not depleted, now is
        if previous_percent < DEPLETED_THRESHOLD && current_percent >= DEPLETED_THRESHOLD {
            let (title, body) = Self::notification_content(
                provider,
                "session",
                current_percent,
                NotificationType::SessionDepleted,
                settings.ui_language,
            );
            self.show_toast(&title, &body);
            play_alert(AlertSound::Error, settings);
            self.sent_notifications.insert((
                provider,
                account.to_string(),
                "session".to_string(),
                String::new(),
                NotificationType::SessionDepleted,
            ));
        }
        // Check for restored transition: was depleted, now is not
        else if previous_percent >= DEPLETED_THRESHOLD && current_percent < DEPLETED_THRESHOLD {
            // Only notify restored if we previously sent a depleted notification
            let depleted_key = (
                provider,
                account.to_string(),
                "session".to_string(),
                String::new(),
                NotificationType::SessionDepleted,
            );
            if self.sent_notifications.contains(&depleted_key) {
                let (title, body) = Self::notification_content(
                    provider,
                    "session",
                    current_percent,
                    NotificationType::SessionRestored,
                    settings.ui_language,
                );
                self.show_toast(&title, &body);
                play_alert(AlertSound::Success, settings);
                self.sent_notifications.remove(&depleted_key);
            }
        }

        // Update the tracked previous percent for this account
        self.previous_session_percent
            .insert(transition_key, current_percent);
    }

    /// Send a Windows toast notification with sound
    fn send_notification(
        &self,
        provider: ProviderId,
        window: &str,
        used_percent: f64,
        notif_type: NotificationType,
        settings: &Settings,
    ) {
        let (title, body) = Self::notification_content(
            provider,
            window,
            used_percent,
            notif_type,
            settings.ui_language,
        );
        self.show_toast(&title, &body);
        play_alert(Self::alert_sound_for(notif_type), settings);
    }

    fn window_label(window: &str, language: crate::settings::Language) -> String {
        match window {
            "session" => locale::get_text(language, LocaleKey::ProviderSession),
            "weekly" => locale::get_text(language, LocaleKey::ProviderWeekly),
            other if !other.is_empty() => other.to_string(),
            _ => locale::get_text(language, LocaleKey::ProviderUsage),
        }
    }

    fn notification_content(
        provider: ProviderId,
        window: &str,
        used_percent: f64,
        notif_type: NotificationType,
        language: crate::settings::Language,
    ) -> (String, String) {
        let provider_name = provider.display_name();
        let window_label = Self::window_label(window, language);
        let percent = format!("{used_percent:.0}");
        let body = match notif_type {
            NotificationType::HighUsage => locale::format_locale(
                language,
                LocaleKey::UsageNotificationHighBody,
                &[provider_name, &window_label, &percent],
            ),
            NotificationType::CriticalUsage => locale::format_locale(
                language,
                LocaleKey::UsageNotificationCriticalBody,
                &[provider_name, &window_label, &percent],
            ),
            NotificationType::Exhausted => locale::format_locale(
                language,
                LocaleKey::UsageNotificationExhaustedBody,
                &[provider_name, &window_label, &percent],
            ),
            NotificationType::StatusIssue => locale::format_locale(
                language,
                LocaleKey::UsageNotificationStatusBody,
                &[provider_name, ""],
            ),
            NotificationType::SessionDepleted => locale::format_locale(
                language,
                LocaleKey::UsageNotificationSessionDepletedBody,
                &[provider_name, &window_label],
            ),
            NotificationType::SessionRestored => locale::format_locale(
                language,
                LocaleKey::UsageNotificationSessionRestoredBody,
                &[provider_name, &window_label],
            ),
        };
        (notif_type.title(language), body)
    }

    fn alert_sound_for(notif_type: NotificationType) -> AlertSound {
        match notif_type {
            NotificationType::HighUsage => AlertSound::Warning,
            NotificationType::CriticalUsage => AlertSound::Critical,
            NotificationType::Exhausted
            | NotificationType::StatusIssue
            | NotificationType::SessionDepleted => AlertSound::Error,
            NotificationType::SessionRestored => AlertSound::Success,
        }
    }

    fn send_status_notification(
        &self,
        provider: ProviderId,
        description: &str,
        settings: &Settings,
    ) {
        let title = NotificationType::StatusIssue.title(settings.ui_language);
        let body = locale::format_locale(
            settings.ui_language,
            LocaleKey::UsageNotificationStatusBody,
            &[provider.display_name(), description],
        );
        self.show_toast(&title, &body);
        play_alert(AlertSound::Error, settings);
    }

    #[cfg(target_os = "windows")]
    fn show_toast(&self, title: &str, body: &str) {
        use std::os::windows::process::CommandExt;
        use std::process::Command;
        use std::sync::Once;

        // Register our AUMID (App User Model ID) exactly once per process so that
        // CreateToastNotifier("CodexBar") finds a valid registration rather than
        // silently returning a null notifier.
        static AUMID_INIT: Once = Once::new();
        AUMID_INIT.call_once(ensure_aumid_registered);

        // Escape for XML content to prevent injection
        fn xml_escape(s: &str) -> String {
            s.replace('&', "&amp;")
                .replace('<', "&lt;")
                .replace('>', "&gt;")
                .replace('"', "&quot;")
                .replace('\'', "&apos;")
        }

        let safe_title = xml_escape(title);
        let safe_body = xml_escape(body);

        // Uses ToastGeneric (Win 10+) and wraps in try/catch so PowerShell exits
        // with code 1 on failure rather than swallowing the error silently.
        // Single-quoted here-string (@'...'@) prevents variable expansion of the
        // XML content by PowerShell.
        let script = format!(
            r#"try {{
    [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
    [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
    $template = @'
<toast><visual><binding template="ToastGeneric"><text>{}</text><text>{}</text></binding></visual></toast>
'@
    $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $xml.LoadXml($template)
    $toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
    $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("CodexBar")
    if ($null -eq $notifier) {{ throw "CreateToastNotifier returned null" }}
    $notifier.Show($toast)
}} catch {{
    [System.Console]::Error.WriteLine("CodexBar toast failed: $_")
    exit 1
}}"#,
            safe_title, safe_body
        );

        match Command::new("powershell")
            .args([
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                &script,
            ])
            .creation_flags(0x08000000) // CREATE_NO_WINDOW
            .spawn()
        {
            Ok(_) => tracing::debug!("Toast notification dispatched: {}", title),
            Err(e) => tracing::warn!("Failed to dispatch toast notification '{}': {}", title, e),
        }
    }

    #[cfg(not(target_os = "windows"))]
    fn show_toast(&self, title: &str, body: &str) {
        use std::process::Command;

        // Dispatch without waiting for the desktop notification process. Apart
        // from matching the Windows implementation, this keeps notification
        // generation ownership from holding AppState across an external wait.
        if let Ok(mut child) = Command::new("notify-send")
            .args([
                "--app-name=CodexBar",
                "--icon=dialog-information",
                title,
                body,
            ])
            .spawn()
        {
            std::thread::spawn(move || {
                let _ = child.wait();
            });
            tracing::debug!("Sent notification via notify-send: {}", title);
            return;
        }

        tracing::info!("Notification: {} - {}", title, body);
    }
}

fn format_duration(seconds: f64) -> String {
    let total_minutes = (seconds / 60.0).ceil().max(1.0) as i64;
    let days = total_minutes / 1440;
    let hours = (total_minutes % 1440) / 60;
    let minutes = total_minutes % 60;
    if days > 0 {
        format!("{days}d {hours}h")
    } else if hours > 0 {
        format!("{hours}h {minutes}m")
    } else {
        format!("{minutes}m")
    }
}

impl Default for NotificationManager {
    fn default() -> Self {
        Self::new()
    }
}

/// Register the CodexBar App User Model ID (AUMID) in the Windows registry so that
/// `CreateToastNotifier("CodexBar")` resolves to a valid notifier instead of returning
/// null.  Must be called at least once before the first toast.  Safe to call multiple
/// times (idempotent registry write).
#[cfg(target_os = "windows")]
fn ensure_aumid_registered() {
    use winreg::RegKey;
    use winreg::enums::*;

    let hkcu = RegKey::predef(HKEY_CURRENT_USER);
    // HKCU\SOFTWARE\Classes\AppUserModelId\<AUMID> is the documented path for
    // registering Win32 desktop app AUMIDs without a COM server or Start Menu shortcut.
    let result = hkcu
        .create_subkey(r"SOFTWARE\Classes\AppUserModelId\CodexBar")
        .and_then(|(key, _)| key.set_value("DisplayName", &"CodexBar"));

    match result {
        Ok(()) => tracing::debug!("CodexBar AUMID registered for Windows toast notifications"),
        Err(e) => tracing::warn!("Failed to register CodexBar AUMID: {}", e),
    }
}

/// Simple notification function for one-off notifications
pub fn show_notification(title: &str, body: &str) {
    let manager = NotificationManager::new();
    manager.show_toast(title, body);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{PaceStage, RateWindow, UsagePace};
    use crate::settings::Language;
    use chrono::{DateTime, Duration, Utc};

    fn pace(will_last_to_reset: bool, eta_seconds: Option<f64>) -> UsagePace {
        UsagePace {
            stage: PaceStage::Ahead,
            delta_percent: 20.0,
            expected_used_percent: 40.0,
            actual_used_percent: 60.0,
            eta_seconds,
            will_last_to_reset,
        }
    }

    fn window(now: DateTime<Utc>, offset: Duration, minutes: u32) -> RateWindow {
        RateWindow::with_details(60.0, Some(minutes), Some(now + offset), None)
    }

    #[test]
    fn chinese_threshold_and_session_notifications_use_locale_resources() {
        let high = NotificationManager::notification_content(
            ProviderId::Codex,
            "weekly",
            81.0,
            NotificationType::HighUsage,
            Language::Chinese,
        );
        assert_eq!(high.0, "用量即将达到上限");
        assert_eq!(high.1, "Codex 本周用量已达 81%，即将达到上限");

        let exhausted = NotificationManager::notification_content(
            ProviderId::Codex,
            "session",
            100.0,
            NotificationType::Exhausted,
            Language::Chinese,
        );
        assert_eq!(exhausted.0, "额度已用尽");
        assert_eq!(exhausted.1, "Codex 本次会话额度已用尽（100%）");

        let depleted = NotificationManager::notification_content(
            ProviderId::Codex,
            "session",
            100.0,
            NotificationType::SessionDepleted,
            Language::Chinese,
        );
        assert_eq!(depleted.0, "会话额度已用尽");
        assert_eq!(
            depleted.1,
            "Codex 本次会话额度已用尽（剩余 0%），恢复后将再次通知。"
        );

        let restored = NotificationManager::notification_content(
            ProviderId::Codex,
            "session",
            0.0,
            NotificationType::SessionRestored,
            Language::Chinese,
        );
        assert_eq!(restored.0, "会话额度已恢复");
        assert_eq!(restored.1, "Codex 本次会话额度已恢复。");
    }

    #[test]
    fn weekly_thresholds_fire_once_each_and_reset_for_new_cycle() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();

        assert_eq!(
            manager.evaluate(
                ProviderId::Claude,
                "account-a",
                "weekly",
                "2026-07-20T00:00:00Z",
                81.0,
                &settings,
            ),
            Some(NotificationType::HighUsage),
        );
        assert_eq!(
            manager.evaluate(
                ProviderId::Claude,
                "account-a",
                "weekly",
                "2026-07-20T00:00:00Z",
                82.0,
                &settings,
            ),
            None,
        );
        assert_eq!(
            manager.evaluate(
                ProviderId::Claude,
                "account-a",
                "weekly",
                "2026-07-20T00:00:00Z",
                91.0,
                &settings,
            ),
            Some(NotificationType::CriticalUsage),
        );
        assert_eq!(
            manager.evaluate(
                ProviderId::Claude,
                "account-a",
                "weekly",
                "2026-07-20T00:00:00Z",
                92.0,
                &settings,
            ),
            None,
        );
        assert_eq!(
            manager.evaluate(
                ProviderId::Claude,
                "account-a",
                "weekly",
                "2026-07-27T00:00:00Z",
                81.0,
                &settings,
            ),
            Some(NotificationType::HighUsage),
        );
    }

    #[test]
    fn critical_threshold_does_not_fall_back_to_high_in_same_cycle() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();

        assert_eq!(
            manager.evaluate(
                ProviderId::Codex,
                "account-a",
                "session",
                "2026-07-20T05:00:00Z",
                91.0,
                &settings,
            ),
            Some(NotificationType::CriticalUsage),
        );
        assert_eq!(
            manager.evaluate(
                ProviderId::Codex,
                "account-a",
                "session",
                "2026-07-20T05:00:00Z",
                85.0,
                &settings,
            ),
            None,
        );
    }

    #[test]
    fn clearing_provider_high_overrides_effectively_disables_high_notifications() {
        let mut overridden = Settings::default();
        overridden.high_usage_threshold = 100.0;
        overridden.critical_usage_threshold = 100.0;
        overridden.provider_usage_thresholds.insert(
            "codex:session".to_string(),
            crate::settings::UsageThresholdOverride {
                high: Some(80.0),
                critical: None,
            },
        );
        let mut manager = NotificationManager::new();
        assert_eq!(
            manager.evaluate(
                ProviderId::Codex,
                "",
                "session",
                "process-lifetime",
                81.0,
                &overridden,
            ),
            Some(NotificationType::HighUsage),
        );

        overridden.provider_usage_thresholds.clear();
        let mut manager = NotificationManager::new();
        assert_eq!(
            manager.evaluate(
                ProviderId::Codex,
                "",
                "session",
                "process-lifetime",
                81.0,
                &overridden,
            ),
            None,
        );
    }

    #[test]
    fn process_lifetime_cycle_notifies_once_as_dynamic_usage_changes() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();

        assert_eq!(
            manager.evaluate(
                ProviderId::Codex,
                "",
                "session",
                "process-lifetime",
                81.0,
                &settings,
            ),
            Some(NotificationType::HighUsage),
        );
        assert_eq!(
            manager.evaluate(
                ProviderId::Codex,
                "",
                "session",
                "process-lifetime",
                82.0,
                &settings,
            ),
            None,
        );
    }

    #[test]
    fn threshold_reset_state_keeps_only_the_latest_cycle_per_lane() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();
        let base = DateTime::parse_from_rfc3339("2026-07-20T05:00:00Z").unwrap();

        for cycle_index in 0..20 {
            let resets_at =
                (base.to_owned() + Duration::hours(5 * cycle_index)).to_rfc3339();
            let cycle = manager.normalize_threshold_reset_cycle(
                ProviderId::Claude,
                "account-a",
                "session",
                &resets_at,
                Some(300),
            );
            assert_eq!(
                manager.evaluate(
                    ProviderId::Claude,
                    "account-a",
                    "session",
                    &cycle,
                    81.0,
                    &settings,
                ),
                Some(NotificationType::HighUsage),
            );
        }

        assert_eq!(manager.threshold_reset_windows.len(), 1);
        assert_eq!(
            manager
                .sent_notifications
                .iter()
                .filter(|key| {
                    key.0 == ProviderId::Claude
                        && key.1 == "account-a"
                        && key.2 == "session"
                        && key.4.is_threshold_toast()
                })
                .count(),
            1
        );
    }

    #[test]
    fn threshold_reset_state_is_process_local() {
        let mut first_process = NotificationManager::new();
        let first_cycle = first_process.normalize_threshold_reset_cycle(
            ProviderId::Claude,
            "account-a",
            "session",
            "2026-07-20T05:00:29Z",
            Some(300),
        );
        assert_eq!(
            first_process.normalize_threshold_reset_cycle(
                ProviderId::Claude,
                "account-a",
                "session",
                "2026-07-20T05:00:31Z",
                Some(300),
            ),
            first_cycle
        );

        let mut restarted_process = NotificationManager::new();
        assert_eq!(
            restarted_process.normalize_threshold_reset_cycle(
                ProviderId::Claude,
                "account-a",
                "session",
                "2026-07-20T05:00:31Z",
                Some(300),
            ),
            "resets-at:2026-07-20T05:00:31Z"
        );
    }

    #[test]
    fn threshold_reset_jitter_cannot_drift_transitively_into_the_next_window() {
        let mut manager = NotificationManager::new();
        let base = DateTime::parse_from_rfc3339("2026-07-20T05:00:00Z").unwrap();
        let first_cycle = manager.normalize_threshold_reset_cycle(
            ProviderId::Claude,
            "account-a",
            "session",
            &base.to_rfc3339(),
            Some(300),
        );

        let first_jitter = (base.to_owned() + Duration::seconds(59)).to_rfc3339();
        assert_eq!(
            manager.normalize_threshold_reset_cycle(
                ProviderId::Claude,
                "account-a",
                "session",
                &first_jitter,
                Some(300),
            ),
            first_cycle,
            "a sub-minute correction belongs to the anchored cycle"
        );

        let mut observed_cycle = first_cycle.clone();
        for step in 2..=305 {
            let observed = (base.to_owned() + Duration::seconds(59 * step)).to_rfc3339();
            observed_cycle = manager.normalize_threshold_reset_cycle(
                ProviderId::Claude,
                "account-a",
                "session",
                &observed,
                Some(300),
            );
        }

        assert_ne!(
            observed_cycle, first_cycle,
            "successive sub-minute movement must not drag the original anchor across a full window"
        );
    }

    #[test]
    fn pruning_usage_lanes_removes_disabled_and_switched_accounts() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();

        for (provider, account) in [
            (ProviderId::Claude, "old-account"),
            (ProviderId::Codex, "disabled-account"),
        ] {
            let cycle = manager.normalize_threshold_reset_cycle(
                provider,
                account,
                "session",
                "2026-07-20T05:00:00Z",
                Some(300),
            );
            assert_eq!(
                manager.evaluate(
                    provider,
                    account,
                    "session",
                    &cycle,
                    81.0,
                    &settings,
                ),
                Some(NotificationType::HighUsage)
            );
            manager
                .previous_session_percent
                .insert((provider, account.to_string()), 81.0);
        }

        manager.retain_active_usage_lanes(
            &[(
                ProviderId::Claude,
                "new-account".to_string(),
                "session".to_string(),
            )],
            &[ProviderId::Claude],
            &[],
        );

        assert!(manager.threshold_reset_windows.is_empty());
        assert!(manager.previous_session_percent.is_empty());
        assert!(
            manager
                .sent_notifications
                .iter()
                .all(|key| !key.4.is_threshold_toast())
        );
    }

    #[test]
    fn pruning_preserves_an_uncertain_enabled_provider_until_a_good_snapshot() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();
        let cycle = manager.normalize_threshold_reset_cycle(
            ProviderId::Claude,
            "account-a",
            "weekly",
            "2026-07-27T05:00:00Z",
            Some(10080),
        );
        assert_eq!(
            manager.evaluate(
                ProviderId::Claude,
                "account-a",
                "weekly",
                &cycle,
                81.0,
                &settings,
            ),
            Some(NotificationType::HighUsage)
        );

        manager.retain_active_usage_lanes(
            &[],
            &[ProviderId::Claude],
            &[ProviderId::Claude],
        );

        assert_eq!(manager.threshold_reset_windows.len(), 1);
        assert_eq!(
            manager
                .sent_notifications
                .iter()
                .filter(|key| key.4.is_threshold_toast())
                .count(),
            1
        );
    }

    #[test]
    fn pruning_an_active_lane_preserves_current_cycle_dedupe() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();
        let lane = (
            ProviderId::Claude,
            "account-a".to_string(),
            "weekly".to_string(),
        );
        let cycle = manager.normalize_threshold_reset_cycle(
            lane.0,
            &lane.1,
            &lane.2,
            "2026-07-27T05:00:00Z",
            Some(10080),
        );
        assert_eq!(
            manager.evaluate(lane.0, &lane.1, &lane.2, &cycle, 81.0, &settings),
            Some(NotificationType::HighUsage)
        );

        manager.retain_active_usage_lanes(&[lane.clone()], &[ProviderId::Claude], &[]);

        assert_eq!(
            manager.evaluate(lane.0, &lane.1, &lane.2, &cycle, 82.0, &settings),
            None,
            "pruning must not re-arm a still-active cycle"
        );
    }

    #[test]
    fn predictive_pruning_removes_switched_account_and_rearms_when_switching_back() {
        let now = DateTime::from_timestamp(1_800_000_000, 0).unwrap();
        let reset = window(now, Duration::hours(3), 300);
        let risk = pace(false, Some(3600.0));
        let mut manager = NotificationManager::new();

        assert!(manager.record_predictive_observation(
            true,
            ProviderId::Claude,
            "oauth:account-a@example.com",
            PredictiveWarningWindow::Session,
            &reset,
            &risk,
        ));

        manager.retain_active_predictive_lanes(
            &[(
                ProviderId::Claude,
                "oauth:account-b@example.com".to_string(),
                PredictiveWarningWindow::Session,
            )],
            &[],
        );

        assert!(
            manager.predictive_warning_keys.is_empty(),
            "a successful account switch must discard the old account's predictive key"
        );
        assert!(
            manager.record_predictive_observation(
                true,
                ProviderId::Claude,
                "oauth:account-a@example.com",
                PredictiveWarningWindow::Session,
                &reset,
                &risk,
            ),
            "switching back must not be suppressed by stale account state"
        );
    }

    #[test]
    fn predictive_pruning_matches_provider_identity_and_window() {
        let now = DateTime::from_timestamp(1_800_000_000, 0).unwrap();
        let reset = window(now, Duration::hours(3), 300);
        let risk = pace(false, Some(3600.0));
        let mut manager = NotificationManager::new();

        for (provider, identity, warning_window) in [
            (
                ProviderId::Claude,
                "oauth:account-a@example.com",
                PredictiveWarningWindow::Session,
            ),
            (
                ProviderId::Claude,
                "oauth:account-a@example.com",
                PredictiveWarningWindow::Weekly,
            ),
            (
                ProviderId::Codex,
                "oauth:account-a@example.com",
                PredictiveWarningWindow::Session,
            ),
        ] {
            assert!(manager.record_predictive_observation(
                true,
                provider,
                identity,
                warning_window,
                &reset,
                &risk,
            ));
        }

        manager.retain_active_predictive_lanes(
            &[(
                ProviderId::Claude,
                "oauth:account-a@example.com".to_string(),
                PredictiveWarningWindow::Session,
            )],
            &[],
        );

        assert_eq!(manager.predictive_warning_keys.len(), 1);
        let remaining = manager.predictive_warning_keys.iter().next().unwrap();
        assert_eq!(remaining.provider, ProviderId::Claude);
        assert_eq!(remaining.identity, "oauth:account-a@example.com");
        assert_eq!(remaining.window, PredictiveWarningWindow::Session);
    }

    #[test]
    fn predictive_pruning_preserves_lane_during_transient_provider_error() {
        let now = DateTime::from_timestamp(1_800_000_000, 0).unwrap();
        let reset = window(now, Duration::days(3), 10080);
        let risk = pace(false, Some(3600.0));
        let mut manager = NotificationManager::new();

        assert!(manager.record_predictive_observation(
            true,
            ProviderId::Codex,
            "oauth:account-a@example.com",
            PredictiveWarningWindow::Weekly,
            &reset,
            &risk,
        ));

        manager.retain_active_predictive_lanes(&[], &[ProviderId::Codex]);

        assert_eq!(
            manager.predictive_warning_keys.len(),
            1,
            "an uncertain snapshot must retain the current valid predictive lane"
        );
        assert!(!manager.record_predictive_observation(
            true,
            ProviderId::Codex,
            "oauth:account-a@example.com",
            PredictiveWarningWindow::Weekly,
            &reset,
            &risk,
        ));
    }

    #[test]
    fn predictive_warning_notifies_once_until_recovery_then_rearms() {
        let now = DateTime::from_timestamp(1_800_000_000, 0).unwrap();
        let window = window(now, Duration::hours(3), 300);
        let risk = pace(false, Some(3600.0));
        let recovery = pace(true, None);
        let mut manager = NotificationManager::new();

        assert!(manager.record_predictive_observation(
            true,
            ProviderId::Claude,
            "oauth:person@example.com",
            PredictiveWarningWindow::Session,
            &window,
            &risk,
        ));
        assert!(!manager.record_predictive_observation(
            true,
            ProviderId::Claude,
            "oauth:person@example.com",
            PredictiveWarningWindow::Session,
            &window,
            &risk,
        ));
        assert!(!manager.record_predictive_observation(
            true,
            ProviderId::Claude,
            "oauth:person@example.com",
            PredictiveWarningWindow::Session,
            &window,
            &recovery,
        ));
        assert!(manager.record_predictive_observation(
            true,
            ProviderId::Claude,
            "oauth:person@example.com",
            PredictiveWarningWindow::Session,
            &window,
            &risk,
        ));
    }

    #[test]
    fn predictive_warning_reset_jitter_does_not_retrigger() {
        let now = DateTime::from_timestamp(1_800_000_000, 0).unwrap();
        let mut manager = NotificationManager::new();
        let risk = pace(false, Some(3600.0));

        assert!(manager.record_predictive_observation(
            true,
            ProviderId::Codex,
            "oauth:account-a",
            PredictiveWarningWindow::Weekly,
            &window(now, Duration::days(3), 10080),
            &risk,
        ));
        assert!(!manager.record_predictive_observation(
            true,
            ProviderId::Codex,
            "oauth:account-a",
            PredictiveWarningWindow::Weekly,
            &window(now, Duration::days(3) + Duration::minutes(5), 10080),
            &risk,
        ));
    }

    #[test]
    fn predictive_warning_isolates_provider_identity_source_and_window() {
        let now = DateTime::from_timestamp(1_800_000_000, 0).unwrap();
        let reset = window(now, Duration::hours(3), 300);
        let risk = pace(false, Some(3600.0));
        let mut manager = NotificationManager::new();

        for (provider, identity, warning_window) in [
            (
                ProviderId::Claude,
                "cli:person@example.com",
                PredictiveWarningWindow::Session,
            ),
            (
                ProviderId::Claude,
                "oauth:person@example.com",
                PredictiveWarningWindow::Session,
            ),
            (
                ProviderId::Claude,
                "token-account:1",
                PredictiveWarningWindow::Session,
            ),
            (
                ProviderId::Claude,
                "oauth:person@example.com",
                PredictiveWarningWindow::Weekly,
            ),
            (
                ProviderId::Codex,
                "oauth:person@example.com",
                PredictiveWarningWindow::Session,
            ),
        ] {
            assert!(manager.record_predictive_observation(
                true,
                provider,
                identity,
                warning_window,
                &reset,
                &risk,
            ));
        }
    }

    #[test]
    fn predictive_warning_requires_enabled_confident_positive_risk() {
        let now = DateTime::from_timestamp(1_800_000_000, 0).unwrap();
        let reset = window(now, Duration::hours(3), 300);
        let mut manager = NotificationManager::new();

        for (enabled, observation) in [
            (false, pace(false, Some(3600.0))),
            (true, pace(true, None)),
            (true, pace(false, Some(0.0))),
        ] {
            assert!(!manager.record_predictive_observation(
                enabled,
                ProviderId::Claude,
                "oauth:person@example.com",
                PredictiveWarningWindow::Session,
                &reset,
                &observation,
            ));
        }

        assert!(manager.record_predictive_observation(
            true,
            ProviderId::Claude,
            "oauth:person@example.com",
            PredictiveWarningWindow::Session,
            &reset,
            &pace(false, Some(3600.0)),
        ));
    }

    #[test]
    fn session_below_high_does_not_rearm_weekly_high_toast() {
        // Repro for #198: session cool + weekly hot on every refresh used to
        // clear all provider keys on the session call, then re-fire weekly.
        let mut manager = NotificationManager::new();
        let settings = Settings::default();
        assert!(settings.show_notifications);
        assert!((settings.high_usage_threshold - 80.0).abs() < f64::EPSILON);

        let account = "";
        let weekly_key = (
            ProviderId::Claude,
            account.to_string(),
            "weekly".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        );

        manager.check_and_notify(
            ProviderId::Claude,
            account,
            "session",
            "cycle-a",
            20.0,
            &settings,
        );
        manager.check_and_notify(
            ProviderId::Claude,
            account,
            "weekly",
            "cycle-a",
            86.0,
            &settings,
        );
        assert!(manager.sent_notifications.contains(&weekly_key));

        // Simulate several refresh cycles: session still cool, weekly still hot.
        for _ in 0..5 {
            manager.check_and_notify(
                ProviderId::Claude,
                account,
                "session",
                "cycle-a",
                20.0,
                &settings,
            );
            manager.check_and_notify(
                ProviderId::Claude,
                account,
                "weekly",
                "cycle-a",
                86.0,
                &settings,
            );
        }
        assert_eq!(
            manager
                .sent_notifications
                .iter()
                .filter(|key| key == &&weekly_key)
                .count(),
            1,
            "weekly high toast must arm only once while still above threshold"
        );

        // Dropping below the threshold does not re-arm within one reset cycle.
        manager.check_and_notify(
            ProviderId::Claude,
            account,
            "weekly",
            "cycle-a",
            50.0,
            &settings,
        );
        manager.check_and_notify(
            ProviderId::Claude,
            account,
            "weekly",
            "cycle-a",
            86.0,
            &settings,
        );
        assert!(manager.sent_notifications.contains(&weekly_key));
    }

    #[test]
    fn threshold_keys_isolate_session_and_weekly() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();
        let account = "";

        manager.check_and_notify(ProviderId::Claude, account, "session", "cycle-a", 86.0, &settings);
        manager.check_and_notify(ProviderId::Claude, account, "weekly", "cycle-a", 86.0, &settings);

        assert!(manager.sent_notifications.contains(&(
            ProviderId::Claude,
            account.to_string(),
            "session".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        )));
        assert!(manager.sent_notifications.contains(&(
            ProviderId::Claude,
            account.to_string(),
            "weekly".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        )));

        // Cool only session; weekly stays armed.
        manager.check_and_notify(ProviderId::Claude, account, "session", "cycle-a", 10.0, &settings);
        assert!(manager.sent_notifications.contains(&(
            ProviderId::Claude,
            account.to_string(),
            "session".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        )));
        assert!(manager.sent_notifications.contains(&(
            ProviderId::Claude,
            account.to_string(),
            "weekly".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        )));
    }

    /// Mirrors `notify_usage_thresholds` in the Tauri shell: each refresh
    /// calls session then weekly. Confidence pass for #198 over many cycles.
    #[test]
    fn refresh_loop_session_cool_weekly_hot_toasts_once() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();
        let account = "";
        let weekly_high = (
            ProviderId::Claude,
            account.to_string(),
            "weekly".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        );

        let mut weekly_fires = 0usize;
        for _ in 0..30 {
            let before = manager.sent_notifications.contains(&weekly_high);
            // Same order as apps/desktop-tauri/.../providers.rs
            manager.check_and_notify(ProviderId::Claude, account, "session", "cycle-a", 20.0, &settings);
            manager.check_and_notify(ProviderId::Claude, account, "weekly", "cycle-a", 86.0, &settings);
            let after = manager.sent_notifications.contains(&weekly_high);
            if after && !before {
                weekly_fires += 1;
            }
        }

        assert_eq!(
            weekly_fires, 1,
            "weekly high must fire exactly once across 30 refresh cycles"
        );
        assert!(manager.sent_notifications.contains(&weekly_high));
        // Session never armed high while cool.
        assert!(!manager.sent_notifications.contains(&(
            ProviderId::Claude,
            account.to_string(),
            "session".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        )));
    }

    #[test]
    fn threshold_keys_isolate_accounts_on_same_provider() {
        // Two accounts on the same provider can each fire High once for weekly.
        let mut manager = NotificationManager::new();
        let settings = Settings::default();

        let key_a = (
            ProviderId::Claude,
            "account-a".to_string(),
            "weekly".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        );
        let key_b = (
            ProviderId::Claude,
            "account-b".to_string(),
            "weekly".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        );

        manager.check_and_notify(ProviderId::Claude, "account-a", "weekly", "cycle-a", 80.0, &settings);
        manager.check_and_notify(ProviderId::Claude, "account-b", "weekly", "cycle-a", 80.0, &settings);

        assert!(manager.sent_notifications.contains(&key_a));
        assert!(manager.sent_notifications.contains(&key_b));

        // Re-poll both still hot: neither re-fires (still armed, no second insert).
        manager.check_and_notify(ProviderId::Claude, "account-a", "weekly", "cycle-a", 80.0, &settings);
        manager.check_and_notify(ProviderId::Claude, "account-b", "weekly", "cycle-a", 80.0, &settings);
        assert_eq!(
            manager
                .sent_notifications
                .iter()
                .filter(|k| k.0 == ProviderId::Claude
                    && k.2 == "weekly"
                    && k.4 == NotificationType::HighUsage)
                .count(),
            2
        );
    }

    #[test]
    fn account_a_session_cool_does_not_clear_account_b_weekly() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();

        let key_b_weekly = (
            ProviderId::Claude,
            "account-b".to_string(),
            "weekly".to_string(),
            "cycle-a".to_string(),
            NotificationType::HighUsage,
        );

        manager.check_and_notify(ProviderId::Claude, "account-b", "weekly", "cycle-a", 80.0, &settings);
        assert!(manager.sent_notifications.contains(&key_b_weekly));

        // Account A session cool must not clear account B weekly armed state.
        manager.check_and_notify(ProviderId::Claude, "account-a", "session", "cycle-a", 10.0, &settings);
        assert!(
            manager.sent_notifications.contains(&key_b_weekly),
            "account A session cool must not clear account B weekly threshold key"
        );

        // Account A weekly cool must also not clear account B.
        manager.check_and_notify(ProviderId::Claude, "account-a", "weekly", "cycle-a", 10.0, &settings);
        assert!(manager.sent_notifications.contains(&key_b_weekly));
    }

    #[test]
    fn session_transition_isolates_accounts() {
        let mut manager = NotificationManager::new();
        let settings = Settings::default();

        let depleted_a = (
            ProviderId::Claude,
            "account-a".to_string(),
            "session".to_string(),
            String::new(),
            NotificationType::SessionDepleted,
        );
        let depleted_b = (
            ProviderId::Claude,
            "account-b".to_string(),
            "session".to_string(),
            String::new(),
            NotificationType::SessionDepleted,
        );

        manager.check_session_transition(ProviderId::Claude, "account-a", 50.0, &settings);
        manager.check_session_transition(ProviderId::Claude, "account-a", 100.0, &settings);
        assert!(manager.sent_notifications.contains(&depleted_a));
        assert!(!manager.sent_notifications.contains(&depleted_b));

        // Account B still has quota; restoring A must not affect B's lane.
        manager.check_session_transition(ProviderId::Claude, "account-b", 40.0, &settings);
        manager.check_session_transition(ProviderId::Claude, "account-a", 20.0, &settings);
        assert!(!manager.sent_notifications.contains(&depleted_a));
        assert!(!manager.sent_notifications.contains(&depleted_b));

        // Account B can still fire depleted independently.
        manager.check_session_transition(ProviderId::Claude, "account-b", 100.0, &settings);
        assert!(manager.sent_notifications.contains(&depleted_b));
    }
}
