# Upstream baseline

- Repository: https://github.com/nesszer/Win-CodexBar
- Commit: 95097f0
- Release: 0.43.0
- Upgrade rule: provider/auth/rate-limit semantics remain unchanged.

## Reproducibility record

- Isolated worktree branch: `feat/zh-cn-usage-widget`
- Verified HEAD: `95097f09f62377fdab0b035a3772599e6f1f1c4d`
- Frontend baseline: `pnpm test` passed (32 test files, 157 tests); `pnpm build` passed.
- Rust verification: not run in this Linux environment because `cargo` is unavailable. Running `cargo test --manifest-path rust/Cargo.toml` and `cargo test --manifest-path apps/desktop-tauri/src-tauri/Cargo.toml` on a Windows/Rust build machine is a release gate.
