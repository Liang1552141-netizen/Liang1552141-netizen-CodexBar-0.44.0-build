# Crimson Eclipse Widget Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the selected Simplified-Chinese “Crimson Eclipse” Codex quota widget with a lightweight animated original character, local weather, and drag-safe performance.

**Architecture:** Keep provider data in the existing `CodexWidgetModel`, add isolated presentation helpers for the primary quota and weather, and keep animation state outside the quota refresh path. The React surface owns rendering; the current Tauri drag lifecycle remains the single source of truth for suspending visual updates.

**Tech Stack:** React 18, TypeScript 5.6, CSS compositor animations, Vitest, Tauri 2.

## Global Constraints

- Do not add runtime dependencies.
- Use Simplified Chinese for widget copy except product/model names.
- Weather failure and character failure must not block quota rendering.
- Suspend character animation and decorative transitions while dragging.
- Respect `prefers-reduced-motion`.
- Do not use continuous canvas, video, backdrop blur, or particle loops.

---

### Task 1: Derive the dashboard view model

**Files:**
- Create: `apps/desktop-tauri/src/usageWidget/dashboardModel.ts`
- Create: `apps/desktop-tauri/src/usageWidget/dashboardModel.test.ts`

**Interfaces:**
- Consumes: `CodexWidgetModel`
- Produces: `buildDashboardView(model: CodexWidgetModel): DashboardView`

- [ ] **Step 1: Write failing tests** for choosing weekly quota as the primary ring, falling back to session quota, never fabricating zero, and formatting plan/status values.
- [ ] **Step 2: Run** `pnpm test -- dashboardModel.test.ts` and verify failure.
- [ ] **Step 3: Implement** typed `DashboardView`, `DashboardQuota`, and `buildDashboardView`.
- [ ] **Step 4: Run** `pnpm test -- dashboardModel.test.ts` and verify pass.
- [ ] **Step 5: Commit** with `feat: derive crimson widget dashboard model`.

### Task 2: Add cached coarse-location weather

**Files:**
- Create: `apps/desktop-tauri/src/usageWidget/weather.ts`
- Create: `apps/desktop-tauri/src/usageWidget/weather.test.ts`
- Create: `apps/desktop-tauri/src/usageWidget/useWeather.ts`
- Create: `apps/desktop-tauri/src/usageWidget/useWeather.test.tsx`
- Modify: `apps/desktop-tauri/src-tauri/tauri.conf.json`

**Interfaces:**
- Produces: `WeatherSnapshot`, `WeatherState`, `fetchWeather(signal, fetcher)`, `useWeather({ enabled })`

- [ ] **Step 1: Write failing tests** for 5-second timeout, 30-minute cache, parse success, malformed response, offline fallback, and disabled state.
- [ ] **Step 2: Run** `pnpm test -- weather.test.ts useWeather.test.tsx` and verify failure.
- [ ] **Step 3: Implement** a single coarse-IP weather request with `AbortController`, local cache, no precise geolocation permission, and the fallback label `天气暂不可用`.
- [ ] **Step 4: Allow only the exact HTTPS weather endpoint** in Tauri `connect-src`; do not broaden CSP with wildcards.
- [ ] **Step 5: Run** the focused tests and `pnpm run build`.
- [ ] **Step 6: Commit** with `feat: add isolated cached weather`.

### Task 3: Create the lightweight character asset and controller

**Files:**
- Create: `apps/desktop-tauri/src/assets/crimson-assistant.webp`
- Create: `apps/desktop-tauri/src/usageWidget/CrimsonAssistant.tsx`
- Create: `apps/desktop-tauri/src/usageWidget/CrimsonAssistant.test.tsx`

**Interfaces:**
- Consumes: `paused: boolean`
- Produces: `CrimsonAssistant`

- [ ] **Step 1: Generate and inspect** one original character asset matching the selected concept, sized to its measured slot with no copied insignia.
- [ ] **Step 2: Write failing tests** for static fallback, reduced-motion pause, hidden-document pause, drag pause, and accessible decorative semantics.
- [ ] **Step 3: Run** `pnpm test -- CrimsonAssistant.test.tsx` and verify failure.
- [ ] **Step 4: Implement** blink/respiration/hair/gaze layers using transforms and opacity only; keep React renders event-driven.
- [ ] **Step 5: Run** focused tests and inspect the asset at 1× and 1.5× scale.
- [ ] **Step 6: Commit** with `feat: add drag-safe crimson assistant`.

### Task 4: Rebuild the expanded dashboard

**Files:**
- Modify: `apps/desktop-tauri/src/usageWidget/ExpandedUsageDashboard.tsx`
- Modify: `apps/desktop-tauri/src/usageWidget/ExpandedUsageDashboard.test.tsx`
- Modify: `apps/desktop-tauri/src/usageWidget/usageWidget.css`
- Modify: `apps/desktop-tauri/src/floatbar/FloatBar.tsx`
- Modify: `apps/desktop-tauri/src/floatbar/FloatBar.test.tsx`

**Interfaces:**
- `ExpandedUsageDashboard` additionally consumes `visualsPaused: boolean`

- [ ] **Step 1: Write failing component tests** for Chinese title, primary ring, model, plan, reset, weather, unavailable weather, refresh/settings actions, and paused animation propagation.
- [ ] **Step 2: Run** the expanded-dashboard and floatbar tests and verify failure.
- [ ] **Step 3: Implement** the selected layout using semantic HTML, real buttons, existing drag lifecycle, and `buildDashboardView`.
- [ ] **Step 4: Implement** matte carbon/black-red tokens, eclipse ring, restrained edge lighting, focus states, and reduced-motion rules in CSS.
- [ ] **Step 5: Connect** `visualsPaused` to the existing native drag suspend/resume events without adding timers or duplicate refresh loops.
- [ ] **Step 6: Run** focused tests, full `pnpm test`, `pnpm run check-locale`, and `pnpm run build`.
- [ ] **Step 7: Commit** with `feat: redesign quota widget as crimson eclipse`.

### Task 5: Visual, interaction, and Windows release verification

**Files:**
- Create: `design-qa.md`
- Modify: `docs/WIDGET_WINDOWS_TEST.md`

**Interfaces:**
- Produces: verified screenshots and release-ready source state.

- [ ] **Step 1: Start** the Vite preview on port 4173 and open `http://terminal.local:4173/` in the cloud browser.
- [ ] **Step 2: Capture** the same expanded state as the selected reference and compare the reference plus prototype together.
- [ ] **Step 3: Test** refresh, settings, collapse, keyboard focus, reduced motion, weather failure, and animation pause.
- [ ] **Step 4: Fix** every P0/P1/P2 issue and repeat capture until `design-qa.md` says `final result: passed`.
- [ ] **Step 5: Run** `pnpm test`, `pnpm run build`, Rust formatting/tests available in the environment, and the Windows GitHub Actions release build.
- [ ] **Step 6: Update** the Windows test guide with weather, animation, and 10-second drag acceptance checks.
- [ ] **Step 7: Commit** with `test: verify crimson eclipse widget`.
