# Task 3: Codex usage widget view model

## Delivered

- Added a pure `buildCodexWidgetModel` mapper for Codex provider snapshots.
- Treats `primary` as the session quota and `secondary` as the weekly quota.
- Preserves snapshot usage and reset values when a refresh error marks the model stale.
- Uses weekly remaining quota for tone when available, otherwise session remaining.
- Applies warning at remaining `<= 20` and critical at remaining `<= 10`.

## Tests

- RED: `CI=true XDG_DATA_HOME=/tmp/codex-pnpm-data pnpm test -- src/usageWidget/model.test.ts` failed because `./model` did not exist.
- Focused: `CI=true XDG_DATA_HOME=/tmp/codex-pnpm-data pnpm exec vitest run src/usageWidget/model.test.ts` — 8 passed.
- Full frontend: `CI=true XDG_DATA_HOME=/tmp/codex-pnpm-data pnpm test` — 33 files, 165 tests passed.
- Build: `CI=true XDG_DATA_HOME=/tmp/codex-pnpm-data pnpm build` — passed.

## Self-review

- Confirmed fixtures use the actual non-nullable `ProviderUsageSnapshot.primary` bridge type.
- Confirmed the mapper only reads its arguments and has no network, CLI, or Tauri calls.
- Confirmed no whitespace errors with `git diff --check`.

## Notes

- The existing full suite emits pre-existing React `act(...)` and locale-missing-key warnings, but exits successfully.
