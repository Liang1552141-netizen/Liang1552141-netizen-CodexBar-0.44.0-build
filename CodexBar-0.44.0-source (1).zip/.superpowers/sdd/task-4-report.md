# Task 4: Simplified Chinese widget localization

## Delivered

- Added the 11 `Widget*` variants to Rust's `locale_keys!` source of truth and to TypeScript `ALL_LOCALE_KEYS`.
- Added all 11 widget entries to every supported Fluent catalog. `zh-CN.ftl` contains the required Simplified Chinese copy; other catalogs use explicit English fallback text.
- `apps/desktop-tauri/scripts/check-locale-drift.mjs` now reads `rust/src/locale/zh-CN.ftl` directly, checks all 11 required values exactly, and rejects `$duration` anywhere in a Fluent catalog. It also retains the Rust/TypeScript key drift and all-catalog `WidgetResetIn` compatibility checks.
- `keys.test.ts` tests only that `ALL_LOCALE_KEYS` contains the 11 required keys. It does not assert values it does not read from Fluent files.

## Checker regression proof

1. Replaced `WidgetTitle = Codex 用量` with `WidgetTitle = 临时错误` in `rust/src/locale/zh-CN.ftl`.
2. Ran `node scripts/check-locale-drift.mjs`; it exited 1 with:
   `zh-CN.ftl WidgetTitle must equal "Codex 用量", got "临时错误"`.
3. Restored the exact original value. No temporary catalog change remains.

## Verification

- `node scripts/check-locale-drift.mjs` — passed: 686 Rust and TypeScript locale keys match, and the `zh-CN` widget copy was verified.
- `./node_modules/.bin/vitest run src/i18n/keys.test.ts` — passed: 1 file, 2 tests.
- `./node_modules/.bin/vitest run` — passed: 33 files, 166 tests. It emits pre-existing React `act(...)` and locale-missing-key test warnings.
- `./node_modules/.bin/tsc --noEmit && ./node_modules/.bin/vite build` — passed.
- `git diff --check` — passed with no whitespace errors.

## Environment note

- `cargo` is unavailable in this environment, so Rust tests, formatting, and Clippy cannot be run.
