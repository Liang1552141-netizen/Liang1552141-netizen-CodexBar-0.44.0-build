# Task 8 Report — Tiered quota alerts and settings UI

## Delivered

- Extended threshold notification dedupe to
  `provider/account/window/reset-cycle/NotificationType`.
- Added a stable reset-cycle selector at the Tauri call site: ISO `resets_at`
  first, stable `reset_description` second, and one process-lifetime fallback
  lane when neither exists.
- Kept High, Critical, and Exhausted as independent once-per-cycle tiers while
  preventing a Critical/Exhausted cycle from later falling back to High.
- Preserved the existing Windows toast implementation.
- Added usage-widget settings for emerald/deep-blue/system theme, pinned state,
  smart topmost behavior, and fullscreen auto-hide.
- Added quota-alert controls for global notifications and the default 80%/90%
  used thresholds, presented in Simplified Chinese as 20%/10% remaining.
- Added localized widget settings copy to all six locale resources and exact
  Simplified Chinese labels.

## TDD evidence

- RED: the new React tests failed because the widget policy controls and
  accessible Chinese quota-alert toggles did not exist.
- GREEN focused: `pnpm exec vitest run src/floatbar/SettingsSection.test.tsx src/surfaces/settings/tabs/GeneralTab.test.tsx`
  — 2 files, 10 tests passed.
- Full frontend: `pnpm test` — 35 files, 203 tests passed.
- Locale: `pnpm run check-locale` — 698 Rust/TypeScript keys matched; zh-CN
  widget copy verified.
- Build: `pnpm run build` — TypeScript and Vite production build passed.
- Diff hygiene: `git diff --check` passed.

## Environment limitation

Rust regression tests, `cargo fmt`, and `cargo clippy` were not runnable because
this environment has no `cargo`, `rustc`, or `rustfmt` binary. The Rust unit
tests and all call-site updates are included for execution in a Rust-enabled
environment.
