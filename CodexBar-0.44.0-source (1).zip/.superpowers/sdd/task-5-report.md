# Task 5: Emerald Codex usage widget

## Delivered

- Added `MiniUsageCard` at the required 395 × 82 logical size with weekly-first remaining usage, reset text, localized sync/error/empty states, a non-draggable expand control, and draggable blank regions.
- Added `ExpandedUsageDashboard` at the required 420 × 520 logical size with session and weekly quota cards, plan, update time, status, pace summary, localized empty states, and pin/refresh/collapse UI callbacks.
- Added shared widget CSS tokens for `emerald`, `deepBlue`, and `system` themes; `ok`, `warning`, `critical`, and `offline` tones; and `prefers-reduced-motion` handling without continuous animation.
- Replaced FloatBar's provider-pill calculations with composition of `useProviders`, `buildCodexWidgetModel`, `MiniUsageCard`, and `ExpandedUsageDashboard`.
- Preserved `useProviders({ refreshOnMount: false })`, the existing stale-aware background refresh interval, detached settings updates, native resizing, and native window drag behavior.
- Removed the legacy local-cost scan and all duplicate usage/tone presentation calculations from FloatBar. No network, CLI, provider, auth, or refresh-core implementation was added.

## TDD evidence

- RED (components): the two new component suites failed because `MiniUsageCard` and `ExpandedUsageDashboard` did not exist.
- GREEN (components): `MiniUsageCard.test.tsx` and `ExpandedUsageDashboard.test.tsx` passed all 5 component tests.
- RED (composition): the new FloatBar suite ran against the legacy pill implementation; 4 of 5 tests failed because the widget surfaces and controls were absent, while the preserved stale-refresh test already passed.
- GREEN (focused): `pnpm exec vitest run src/usageWidget src/floatbar/FloatBar.test.tsx` passed 4 files and 18 tests.

## Final verification

- `pnpm test` — passed: 35 files, 162 tests. The suite still emits pre-existing React `act(...)` and intentional locale-missing-key warnings.
- `pnpm check-locale` — passed: 686 Rust and TypeScript locale keys match; the Simplified Chinese widget copy is verified.
- Initial `pnpm build` found one TypeScript null-narrowing error in the new quota reset line after tests passed. The line was changed to safe optional access.
- Fresh `pnpm build` after that fix — passed: TypeScript check and Vite production build, 159 modules transformed.
- `git diff --check` — passed.

## Self-review

- All semantic user-visible component copy uses `t(LocaleKey)`; percentages, timestamps, reset descriptions, and plan names are model data rather than hardcoded interface strings.
- Buttons carry no `data-tauri-drag-region`, and FloatBar's mouse handler excludes buttons, links, form fields, and button roles before calling `startDragging()`.
- The presentation components have no Tauri, network, CLI, auth, provider, or refresh imports.
- Pin state changes persist through `updateSettings`; refresh and collapse only forward the callbacks owned by the composition layer.
- No dependencies or complex/continuous animations were added.

## Important review fixes

- Replaced the `system` theme's inherited system colors with explicit light and dark token sets under `prefers-color-scheme`, so the widget follows the OS independently of the app's forced `theme` setting.
- Mapped all seven pace stages to their exact existing `DetailPace*` locale keys; ahead stages no longer render as on-track.
- Connected the pin control to `updateSettings({ widgetPinned })`, initializes it from the settings snapshot, and continues to reload both theme and pin state after detached-window configuration events. Task 6 remains responsible for native topmost and auto-hide policy.
- Replaced the decorative settings footer text with a keyboard-accessible button that calls `openSettingsWindow("general")` through the FloatBar composition layer.
- Added the Rust-locale-equivalent Language-to-BCP-47 mapping and formats `updatedAt` with the active app UI language rather than the host's default locale.
- Added focused coverage for all four tones, system theme independence, signed-out auth errors, a missing weekly quota, exact ahead/behind/on-track pace labels, persisted/config-synchronized pin state, settings navigation, and Chinese app-language date formatting on an English host.

## Review verification

- RED: 9 new regression checks failed against the reviewed implementation for the expected missing behaviors.
- Focused GREEN: `vitest run src/usageWidget src/floatbar/FloatBar.test.tsx` passed 4 files and 28 tests.
- Full frontend suite (run once): `npm test -- --run` passed 35 files and 172 tests. Output retains the pre-existing React `act(...)` and intentional missing-locale-key warnings.
- Locale drift: `node scripts/check-locale-drift.mjs` passed with 686 Rust/TypeScript keys and verified zh-CN widget copy.
- Production build: `npm run build --ignore-scripts` passed TypeScript and Vite, transforming 160 modules.
- `git diff --check` passed.

## Final cross-window sync review

- Routed `widgetTheme` and `widgetPinned` through both `SettingsUpdate::notifies_float_bar()` and the float-bar `SettingsPatch`. Updates from another window now emit `float-bar-config-changed`, after which FloatBar re-reads `SettingsSnapshot` as designed.
- Added Rust command/DTO tests for camelCase update deserialization, the specialized notification decision, patch payload mapping/application, and `SettingsSnapshot` serialization of both widget fields.
- Replaced the FloatBar test's incorrect mocked event name with the real frontend constant and added static frontend/backend contract checks for the event name, Rust DTO mapping, notification predicate, and float-bar patch mapping.
- Expanded the pace-label parameterized test to all seven stages. The exhaustive `Record<PaceSnapshot["stage"], LocaleKey>` remains the compile-time guard for future stage additions.
- Re-reviewed the explicit light/dark `system` media token sets. A proposed CSS `?raw` Vitest check was dropped because this repository's Vitest CSS configuration replaces CSS imports with an empty string; no test-runner configuration or filesystem permissions were broadened.
- Corrected the stale self-review statement: pin state is persisted through `updateSettings`, not held only in local UI state.

### Final verification

- RED: the new static backend-routing checks failed for `widget_theme` and `widget_pinned` against the reviewed implementation, directly exposing the missing specialized patch mapping.
- Focused GREEN: `vitest run src/types/bridge.test.ts src/usageWidget src/floatbar/FloatBar.test.tsx` passed 5 files and 40 tests.
- Full frontend suite (run once): `vitest run` passed 35 files and 181 tests. Output retains the pre-existing React `act(...)` and intentional missing-locale-key warnings.
- Locale drift: `node scripts/check-locale-drift.mjs` passed with 686 Rust/TypeScript keys and verified zh-CN widget copy.
- Production build: `npm run build --ignore-scripts` passed TypeScript and Vite, transforming 160 modules.
- Rust focused test command was attempted, but this environment has no `cargo` executable (`cargo: command not found`); the Rust tests could not be executed here.
