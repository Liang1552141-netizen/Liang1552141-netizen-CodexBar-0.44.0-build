# Task 6: Native usage widget window policy

## Delivered

- Added the pure Rust `widget_policy` state machine with `WidgetState`, `WidgetEvent`, `WidgetAction`, and `decide`.
- Registered the fixed Tauri commands `expand_usage_widget`, `collapse_usage_widget`, `set_usage_widget_pinned`, `begin_usage_widget_drag`, and `end_usage_widget_drag`.
- Moved mini/expanded sizing into native commands at exactly 395 × 82 and 420 × 520 logical pixels. Startup, tray reopen, and settings-enabled reopen normalize the widget to the mini size.
- Persisted pin changes through `Settings`, initialized native policy state from persisted settings, and synchronized policy state when another settings surface changes `widgetPinned`.
- Routed floatbar `Focused(false)` through the pure policy. Only an unpinned, non-dragging widget collapses; pinned or actively dragged widgets stay visible.
- Added native suspended/resumed visual-update events around window drag. The React surface continues provider refresh/event ingestion while caching the newest model, then commits that model once when drag ends.
- Kept all interactive controls outside the drag gesture and centralized the new native event listeners in one effect with cleanup.
- Did not add fullscreen detection or any Task 7 behavior.

## TDD evidence

- Rust RED was written first in `widget_policy.rs` for focus-loss, pin, and drag decisions.
- The required command `cargo test --manifest-path apps/desktop-tauri/src-tauri/Cargo.toml widget_policy` was attempted before implementation and failed with exit 127 because this environment has no `cargo` executable. The complete Rust tests remain in source, but no Rust test pass is claimed.
- Frontend RED: the focused FloatBar suite failed for the expected missing native expand/collapse, pin, drag lifecycle, focus-collapse event, and visual-model suspension behavior.
- Focused GREEN: `npm test -- --run src/types/bridge.test.ts src/usageWidget src/floatbar` passed 6 files and 53 tests.

## Final verification

- `npm test -- --run` — passed once: 35 files and 193 tests. Output retains the repository's pre-existing React `act(...)` and intentional missing-locale-key warnings.
- `npm run check-locale` — passed: 686 Rust/TypeScript locale keys match and Simplified Chinese widget copy is verified.
- `npm run build --ignore-scripts` — passed: TypeScript checking and Vite production build, 160 modules transformed.
- Static Rust/API contract tests verify all five command definitions, `generate_handler!` registrations, exact native sizes, and Rust/TypeScript event-name parity.
- `git diff --check` — passed.
- Rust tests, `cargo fmt`, and `cargo clippy` could not run because `cargo`/Rust tooling is unavailable in this environment; Rust correctness was reviewed statically only.

## Self-review

- Policy locking is brief and never spans window resizing, event emission, settings I/O, or provider refresh.
- Settings persistence runs through `spawn_blocking`; native expand/collapse work is dispatched off the UI thread, and focus-loss collapse is scheduled on the async runtime.
- Dragging pauses only React model commits. The existing `refreshProvidersIfStale` timer and `useProviders` listeners continue without branching on drag state.
- The frontend uses one listener registration per event and disposes every listener on unmount.
- The resume handler is idempotent, so whichever arrives first—the native resumed event or the command-response fallback—commits the newest cached model exactly once.
- Buttons, links, form controls, and button roles return before `begin_usage_widget_drag`, so controls do not initiate native dragging.

## Review-unblock follow-up

- Corrected the Windows interaction policy: the ordinary interactive floatbar
  clears `WS_EX_NOACTIVATE` (and `WS_EX_TRANSPARENT`) so it can acquire focus
  and later deliver `Focused(false)`; only click-through mode sets both flags.
  The `SWP_NOACTIVATE` flags used by topmost/frame `SetWindowPos` calls remain
  unchanged and are limited to non-activating z-order/style updates.
- Added a pure extended-style helper with Rust unit cases for interactive and
  click-through modes, plus a passing TypeScript static contract test because
  Rust tooling is unavailable in this environment.
- Removed every `data-tauri-drag-region` attribute from `FloatBar`,
  `MiniUsageCard`, and `ExpandedUsageDashboard`. Dragging now has one path only:
  `beginUsageWidgetDrag` -> `startDragging` -> `endUsageWidgetDrag`, with
  interactive controls filtered before the sequence starts.
- Replaced aggregate listener cleanup with independent promise cleanup. Each
  registration gets an immediate rejection handler, and each successful
  listener is independently unlistened on unmount even if another registration
  rejects. The regression test delays unmount after one rejection, verifies the
  other four unlisteners run, and completes without an unhandled rejection.
- Preserved all five Task 6 commands, exact 395 x 82 / 420 x 520 native sizes,
  persisted pin behavior, and stale-aware background refresh. No Task 7 policy
  was added or modified.

### Follow-up verification

- Focused RED: 4 expected failures across the Win32 interaction contract and
  the three automatic drag-region checks; the listener scenario also exposed
  the expected unhandled rejection from aggregate cleanup.
- Focused GREEN: 4 files, 44 tests passed. The strengthened listener-only rerun
  passed 10 tests with rejection occurring before delayed unmount.
- `npm test -- --run`: passed once, 35 files and 195 tests. Existing React
  `act(...)` and intentional missing-locale-key warnings remain unchanged.
- `npm run check-locale`: passed; 686 Rust/TypeScript locale keys match and the
  Simplified Chinese widget copy is verified.
- `npm run build --ignore-scripts`: passed; TypeScript checking and Vite build
  completed with 160 modules transformed.
- `git diff --check`: passed.
- `cargo --version`: failed with exit 127 (`cargo: command not found`), so Rust
  tests, `cargo fmt`, and `cargo clippy` could not be run and are not claimed.
