# Task 7 Report

## Review fixes

- Replaced eager `previous` mutation with `last_applied` / `dirty` two-phase policy state. Main-thread work acknowledges only after the target window exists and topmost, hide/show, and visibility verification succeed; missing windows, dispatch failures, and operation failures retry on the next 500 ms tick.
- `ShowWindow`'s previous-visibility return value is ignored; success is verified with `window.is_visible()` after `SW_SHOWNOACTIVATE`.
- `RestoreState` now captures `was_visible` plus the exact physical window position, size, and monitor bounds. Restore locks are held only to copy/take/replace state, never across geometry I/O or window operations; failures put taken state back.
- Restore selects the still-connected original monitor by its captured physical bounds. Only a missing original monitor falls back to current/primary/first, followed by physical work-area clamping. Persisted logical geometry remains a compatibility fallback and is never tried at every candidate monitor scale.
- Added pure policy retry/ack tests and physical-monitor identity tests covering a 100% primary plus 150% secondary display.

## Verification

- Focused frontend/static contract: `npm test -- --run src/types/bridge.test.ts` — 24 tests passed.
- Full frontend suite (run once): `npm test -- --run` — 35 files, 200 tests passed. Existing React `act(...)` and intentional missing-locale-key warnings remain.
- Locale: `npm run check-locale` — 686 keys matched; zh-CN widget copy verified.
- Production build: `CI=true XDG_DATA_HOME=/tmp/codex-pnpm-data npm run build` — TypeScript and Vite build passed (160 modules).
- Rust focused/full/build/fmt/clippy: unavailable because neither `cargo`, `rustc`, nor `rustfmt` is installed in this environment. The attempted focused command failed with `/bin/bash: cargo: command not found`.
- `git diff --check` — passed.
