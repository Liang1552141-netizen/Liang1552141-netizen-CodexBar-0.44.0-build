# Win-CodexBar 0.44.0 中文用量小组件升级版

[English](./README.md) | [简体中文](./README.zh-CN.md) | [繁體中文（臺灣）](./README.zh-TW.md) | [日本語](./README.ja-JP.md) | [한국어](./README.ko-KR.md) | [Español mexicano](./README.es-MX.md)

Win-CodexBar 是 [CodexBar](https://github.com/steipete/CodexBar) 的 Windows 移植版。本仓库的 **0.44.0 中文用量小组件升级版**在官方 Win-CodexBar 0.43.0 基线上增加了默认简体中文、Codex 用量悬浮卡、分级额度提醒和 Windows 窗口恢复策略。桌面端使用 Tauri + React，共享后端和 CLI 使用 Rust。

> 发布状态：0.44.0 的代码和发布配置已经准备，但只有 GitHub Release 真正出现四个 0.44.0 资产并完成 Windows 验证后才算可下载版本。不要把 Winget 中的稳定版误认为本升级版；0.44.0 的 Winget manifest 在正式发布并审核通过前并不存在。

<p align="center">
  <img src="docs/images/tray-panel.png" width="280" alt="托盘面板 — 服务商网格与 Codex 用量"/>
  &nbsp;&nbsp;
  <img src="docs/images/settings-providers.png" width="480" alt="设置 — 服务商选项卡"/>
</p>

## 0.44.0 重点

- 新安装默认使用简体中文，已有用户的语言选择不会被覆盖。
- 新增 Codex 迷你用量卡和展开仪表盘，展示 5 小时/每周额度、剩余百分比、重置时间、同步状态和用量节奏。
- 支持翡翠绿、深海蓝、跟随系统三种小组件主题，以及固定、智能置顶和全屏自动隐藏。
- 拖动时暂停视觉提交；失焦、固定、收起、显示器拔插和全屏恢复由独立窗口策略处理。
- 剩余 20% 和 10% 时分级提醒；同一服务商、账户、额度窗口和重置周期的每个阈值只提醒一次。
- 数据刷新失败时保留上次成功结果；Codex 注销时明确提示在 PowerShell 运行 `codex login`，登录完成后可重试刷新。
- 保留 Win-CodexBar 的多服务商托盘面板、Cookie/API Key/OAuth 凭据管理、Windows DPAPI 保护和 CLI。

## 安装

### 安装包

正式发布后，从 [GitHub Releases](https://github.com/Finesssee/Win-CodexBar/releases) 的 `v0.44.0` 页面下载：

- `CodexBar-0.44.0-Setup.exe`
- `CodexBar-0.44.0-Setup.exe.sha256`

在下载目录校验后运行安装程序：

```powershell
$expected = (Get-Content .\CodexBar-0.44.0-Setup.exe.sha256).Split()[0]
$actual = (Get-FileHash .\CodexBar-0.44.0-Setup.exe -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected.ToLowerInvariant()) { throw "SHA-256 校验失败" }
.\CodexBar-0.44.0-Setup.exe
```

安装包安装到当前用户目录，并包含桌面应用、控制台 CLI、开始菜单快捷方式、WebView2 Runtime 和 Visual C++ Runtime 引导。

### 便携版

下载 `CodexBar-0.44.0-portable.exe` 和对应的 `.sha256`，放到可写目录后校验并运行：

```powershell
$expected = (Get-Content .\CodexBar-0.44.0-portable.exe.sha256).Split()[0]
$actual = (Get-FileHash .\CodexBar-0.44.0-portable.exe -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected.ToLowerInvariant()) { throw "SHA-256 校验失败" }
.\CodexBar-0.44.0-portable.exe
```

便携版不写入安装器/卸载器记录，也不会安装系统前置组件，但仍会把用户设置和受保护凭据保存到 Windows 用户配置目录。机器必须已有 Microsoft Edge WebView2 Runtime 和 Microsoft Visual C++ Runtime。

### Winget

先查看 Winget 当前实际提供的版本：

```powershell
winget show --id Finesssee.Win-CodexBar --exact --versions
```

只有输出明确列出 `0.44.0` 时，下面的命令才会安装本升级版：

```powershell
winget install --id Finesssee.Win-CodexBar --exact --version 0.44.0 --source winget
```

在 0.44.0 manifest 尚未发布或仍在审核时，请使用上面的 GitHub 安装包/便携版流程，不要省略版本确认。

## 首次登录

1. 启动 CodexBar；应用默认驻留在系统托盘。
2. 点击托盘图标，打开 **设置 → 服务商**，启用 Codex 和其他需要的服务商。
3. Codex 用户先在 PowerShell 运行 `codex login` 完成 Codex CLI 登录，然后在 Codex 服务商页面刷新。若界面提示运行 `codex login`，请先在 PowerShell 完成该命令，再点击“重试”；“重试”只刷新用量，不会代替 CLI 登录。
4. Cookie 服务商在对应详情页选择 **浏览器 Cookies → 导入**；支持 Windows 上的 Chrome、Edge、Brave 和 Firefox。自动导入不可用时再使用手动 Cookie。
5. API Key 服务商在对应详情页填写密钥。密钥和手动 Cookie 只保存在当前用户本机。

## 使用悬浮用量卡

在 **设置 → 菜单 → 悬浮栏** 中启用悬浮栏。小组件操作如下：

- 拖动迷你卡空白区域移动窗口；展开按钮不属于拖动区域。
- 点击右侧 `›` 展开 Codex 详细仪表盘。
- 在展开视图中点击 `↻` 手动刷新，点击图钉固定/取消固定，点击 `−` 收起。
- 未固定时，失去焦点会自动收起；拖动期间不会因失焦而收起。
- 开启“智能置顶”后，小组件只在需要时保持在其他窗口上方。
- 开启“全屏时自动隐藏”后，全屏视频或游戏期间隐藏，退出全屏后恢复原位置且不主动抢焦点。
- 更换或拔插显示器后，保存位置会被校正到当前可见工作区。

### 主题

- 应用主题：**设置 → 通用 → 外观**，选择自动（跟随系统）、浅色或深色。
- 小组件主题：**设置 → 菜单 → 额度小组件 → 小组件主题**，选择翡翠绿、深海蓝或跟随系统。

### 通知

前往 **设置 → 通知**：

- 打开“用量通知”总开关。
- “高用量提醒”在已用 80%（剩余 20%）时提醒。
- “严重用量提醒”在已用 90%（剩余 10%）时提醒。
- 可单独开启声音和调整音量。

提醒按服务商、账户、额度窗口、重置周期和阈值去重；一个周期内 20% 与 10% 各最多提醒一次，新周期重新生效。

## 常见问题

### 刷新失败或代理错误

刷新失败时小组件会继续显示上次成功数据，并标注更新失败。可按以下顺序排查：

1. 从托盘菜单“立即刷新”，确认是单个服务商还是全部服务商失败。
2. 在浏览器中确认对应服务商可访问，并检查 VPN、公司代理、防火墙和 TLS 检查软件。
3. 使用显式 HTTP 代理时，从同一个 PowerShell 会话设置标准代理环境变量并启动应用：

   ```powershell
   $env:HTTP_PROXY = "http://proxy.example:8080"
   $env:HTTPS_PROXY = "http://proxy.example:8080"
   & "$env:LOCALAPPDATA\Programs\CodexBar\codexbar.exe" menubar
   ```

4. 要排除代理变量，退出托盘程序后运行：

   ```powershell
   Remove-Item Env:HTTP_PROXY -ErrorAction SilentlyContinue
   Remove-Item Env:HTTPS_PROXY -ErrorAction SilentlyContinue
   & "$env:LOCALAPPDATA\Programs\CodexBar\codexbar.exe" menubar
   ```

5. 若仅 Cookie 服务商失败，重新导入 Cookie；若 Codex 提示登录，在 PowerShell 执行 `codex login`，成功后返回应用点击“重试”刷新用量。

不要把代理地址、Cookie、API Key 或 OAuth token 粘贴到公开 issue。诊断信息只应包含服务商、错误类别和已脱敏状态。

### CLI

安装版的 CLI 默认位于 `%LOCALAPPDATA%\Programs\CodexBar\codexbar-cli.exe`：

```powershell
& "$env:LOCALAPPDATA\Programs\CodexBar\codexbar-cli.exe" usage -p codex
& "$env:LOCALAPPDATA\Programs\CodexBar\codexbar-cli.exe" usage -p all
& "$env:LOCALAPPDATA\Programs\CodexBar\codexbar-cli.exe" cost -p codex
& "$env:LOCALAPPDATA\Programs\CodexBar\codexbar-cli.exe" diagnose
```

## 隐私与本地数据

- 用量请求只发送到已启用服务商的 API；项目没有中转数据服务。
- 应用只读取已知的 CLI 配置、日志和所选浏览器 Cookie 数据库，不做任意磁盘扫描。
- API Key、手动 Cookie 和 token 账户保存在当前用户配置目录，Windows 上使用当前用户的 DPAPI 保护。
- 用量快照、设置和缓存保存在本机；诊断输出不应包含原始凭据。
- 自动更新安装包必须带 GitHub SHA-256 摘要，并在应用前校验。

## 卸载、清理和回退

安装版可在 **Windows 设置 → 应用 → 已安装的应用 → CodexBar → 卸载** 中移除，也可尝试：

```powershell
winget uninstall --id Finesssee.Win-CodexBar --exact
```

卸载程序默认保留用户设置和凭据，便于覆盖升级或重新安装。确认不再需要后，可手动清理：

```powershell
Remove-Item "$env:APPDATA\CodexBar" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:LOCALAPPDATA\CodexBar" -Recurse -Force -ErrorAction SilentlyContinue
```

### 回退到官方 Win-CodexBar 0.43.0

0.44.0 是本仓库的中文用量小组件升级版；官方回退目标是 `Finesssee.Win-CodexBar` 0.43.0。先卸载 0.44.0，再确认 Winget 源确实列出 0.43.0：

```powershell
winget show --id Finesssee.Win-CodexBar --exact --versions
winget install --id Finesssee.Win-CodexBar --exact --version 0.43.0 --source winget
```

若 Winget 当前不再提供 0.43.0，请改从官方仓库的 [v0.43.0 Release](https://github.com/Finesssee/Win-CodexBar/releases/tag/v0.43.0) 下载安装包并校验 SHA-256；不要安装来源不明的回退包。保留的设置通常可继续使用，遇到配置不兼容时先备份 `%APPDATA%\CodexBar` 再清理。

## 从源码运行

Windows 需要 Node.js、pnpm、Rust stable，以及带“使用 C++ 的桌面开发”工作负载的 Visual Studio Build Tools：

```powershell
git clone https://github.com/Finesssee/Win-CodexBar.git
Set-Location Win-CodexBar
corepack enable pnpm
pnpm --dir apps\desktop-tauri install --frozen-lockfile
.\scripts\dev.ps1
```

开发验证：

```powershell
Set-Location apps\desktop-tauri
pnpm run check-locale
pnpm test
pnpm build
Set-Location ..\..
cargo test --manifest-path rust\Cargo.toml
cargo test --manifest-path apps\desktop-tauri\src-tauri\Cargo.toml
```

发布维护者在 Windows 上创建并推送 `v0.44.0` tag 后执行：

```powershell
.\scripts\windows-release-build.ps1 -Ref v0.44.0
.\scripts\verify-windows-executables.ps1 -ExpectedVersion 0.44.0
.\scripts\windows-smoke-install.ps1 `
  -InstallerPath C:\code\Win-CodexBar-release\assets\CodexBar-0.44.0-Setup.exe `
  -ExpectedVersion 0.44.0
```

四个真实资产必须位于 `C:\code\Win-CodexBar-release\assets`：

- `CodexBar-0.44.0-Setup.exe`
- `CodexBar-0.44.0-Setup.exe.sha256`
- `CodexBar-0.44.0-portable.exe`
- `CodexBar-0.44.0-portable.exe.sha256`

Windows 手工验证矩阵见 [docs/WIDGET_WINDOWS_TEST.md](docs/WIDGET_WINDOWS_TEST.md)。

## 更多文档

- [从源码构建](docs/BUILDING.md)
- [WSL 设置与认证](docs/WSL.md)
- [浏览器 Cookie 详解](docs/COOKIES.md)
- [Windows 小组件验证矩阵](docs/WIDGET_WINDOWS_TEST.md)

## 致谢与许可证

- 原版 CodexBar：[steipete/CodexBar](https://github.com/steipete/CodexBar)，作者 Peter Steinberger。
- Windows 移植：[Finesssee/Win-CodexBar](https://github.com/Finesssee/Win-CodexBar)。
- MIT License，见 [LICENSE](LICENSE)。
