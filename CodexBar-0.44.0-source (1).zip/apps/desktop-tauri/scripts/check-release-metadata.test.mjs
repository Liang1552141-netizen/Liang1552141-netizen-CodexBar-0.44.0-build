import assert from "node:assert/strict";
import test from "node:test";

import { checkReleaseMetadata } from "../../../scripts/ci/check-release-metadata.mjs";

function fixture(overrides = {}) {
  const files = {
    "version.env": "MARKETING_VERSION=0.44.0\n",
    "apps/desktop-tauri/package.json": JSON.stringify({ version: "0.44.0" }),
    "apps/desktop-tauri/src-tauri/tauri.conf.json": JSON.stringify({
      version: "0.44.0",
    }),
    "apps/desktop-tauri/src-tauri/Cargo.toml":
      '[package]\nname = "codexbar-desktop-tauri"\nversion = "0.44.0"\n',
    "rust/Cargo.toml":
      '[package]\nname = "codexbar"\nversion = "0.44.0"\n',
    "Cargo.lock":
      '[[package]]\nname = "codexbar"\nversion = "0.44.0"\n\n' +
      '[[package]]\nname = "codexbar-desktop-tauri"\nversion = "0.44.0"\n',
    "rust/installer/codexbar.iss": '#define AppVersion "0.44.0"\n',
    "CHANGELOG.md": "## [Windows] 0.44.0 - 2026-07-23\n",
    "README.zh-CN.md": "# Win-CodexBar 0.44.0 中文用量小组件升级版\n",
    ...overrides,
  };
  return (path) => {
    if (!(path in files)) throw new Error(`unexpected read: ${path}`);
    return files[path];
  };
}

test("checks release metadata without interpreting PowerShell behavior", () => {
  const result = checkReleaseMetadata(fixture());
  assert.deepEqual(result, { version: "0.44.0", failures: [] });
});

test("reports a structured package version mismatch", () => {
  const result = checkReleaseMetadata(
    fixture({
      "apps/desktop-tauri/package.json": JSON.stringify({ version: "9.9.9" }),
    }),
  );
  assert.ok(
    result.failures.includes(
      "apps/desktop-tauri/package.json version is 9.9.9, expected 0.44.0",
    ),
  );
});
