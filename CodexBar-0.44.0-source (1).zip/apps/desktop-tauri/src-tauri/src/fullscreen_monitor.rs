use std::sync::atomic::{AtomicU64, Ordering};

static WINDOW_GENERATION: AtomicU64 = AtomicU64::new(0);

/// Invalidate policy state whenever the floatbar HWND is created or destroyed.
/// This makes an unchanged fullscreen observation apply to a replacement
/// window while a missing-window directive can still be acknowledged.
pub(crate) fn window_instance_changed() {
    WINDOW_GENERATION.fetch_add(1, Ordering::Relaxed);
}

fn window_generation() -> u64 {
    WINDOW_GENERATION.load(Ordering::Relaxed)
}

/// Physical-pixel rectangle used by the platform probe and pure fullscreen
/// tests. The field order intentionally matches Win32 `RECT`.
#[repr(C)]
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Rect {
    pub left: i32,
    pub top: i32,
    pub right: i32,
    pub bottom: i32,
}

impl Rect {
    pub const fn new(left: i32, top: i32, right: i32, bottom: i32) -> Self {
        Self {
            left,
            top,
            right,
            bottom,
        }
    }
}

/// Treat borderless windows as fullscreen when every edge matches the
/// monitor bounds within Windows' occasional one-physical-pixel rounding.
pub fn is_effective_fullscreen(foreground: Rect, monitor: Rect) -> bool {
    const EPSILON: i32 = 1;
    (foreground.left - monitor.left).abs() <= EPSILON
        && (foreground.top - monitor.top).abs() <= EPSILON
        && (foreground.right - monitor.right).abs() <= EPSILON
        && (foreground.bottom - monitor.bottom).abs() <= EPSILON
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct MonitorObservation {
    fullscreen: bool,
    hide_fullscreen: bool,
    smart_topmost: bool,
    widget_enabled: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct WindowDirective {
    enabled: bool,
    hidden: bool,
    topmost: bool,
}

impl From<MonitorObservation> for WindowDirective {
    fn from(observation: MonitorObservation) -> Self {
        Self {
            enabled: observation.widget_enabled,
            hidden: observation.widget_enabled
                && observation.fullscreen
                && observation.hide_fullscreen,
            topmost: observation.smart_topmost,
        }
    }
}

#[derive(Debug, Default)]
struct MonitorPolicy {
    last_applied: Option<WindowDirective>,
    dirty: Option<WindowDirective>,
    observed_window_generation: Option<u64>,
}

impl MonitorPolicy {
    fn observe_window_generation(&mut self, generation: u64) -> bool {
        if self.observed_window_generation == Some(generation) {
            return false;
        }
        self.observed_window_generation = Some(generation);
        self.last_applied = None;
        self.dirty = None;
        true
    }

    fn desired(&mut self, observation: MonitorObservation) -> Option<WindowDirective> {
        let next = WindowDirective::from(observation);
        if self.last_applied == Some(next) {
            self.dirty = None;
            return None;
        }
        self.dirty = Some(next);
        Some(next)
    }

    fn acknowledge(&mut self, applied: WindowDirective) {
        if self.dirty == Some(applied) {
            self.last_applied = Some(applied);
            self.dirty = None;
        }
    }

    fn is_pending(&self, directive: WindowDirective) -> bool {
        self.dirty == Some(directive)
    }
}

#[cfg(windows)]
mod platform {
    use super::{
        is_effective_fullscreen, window_generation, MonitorObservation, MonitorPolicy, Rect,
        WindowDirective,
    };
    use codexbar::settings::Settings;
    use raw_window_handle::HasWindowHandle;
    use std::sync::{Arc, Mutex};
    use std::time::Duration;
    use tauri::Manager;

    const POLL_INTERVAL: Duration = Duration::from_millis(500);
    const MONITOR_DEFAULTTONEAREST: u32 = 2;
    const SW_SHOWNOACTIVATE: i32 = 4;

    #[repr(C)]
    struct MonitorInfo {
        size: u32,
        monitor: Rect,
        work: Rect,
        flags: u32,
    }

    #[derive(Debug, Clone, Copy)]
    struct RestoreState {
        was_visible: bool,
        geometry: crate::floatbar::FullscreenRestoreGeometry,
    }

    pub fn install(app: &tauri::AppHandle) {
        let app = app.clone();
        let restore = Arc::new(Mutex::new(None::<RestoreState>));
        let policy = Arc::new(Mutex::new(MonitorPolicy::default()));

        tauri::async_runtime::spawn(async move {
            let mut interval = tokio::time::interval(POLL_INTERVAL);
            interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);

            loop {
                interval.tick().await;
                let settings = Settings::load();
                let observation = MonitorObservation {
                    fullscreen: foreground_is_effectively_fullscreen(),
                    hide_fullscreen: settings.widget_hide_fullscreen,
                    smart_topmost: settings.widget_smart_topmost,
                    widget_enabled: settings.float_bar_enabled,
                };
                let observed_generation = window_generation();
                let directive = policy.lock().ok().and_then(|mut policy| {
                    if policy.observe_window_generation(observed_generation)
                        && let Ok(mut state) = restore.lock()
                    {
                        *state = None;
                    }
                    policy.desired(observation)
                });
                let Some(directive) = directive else {
                    continue;
                };

                let app_for_action = app.clone();
                let restore_for_action = Arc::clone(&restore);
                let policy_for_action = Arc::clone(&policy);
                if let Err(error) = app.run_on_main_thread(move || {
                    let still_pending = policy_for_action
                        .lock()
                        .map(|policy| policy.is_pending(directive))
                        .unwrap_or(false);
                    if !still_pending {
                        return;
                    }
                    if window_generation() != observed_generation {
                        return;
                    }
                    if apply_directive(&app_for_action, &restore_for_action, directive)
                        && let Ok(mut policy) = policy_for_action.lock()
                    {
                        policy.acknowledge(directive);
                    }
                }) {
                    tracing::warn!(%error, "failed to dispatch fullscreen widget action");
                }
            }
        });
    }

    fn apply_directive(
        app: &tauri::AppHandle,
        restore: &Mutex<Option<RestoreState>>,
        directive: WindowDirective,
    ) -> bool {
        let Some(window) = app.get_webview_window(crate::floatbar::FLOATBAR_LABEL) else {
            if let Ok(mut state) = restore.lock() {
                *state = None;
                return true;
            }
            return false;
        };
        if !directive.enabled {
            if let Ok(mut state) = restore.lock() {
                *state = None;
            } else {
                return false;
            }
            return window.is_visible().is_ok();
        }
        if !crate::floatbar::apply_topmost(&window, directive.topmost) {
            return false;
        }

        if directive.hidden {
            let was_visible = match window.is_visible() {
                Ok(visible) => visible,
                Err(error) => {
                    tracing::warn!(%error, "failed to inspect floatbar visibility before hide");
                    return false;
                }
            };
            let prior = match restore.lock() {
                Ok(state) => *state,
                Err(_) => return false,
            };
            if prior.is_none() {
                let geometry = match crate::floatbar::capture_fullscreen_restore_geometry(&window) {
                    Ok(geometry) => geometry,
                    Err(error) => {
                        tracing::warn!(%error, "failed to capture floatbar fullscreen restore rect");
                        return false;
                    }
                };
                if let Ok(mut state) = restore.lock() {
                    *state = Some(RestoreState {
                        was_visible,
                        geometry,
                    });
                } else {
                    return false;
                }
            }
            if was_visible {
                crate::floatbar::set_topmost_guard_active(false);
                if let Err(error) = window.hide() {
                    tracing::warn!(%error, "failed to hide floatbar for fullscreen app");
                    return false;
                }
            }
            return matches!(window.is_visible(), Ok(false));
        }

        let prior = match restore.lock() {
            Ok(mut state) => state.take(),
            Err(_) => return false,
        };
        if let Some(prior) = prior {
            if prior.was_visible {
                if !crate::floatbar::restore_fullscreen_geometry(&window, Some(&prior.geometry)) {
                    put_restore_state_back(restore, prior);
                    return false;
                }
                if !show_without_activation(&window) {
                    put_restore_state_back(restore, prior);
                    return false;
                }
                if !crate::floatbar::apply_topmost(&window, directive.topmost) {
                    put_restore_state_back(restore, prior);
                    return false;
                }
            } else if !matches!(window.is_visible(), Ok(false)) {
                put_restore_state_back(restore, prior);
                return false;
            }
        }
        let visible = match window.is_visible() {
            Ok(visible) => visible,
            Err(error) => {
                if let Some(prior) = prior {
                    put_restore_state_back(restore, prior);
                }
                tracing::warn!(%error, "failed to verify floatbar visibility after restore");
                return false;
            }
        };
        crate::floatbar::set_topmost_guard_active(directive.topmost && visible);
        true
    }

    fn put_restore_state_back(restore: &Mutex<Option<RestoreState>>, prior: RestoreState) {
        if let Ok(mut state) = restore.lock() {
            if state.is_none() {
                *state = Some(prior);
            }
        }
    }

    fn show_without_activation(window: &tauri::WebviewWindow) -> bool {
        let Ok(handle) = window.window_handle() else {
            return false;
        };
        let raw_window_handle::RawWindowHandle::Win32(handle) = handle.as_raw() else {
            return false;
        };
        unsafe {
            // The return value is the previous visibility state, not success.
            ShowWindow(handle.hwnd.get(), SW_SHOWNOACTIVATE);
        }
        matches!(window.is_visible(), Ok(true))
    }

    fn foreground_is_effectively_fullscreen() -> bool {
        let foreground = unsafe { GetForegroundWindow() };
        if !is_application_foreground(foreground) {
            return false;
        }

        let mut foreground_rect = Rect::default();
        if unsafe { GetWindowRect(foreground, &mut foreground_rect) } == 0 {
            return false;
        }
        let monitor = unsafe { MonitorFromWindow(foreground, MONITOR_DEFAULTTONEAREST) };
        if monitor == 0 {
            return false;
        }
        let mut info = MonitorInfo {
            size: std::mem::size_of::<MonitorInfo>() as u32,
            monitor: Rect::default(),
            work: Rect::default(),
            flags: 0,
        };
        if unsafe { GetMonitorInfoW(monitor, &mut info) } == 0 {
            return false;
        }
        is_effective_fullscreen(foreground_rect, info.monitor)
    }

    fn is_application_foreground(window: isize) -> bool {
        if window == 0
            || unsafe { IsWindowVisible(window) } == 0
            || unsafe { IsIconic(window) } != 0
            || window == unsafe { GetDesktopWindow() }
            || window == unsafe { GetShellWindow() }
        {
            return false;
        }

        let mut process_id = 0_u32;
        unsafe { GetWindowThreadProcessId(window, &mut process_id) };
        if process_id == 0 || process_id == std::process::id() {
            return false;
        }

        !matches!(
            window_class_name(window).as_str(),
            "Progman"
                | "WorkerW"
                | "Shell_TrayWnd"
                | "Shell_SecondaryTrayWnd"
                | "MultitaskingViewFrame"
        )
    }

    fn window_class_name(window: isize) -> String {
        let mut buffer = [0_u16; 256];
        let length = unsafe { GetClassNameW(window, buffer.as_mut_ptr(), buffer.len() as i32) };
        if length <= 0 {
            return String::new();
        }
        String::from_utf16_lossy(&buffer[..length as usize])
    }

    #[link(name = "user32")]
    unsafe extern "system" {
        fn GetClassNameW(window: isize, class_name: *mut u16, max_count: i32) -> i32;
        fn GetDesktopWindow() -> isize;
        fn GetForegroundWindow() -> isize;
        fn GetMonitorInfoW(monitor: isize, info: *mut MonitorInfo) -> i32;
        fn GetShellWindow() -> isize;
        fn GetWindowRect(window: isize, rect: *mut Rect) -> i32;
        fn GetWindowThreadProcessId(window: isize, process_id: *mut u32) -> u32;
        fn IsIconic(window: isize) -> i32;
        fn IsWindowVisible(window: isize) -> i32;
        fn MonitorFromWindow(window: isize, flags: u32) -> isize;
        fn ShowWindow(window: isize, command: i32) -> i32;
    }
}

#[cfg(windows)]
pub fn install(app: &tauri::AppHandle) {
    platform::install(app);
}

#[cfg(not(windows))]
pub fn install(_app: &tauri::AppHandle) {}

#[cfg(test)]
mod tests {
    use super::{
        is_effective_fullscreen, MonitorObservation, MonitorPolicy, Rect, WindowDirective,
    };

    #[test]
    fn exact_or_one_pixel_tolerance_counts_as_fullscreen() {
        assert!(is_effective_fullscreen(
            Rect::new(0, 0, 1920, 1080),
            Rect::new(0, 0, 1920, 1080),
        ));
        assert!(is_effective_fullscreen(
            Rect::new(-1, 0, 1921, 1080),
            Rect::new(0, 0, 1920, 1080),
        ));
    }

    #[test]
    fn normal_maximized_window_does_not_count_as_fullscreen() {
        assert!(!is_effective_fullscreen(
            Rect::new(0, 0, 1920, 1040),
            Rect::new(0, 0, 1920, 1080),
        ));
    }

    #[test]
    fn unrelated_or_oversized_windows_do_not_count_as_fullscreen() {
        assert!(!is_effective_fullscreen(
            Rect::new(120, 80, 1500, 900),
            Rect::new(0, 0, 1920, 1080),
        ));
        assert!(!is_effective_fullscreen(
            Rect::new(-8, -8, 1928, 1088),
            Rect::new(0, 0, 1920, 1080),
        ));
    }

    #[test]
    fn acknowledged_monitor_directive_emits_no_repeated_action() {
        let mut policy = MonitorPolicy::default();
        let ordinary = MonitorObservation {
            fullscreen: false,
            hide_fullscreen: true,
            smart_topmost: true,
            widget_enabled: true,
        };

        assert_eq!(
            policy.desired(ordinary),
            Some(WindowDirective {
                enabled: true,
                hidden: false,
                topmost: true,
            }),
        );
        policy.acknowledge(WindowDirective::from(ordinary));
        assert_eq!(policy.desired(ordinary), None);
    }

    #[test]
    fn unacknowledged_directive_is_retried() {
        let mut policy = MonitorPolicy::default();
        let observation = MonitorObservation {
            fullscreen: true,
            hide_fullscreen: true,
            smart_topmost: true,
            widget_enabled: true,
        };

        let first = policy.desired(observation).unwrap();
        // Failed window operations deliberately omit acknowledge.
        assert_eq!(policy.desired(observation), Some(first));
    }

    #[test]
    fn failed_window_operation_does_not_ack_and_is_retried() {
        let mut policy = MonitorPolicy::default();
        let observation = MonitorObservation {
            fullscreen: false,
            hide_fullscreen: true,
            smart_topmost: false,
            widget_enabled: true,
        };

        let first = policy.desired(observation).unwrap();
        // A hide/show/visibility failure also deliberately omits acknowledge.
        assert_eq!(policy.desired(observation), Some(first));
    }

    #[test]
    fn fullscreen_preference_transitions_hide_then_restore() {
        let mut policy = MonitorPolicy::default();
        let ordinary = MonitorObservation {
            fullscreen: false,
            hide_fullscreen: true,
            smart_topmost: true,
            widget_enabled: true,
        };
        let fullscreen = MonitorObservation {
            fullscreen: true,
            ..ordinary
        };

        let ordinary_directive = policy.desired(ordinary).unwrap();
        policy.acknowledge(ordinary_directive);
        assert_eq!(
            policy.desired(fullscreen),
            Some(WindowDirective {
                enabled: true,
                hidden: true,
                topmost: true,
            }),
        );
        let fullscreen_directive = WindowDirective::from(fullscreen);
        policy.acknowledge(fullscreen_directive);
        assert_eq!(policy.desired(fullscreen), None);
        assert_eq!(
            policy.desired(ordinary),
            Some(WindowDirective {
                enabled: true,
                hidden: false,
                topmost: true,
            }),
        );
    }

    #[test]
    fn disabling_fullscreen_hide_restores_without_changing_foreground() {
        let mut policy = MonitorPolicy::default();
        let hiding = MonitorObservation {
            fullscreen: true,
            hide_fullscreen: true,
            smart_topmost: false,
            widget_enabled: true,
        };
        let showing = MonitorObservation {
            hide_fullscreen: false,
            ..hiding
        };

        let hiding_directive = policy.desired(hiding).unwrap();
        assert!(hiding_directive.hidden);
        policy.acknowledge(hiding_directive);
        assert_eq!(policy.desired(showing).unwrap().hidden, false);
    }

    #[test]
    fn smart_topmost_changes_are_emitted_in_normal_state() {
        let mut policy = MonitorPolicy::default();
        let normal = MonitorObservation {
            fullscreen: false,
            hide_fullscreen: true,
            smart_topmost: true,
            widget_enabled: true,
        };
        let not_topmost = MonitorObservation {
            smart_topmost: false,
            ..normal
        };

        let normal_directive = policy.desired(normal).unwrap();
        policy.acknowledge(normal_directive);
        let changed = policy.desired(not_topmost).unwrap();
        assert!(!changed.topmost);
        policy.acknowledge(changed);
        assert_eq!(policy.desired(not_topmost), None);
    }

    #[test]
    fn enabling_widget_re_emits_current_directive() {
        let mut policy = MonitorPolicy::default();
        let closed = MonitorObservation {
            fullscreen: true,
            hide_fullscreen: true,
            smart_topmost: true,
            widget_enabled: false,
        };
        let open = MonitorObservation {
            widget_enabled: true,
            ..closed
        };

        let closed_directive = policy.desired(closed).unwrap();
        assert!(!closed_directive.hidden);
        policy.acknowledge(closed_directive);
        let open_directive = policy.desired(open).unwrap();
        assert!(open_directive.hidden);
        policy.acknowledge(open_directive);
        assert_eq!(policy.desired(open), None);
    }

    #[test]
    fn new_window_instance_reapplies_fullscreen_hide_during_same_session() {
        let mut policy = MonitorPolicy::default();
        let fullscreen = MonitorObservation {
            fullscreen: true,
            hide_fullscreen: true,
            smart_topmost: true,
            widget_enabled: true,
        };

        policy.observe_window_generation(1);
        let first_window = policy.desired(fullscreen).unwrap();
        assert!(first_window.hidden);
        policy.acknowledge(first_window);
        assert_eq!(policy.desired(fullscreen), None);

        policy.observe_window_generation(2);
        let replacement_window = policy.desired(fullscreen).unwrap();
        assert!(replacement_window.hidden);
    }

    #[test]
    fn absent_window_directive_can_be_acknowledged_until_creation_invalidates_it() {
        let mut policy = MonitorPolicy::default();
        let disabled = MonitorObservation {
            fullscreen: true,
            hide_fullscreen: true,
            smart_topmost: true,
            widget_enabled: false,
        };

        policy.observe_window_generation(7);
        let without_window = policy.desired(disabled).unwrap();
        policy.acknowledge(without_window);
        assert_eq!(policy.desired(disabled), None);

        policy.observe_window_generation(8);
        assert_eq!(policy.desired(disabled), Some(without_window));
    }
}
