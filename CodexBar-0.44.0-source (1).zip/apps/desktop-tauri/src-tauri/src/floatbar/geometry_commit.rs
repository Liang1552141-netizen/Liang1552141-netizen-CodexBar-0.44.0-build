use std::sync::{LazyLock, Mutex};
use std::time::Duration;

use codexbar::settings::Settings;
use tauri::Manager;

const GEOMETRY_DEBOUNCE: Duration = Duration::from_millis(180);

#[derive(Debug, Default)]
struct GeometryCommitState {
    revision: u64,
    worker_running: bool,
}

impl GeometryCommitState {
    fn record_event(&mut self) -> bool {
        self.revision = self.revision.wrapping_add(1);
        if self.worker_running {
            return false;
        }
        self.worker_running = true;
        true
    }

    fn revision(&self) -> u64 {
        self.revision
    }

    fn invalidate(&mut self) {
        self.revision = self.revision.wrapping_add(1);
    }

    fn is_stable(&self, revision: u64) -> bool {
        self.revision == revision
    }

    /// Returns true when another event arrived and this worker must continue.
    fn finish_commit(&mut self, committed_revision: u64) -> bool {
        if self.revision != committed_revision {
            return true;
        }
        self.worker_running = false;
        false
    }

    fn worker_running(&self) -> bool {
        self.worker_running
    }
}

static COMMIT_STATE: LazyLock<Mutex<GeometryCommitState>> =
    LazyLock::new(|| Mutex::new(GeometryCommitState::default()));
static FLOATBAR_WRITE: LazyLock<Mutex<()>> = LazyLock::new(|| Mutex::new(()));

/// Coalesce high-frequency Moved/Resized events. The event callback performs
/// only a mutex update and task spawn; settings I/O, geometry persistence, and
/// z-order repair happen once after the burst settles.
pub(super) fn schedule(app: tauri::AppHandle) {
    let starts_worker = COMMIT_STATE
        .lock()
        .map(|mut state| state.record_event())
        .unwrap_or(false);
    if !starts_worker {
        return;
    }

    tauri::async_runtime::spawn(async move {
        commit_loop(app).await;
    });
}

/// Persist an explicit final geometry (close or imperative resize) in write
/// order with the debounced worker.
pub(super) fn commit_now<R: tauri::Runtime, M: super::window::WindowGeometry<R>>(
    window: &M,
) {
    let Some(geometry) = super::window::capture_geometry(window) else {
        return;
    };
    commit_stored_geometry(geometry);
}

/// Canonical direct floatbar writer used by close, resize, off-monitor
/// recovery, fullscreen restore, and application-exit flush. A dedicated
/// write lock orders the revision check with disk persistence without holding
/// COMMIT_STATE across I/O, so Moved/Resized callbacks remain non-blocking.
pub(super) fn commit_stored_geometry(geometry: crate::geometry_store::StoredGeometry) {
    let _write = FLOATBAR_WRITE
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    COMMIT_STATE
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
        .invalidate();
    crate::geometry_store::save_entry(super::window::FLOATBAR_LABEL, geometry);
}

fn commit_stored_geometry_if_stable(
    candidate_revision: u64,
    geometry: crate::geometry_store::StoredGeometry,
) {
    let _write = FLOATBAR_WRITE
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let stable = COMMIT_STATE
        .lock()
        .map(|state| state.is_stable(candidate_revision))
        .unwrap_or(false);
    if stable {
        crate::geometry_store::save_entry(super::window::FLOATBAR_LABEL, geometry);
    }
}

async fn commit_loop(app: tauri::AppHandle) {
    loop {
        let candidate_revision = match COMMIT_STATE.lock() {
            Ok(state) => state.revision(),
            Err(_) => return,
        };
        tokio::time::sleep(GEOMETRY_DEBOUNCE).await;
        let stable = COMMIT_STATE
            .lock()
            .map(|state| state.is_stable(candidate_revision))
            .unwrap_or(false);
        if !stable {
            continue;
        }

        let settings = tauri::async_runtime::spawn_blocking(Settings::load)
            .await
            .unwrap_or_else(|_| Settings::default());
        let style = settings.float_bar_style;
        let smart_topmost = settings.widget_smart_topmost;
        let (sender, receiver) = tokio::sync::oneshot::channel();
        let app_for_main = app.clone();
        if let Err(error) = app.run_on_main_thread(move || {
            let geometry = app_for_main
                .get_webview_window(super::window::FLOATBAR_LABEL)
                .and_then(|window| {
                    if super::window::is_off_all_monitors(&window) {
                        super::window::recover_onto_primary(&window, &style);
                        super::window::apply_topmost(&window, smart_topmost);
                        None
                    } else {
                        let geometry = super::window::capture_geometry(&window);
                        super::window::apply_topmost(&window, smart_topmost);
                        geometry
                    }
                });
            let _ = sender.send(geometry);
        }) {
            tracing::warn!(%error, "failed to dispatch debounced floatbar geometry commit");
        }

        if let Ok(Some(geometry)) = receiver.await {
            let _ = tauri::async_runtime::spawn_blocking(move || {
                commit_stored_geometry_if_stable(candidate_revision, geometry);
            })
            .await;
        }

        let keep_running = COMMIT_STATE
            .lock()
            .map(|mut state| state.finish_commit(candidate_revision))
            .unwrap_or(false);
        if !keep_running {
            return;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::GeometryCommitState;

    #[test]
    fn burst_geometry_events_start_one_worker_and_commit_only_latest_revision() {
        let mut state = GeometryCommitState::default();

        assert!(state.record_event());
        assert!(!state.record_event());
        assert!(!state.record_event());
        assert_eq!(state.revision(), 3);
        assert!(!state.is_stable(1));
        assert!(state.is_stable(3));
    }

    #[test]
    fn event_arriving_during_commit_keeps_worker_alive_for_final_geometry() {
        let mut state = GeometryCommitState::default();
        assert!(state.record_event());
        let committing = state.revision();
        assert!(!state.record_event());

        assert!(state.finish_commit(committing));
        let final_revision = state.revision();
        assert!(state.is_stable(final_revision));
        assert!(!state.finish_commit(final_revision));
        assert!(!state.worker_running());
    }
}
