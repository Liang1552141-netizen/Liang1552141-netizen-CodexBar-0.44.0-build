//! Self-contained "Float Bar" feature module.
//!
//! Owns the auxiliary `floatbar` Tauri window, the Tauri commands that
//! mutate it, the settings-patch surface, the startup restore hook, the
//! window-event hook, and the tray-menu glue. The rest of the desktop
//! shell only needs to call into the small public API exported here.

mod commands;
mod geometry_commit;
mod topmost_guard;
mod window;

pub use commands::*;
pub use window::FLOAT_BAR_CONFIG_CHANGED_EVENT;
pub use window::FLOATBAR_LABEL;
pub(crate) use window::{
    apply_topmost, capture_fullscreen_restore_geometry, restore_fullscreen_geometry,
    FullscreenRestoreGeometry,
};

pub(crate) fn set_topmost_guard_active(active: bool) {
    topmost_guard::set_active(active);
}

use codexbar::settings::Settings;
use std::sync::Mutex;

use tauri::{Emitter, Manager};

use crate::widget_policy::{decide, WidgetAction, WidgetEvent, WidgetState};

/// Install the native z-order guard and reopen the floating bar on app start
/// if it was enabled previously.
///
/// Called once from `main.rs::setup` so the guard has the app handle before
/// the floatbar is shown.
pub fn install(app: &tauri::AppHandle) {
    topmost_guard::install(app);
    let persisted = Settings::load();
    if persisted.float_bar_enabled {
        if window::show(
            app,
            persisted.float_bar_opacity,
            &persisted.float_bar_orientation,
            &persisted.float_bar_style,
            persisted.widget_smart_topmost,
            persisted.float_bar_click_through,
        )
        .is_ok()
        {
            let _ = commands::collapse_usage_widget_window(app);
        }
    }
}

/// Handle a `WindowEvent` targeting the floatbar window. Returns `true`
/// when the event was for the floatbar (and was handled), `false`
/// otherwise so the caller can fall through to its own handling.
pub fn handle_window_event(window: &tauri::Window, event: &tauri::WindowEvent) -> bool {
    if window.label() != FLOATBAR_LABEL {
        return false;
    }
    match event {
        tauri::WindowEvent::Moved(_) | tauri::WindowEvent::Resized(_) => {
            geometry_commit::schedule(window.app_handle().clone());
        }
        tauri::WindowEvent::CloseRequested { .. } => geometry_commit::commit_now(window),
        tauri::WindowEvent::Destroyed => {
            topmost_guard::set_active(false);
            crate::fullscreen_monitor::window_instance_changed();
        }
        tauri::WindowEvent::Focused(false) => {
            let action = window
                .app_handle()
                .try_state::<Mutex<WidgetState>>()
                .and_then(|state| {
                    state
                        .lock()
                        .ok()
                        .map(|state| decide(*state, WidgetEvent::FocusLost))
                })
                .unwrap_or(WidgetAction::KeepVisible);
            if action == WidgetAction::Collapse {
                let app = window.app_handle().clone();
                tauri::async_runtime::spawn(async move {
                    let _ = commands::collapse_usage_widget_window(&app);
                });
            }
        }
        _ => {}
    }
    true
}

/// Toggle the floating bar from the tray menu. Persists the new state
/// and shows or hides the window accordingly.
pub fn toggle(app: &tauri::AppHandle) {
    let settings = match crate::settings_mutation::mutate(|settings| {
        settings.float_bar_enabled = !settings.float_bar_enabled;
        Ok(())
    }) {
        Ok((settings, ())) => settings,
        Err(error) => {
            tracing::warn!(%error, "failed to persist floatbar toggle");
            return;
        }
    };
    if settings.float_bar_enabled {
        if window::show(
            app,
            settings.float_bar_opacity,
            &settings.float_bar_orientation,
            &settings.float_bar_style,
            settings.widget_smart_topmost,
            settings.float_bar_click_through,
        )
        .is_ok()
        {
            let _ = commands::collapse_usage_widget_window(app);
        }
    } else {
        let _ = window::hide(app);
    }
}

/// Bring the floating-bar window in line with persisted settings: open,
/// close, or re-apply opacity / click-through as appropriate. Used after
/// a settings patch is saved.
pub fn apply_state(app: &tauri::AppHandle, settings: &Settings) {
    let open = app.get_webview_window(FLOATBAR_LABEL).is_some();
    if settings.float_bar_enabled && !open {
        if window::show(
            app,
            settings.float_bar_opacity,
            &settings.float_bar_orientation,
            &settings.float_bar_style,
            settings.widget_smart_topmost,
            settings.float_bar_click_through,
        )
        .is_ok()
        {
            let _ = commands::collapse_usage_widget_window(app);
        }
    } else if !settings.float_bar_enabled && open {
        let _ = window::hide(app);
    } else if let Some(w) = app.get_webview_window(FLOATBAR_LABEL) {
        let _ = window::ensure_visible_on_active_monitor(&w, &settings.float_bar_style);
        window::apply_opacity(&w, settings.float_bar_opacity);
        window::apply_click_through(&w, settings.float_bar_click_through);
        window::apply_topmost(&w, settings.widget_smart_topmost);
        topmost_guard::set_active(
            settings.widget_smart_topmost && w.is_visible().unwrap_or(false),
        );
    }
}

/// All settings fields the float bar owns, in a single optional
/// patch. Used by `update_settings` so the bulk of float-bar plumbing
/// stays in this module rather than spread across the settings handler.
#[derive(Debug, Default)]
pub struct SettingsPatch {
    pub enabled: Option<bool>,
    pub opacity: Option<u8>,
    pub scale: Option<u8>,
    pub orientation: Option<String>,
    pub style: Option<String>,
    pub click_through: Option<bool>,
    pub provider_ids: Option<Vec<String>>,
    pub dark_text: Option<bool>,
    pub show_reset_inline: Option<bool>,
    pub show_cost: Option<bool>,
    pub widget_theme: Option<codexbar::settings::WidgetTheme>,
    pub widget_pinned: Option<bool>,
}

impl SettingsPatch {
    pub fn is_empty(&self) -> bool {
        self.enabled.is_none()
            && self.opacity.is_none()
            && self.scale.is_none()
            && self.orientation.is_none()
            && self.style.is_none()
            && self.click_through.is_none()
            && self.provider_ids.is_none()
            && self.dark_text.is_none()
            && self.show_reset_inline.is_none()
            && self.show_cost.is_none()
            && self.widget_theme.is_none()
            && self.widget_pinned.is_none()
    }

    /// Apply this patch to a mutable `Settings`. Values are clamped and
    /// normalized before assignment to keep the on-disk state safe.
    pub fn apply(&self, settings: &mut Settings) {
        if let Some(v) = self.enabled {
            settings.float_bar_enabled = v;
        }
        if let Some(v) = self.opacity {
            settings.float_bar_opacity = codexbar::settings::clamp_float_bar_opacity(v);
        }
        if let Some(v) = self.scale {
            settings.float_bar_scale = codexbar::settings::clamp_float_bar_scale(v);
        }
        if let Some(v) = &self.orientation {
            settings.float_bar_orientation = codexbar::settings::normalize_float_bar_orientation(v);
        }
        if let Some(v) = &self.style {
            settings.float_bar_style = codexbar::settings::normalize_float_bar_style(v);
        }
        if let Some(v) = self.click_through {
            settings.float_bar_click_through = v;
        }
        if let Some(v) = &self.provider_ids {
            settings.float_bar_provider_ids = v.clone();
        }
        if let Some(v) = self.dark_text {
            settings.float_bar_dark_text = v;
        }
        if let Some(v) = self.show_reset_inline {
            settings.float_bar_show_reset_inline = v;
        }
        if let Some(v) = self.show_cost {
            settings.float_bar_show_cost = v;
        }
        if let Some(v) = self.widget_theme {
            settings.widget_theme = v;
        }
        if let Some(v) = self.widget_pinned {
            settings.widget_pinned = v;
        }
    }
}

/// React to a saved settings patch: emit the live-config event and bring
/// the window in line. No-op when nothing in the patch was float-bar
/// related.
pub fn after_settings_saved(
    app: &tauri::AppHandle,
    patch: &SettingsPatch,
    settings: &Settings,
    notify_live_config: bool,
) {
    if notify_live_config || !patch.is_empty() {
        notify_settings_changed(app);
    }
    if !patch.is_empty() {
        apply_state(app, settings);
    }
}

/// Persist settings and update the widget policy's pin bit. The caller owns
/// the process-wide settings mutation lock; this helper then acquires widget
/// state before disk mutation, preserving the single lock order
/// settings-mutation -> widget-state.
pub(crate) fn save_settings_with_widget_state(
    app: &tauri::AppHandle,
    settings: &Settings,
    pinned: Option<bool>,
) -> Result<(), String> {
    if let Some(pinned) = pinned {
        let state = app
            .try_state::<Mutex<WidgetState>>()
            .ok_or_else(|| "usage widget policy state is unavailable".to_string())?;
        let mut state = state
            .lock()
            .map_err(|_| "usage widget policy state is poisoned".to_string())?;
        settings.save().map_err(|error| error.to_string())?;
        let _ = decide(*state, WidgetEvent::PinChanged(pinned));
        state.pinned = pinned;
        return Ok(());
    }
    settings.save().map_err(|error| error.to_string())
}

pub fn notify_settings_changed(app: &tauri::AppHandle) {
    let _ = app.emit(FLOAT_BAR_CONFIG_CHANGED_EVENT, ());
}

fn flush_then<T>(flush: impl FnOnce(), continue_exit: impl FnOnce() -> T) -> T {
    flush();
    continue_exit()
}

/// Synchronously capture the live floatbar rectangle. This bypasses the
/// 180ms debounce and invalidates any older worker candidate.
pub(crate) fn flush_geometry_before_exit(app: &tauri::AppHandle) {
    if let Some(window) = app.get_webview_window(FLOATBAR_LABEL) {
        geometry_commit::commit_now(&window);
    }
}

/// Canonical Tauri application exit path: final geometry reaches disk before
/// AppHandle::exit can terminate the event loop.
pub(crate) fn exit_app(app: &tauri::AppHandle) {
    flush_then(
        || flush_geometry_before_exit(app),
        || app.exit(0),
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex as StdMutex;

    #[test]
    fn settings_patch_is_empty_by_default() {
        assert!(SettingsPatch::default().is_empty());
    }

    #[test]
    fn settings_patch_apply_only_writes_present_fields() {
        let mut s = Settings {
            float_bar_enabled: false,
            float_bar_opacity: 80,
            float_bar_scale: 100,
            float_bar_orientation: "horizontal".into(),
            float_bar_style: "floating".into(),
            float_bar_dark_text: false,
            float_bar_show_reset_inline: false,
            ..Settings::default()
        };

        let patch = SettingsPatch {
            enabled: Some(true),
            opacity: Some(45),
            scale: Some(135),
            style: Some("taskbar".into()),
            dark_text: Some(true),
            show_reset_inline: Some(true),
            widget_theme: Some(codexbar::settings::WidgetTheme::DeepBlue),
            widget_pinned: Some(true),
            ..SettingsPatch::default()
        };
        patch.apply(&mut s);
        assert!(s.float_bar_enabled);
        assert_eq!(s.float_bar_opacity, 45);
        assert_eq!(s.float_bar_scale, 135);
        assert_eq!(s.float_bar_style, "taskbar");
        assert!(s.float_bar_dark_text);
        assert!(s.float_bar_show_reset_inline);
        assert_eq!(
            s.widget_theme,
            codexbar::settings::WidgetTheme::DeepBlue
        );
        assert!(s.widget_pinned);
        // Orientation untouched by the patch.
        assert_eq!(s.float_bar_orientation, "horizontal");
    }

    #[test]
    fn settings_patch_clamps_and_normalizes_on_apply() {
        let mut s = Settings::default();
        let patch = SettingsPatch {
            opacity: Some(250),
            scale: Some(250),
            orientation: Some("diagonal".into()),
            style: Some("glass".into()),
            ..SettingsPatch::default()
        };
        patch.apply(&mut s);
        assert_eq!(s.float_bar_opacity, 100);
        assert_eq!(s.float_bar_scale, 200);
        assert_eq!(s.float_bar_orientation, "horizontal");
        assert_eq!(s.float_bar_style, "floating");
    }

    #[test]
    fn empty_patch_leaves_settings_unchanged() {
        let original = Settings::default();
        let mut s = Settings::default();
        SettingsPatch::default().apply(&mut s);
        assert_eq!(s.float_bar_enabled, original.float_bar_enabled);
        assert_eq!(s.float_bar_opacity, original.float_bar_opacity);
        assert_eq!(s.float_bar_scale, original.float_bar_scale);
        assert_eq!(s.float_bar_orientation, original.float_bar_orientation);
        assert_eq!(s.float_bar_style, original.float_bar_style);
        assert_eq!(s.float_bar_dark_text, original.float_bar_dark_text);
        assert_eq!(
            s.float_bar_show_reset_inline,
            original.float_bar_show_reset_inline
        );
    }

    #[test]
    fn application_exit_flushes_floatbar_geometry_before_termination() {
        let events = StdMutex::new(Vec::new());

        flush_then(
            || events.lock().unwrap().push("flush"),
            || events.lock().unwrap().push("exit"),
        );

        assert_eq!(*events.lock().unwrap(), vec!["flush", "exit"]);
    }
}
