use std::sync::{LazyLock, Mutex};

use codexbar::settings::Settings;

static SETTINGS_MUTATION: LazyLock<Mutex<()>> = LazyLock::new(|| Mutex::new(()));

fn serialize<T>(operation: impl FnOnce() -> Result<T, String>) -> Result<T, String> {
    let _guard = SETTINGS_MUTATION
        .lock()
        .map_err(|_| "settings mutation lock is poisoned".to_string())?;
    operation()
}

/// Keep the complete load/modify/save sequence under the process-wide
/// settings mutation lock. Generic I/O hooks keep the transaction itself
/// testable without touching the user's real settings file.
fn mutate_with_io<S, T>(
    load: impl FnOnce() -> S,
    operation: impl FnOnce(&mut S) -> Result<T, String>,
    save: impl FnOnce(&S) -> Result<(), String>,
) -> Result<(S, T), String> {
    serialize(|| {
        let mut settings = load();
        let value = operation(&mut settings)?;
        save(&settings)?;
        Ok((settings, value))
    })
}

/// Canonical app-owned settings writer. Callers receive the exact snapshot
/// that was saved so post-save window/tray work can happen after the lock is
/// released without reloading a potentially different file.
pub(crate) fn mutate<T>(
    operation: impl FnOnce(&mut Settings) -> Result<T, String>,
) -> Result<(Settings, T), String> {
    mutate_with_io(Settings::load_persisted, operation, |settings| {
        settings.save().map_err(|error| error.to_string())
    })
}

/// Read a persisted value without racing a settings-file save. The returned
/// value must be owned so no reference escapes the process-wide lock.
pub(crate) fn read<T>(operation: impl FnOnce(&Settings) -> T) -> Result<T, String> {
    serialize(|| {
        let settings = Settings::load_persisted();
        Ok(operation(&settings))
    })
}

/// Variant for the widget-pin transaction, whose persistence step also
/// updates in-memory widget policy under the fixed lock order:
/// settings mutation lock -> widget state lock.
pub(crate) fn mutate_with_save<T>(
    operation: impl FnOnce(&mut Settings) -> Result<T, String>,
    save: impl FnOnce(&Settings) -> Result<(), String>,
) -> Result<(Settings, T), String> {
    mutate_with_io(Settings::load_persisted, operation, save)
}

#[cfg(test)]
mod tests {
    use super::{mutate_with_io, serialize};
    use std::sync::{
        Arc, Barrier,
        atomic::{AtomicUsize, Ordering},
        mpsc,
    };
    use std::time::Duration;

    #[test]
    fn settings_mutations_share_one_process_wide_critical_section() {
        let start = Arc::new(Barrier::new(3));
        let inside = Arc::new(AtomicUsize::new(0));
        let max_inside = Arc::new(AtomicUsize::new(0));
        let mut workers = Vec::new();

        for _ in 0..2 {
            let start = Arc::clone(&start);
            let inside = Arc::clone(&inside);
            let max_inside = Arc::clone(&max_inside);
            workers.push(std::thread::spawn(move || {
                start.wait();
                serialize(|| {
                    let active = inside.fetch_add(1, Ordering::SeqCst) + 1;
                    max_inside.fetch_max(active, Ordering::SeqCst);
                    std::thread::sleep(Duration::from_millis(20));
                    inside.fetch_sub(1, Ordering::SeqCst);
                    Ok::<_, String>(())
                })
                .unwrap();
            }));
        }

        start.wait();
        for worker in workers {
            worker.join().unwrap();
        }
        assert_eq!(max_inside.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn shared_helper_serializes_the_complete_load_modify_save_transaction() {
        let first_loaded = Arc::new(Barrier::new(2));
        let release_first = Arc::new(Barrier::new(2));
        let (second_loaded_tx, second_loaded_rx) = mpsc::channel();

        let first_loaded_worker = Arc::clone(&first_loaded);
        let release_first_worker = Arc::clone(&release_first);
        let first = std::thread::spawn(move || {
            mutate_with_io(
                || {
                    first_loaded_worker.wait();
                    (0_u8, 0_u8)
                },
                |settings| {
                    settings.0 = 1;
                    release_first_worker.wait();
                    Ok::<_, String>(())
                },
                |_| Ok::<_, String>(()),
            )
            .unwrap();
        });

        first_loaded.wait();
        let second = std::thread::spawn(move || {
            mutate_with_io(
                || {
                    second_loaded_tx.send(()).unwrap();
                    (0_u8, 0_u8)
                },
                |settings| {
                    settings.1 = 1;
                    Ok::<_, String>(())
                },
                |_| Ok::<_, String>(()),
            )
            .unwrap();
        });

        assert!(
            second_loaded_rx
                .recv_timeout(Duration::from_millis(50))
                .is_err(),
            "a second writer must not load until the first writer has saved"
        );
        release_first.wait();
        first.join().unwrap();
        second_loaded_rx
            .recv_timeout(Duration::from_secs(1))
            .unwrap();
        second.join().unwrap();
    }

    #[test]
    fn every_desktop_settings_writer_routes_through_the_shared_transaction() {
        let writer_sources = [
            ("floatbar/mod.rs", include_str!("floatbar/mod.rs"), 1),
            (
                "floatbar/commands.rs",
                include_str!("floatbar/commands.rs"),
                6,
            ),
            ("tray_bridge.rs", include_str!("tray_bridge.rs"), 1),
            (
                "commands/provider_settings.rs",
                include_str!("commands/provider_settings.rs"),
                5,
            ),
            (
                "commands/locale_cmd.rs",
                include_str!("commands/locale_cmd.rs"),
                1,
            ),
            (
                "commands/credential_detection.rs",
                include_str!("commands/credential_detection.rs"),
                1,
            ),
            (
                "commands/settings.rs",
                include_str!("commands/settings.rs"),
                1,
            ),
        ];

        for (path, source, expected_transactions) in writer_sources {
            assert_eq!(
                source.matches("settings_mutation::mutate").count(),
                expected_transactions,
                "{path} must keep every settings writer on the shared transaction helper"
            );
            assert!(
                !source.contains("let mut settings = Settings::load()"),
                "{path} must not introduce an unlocked load/modify/save writer"
            );
        }
    }
}
