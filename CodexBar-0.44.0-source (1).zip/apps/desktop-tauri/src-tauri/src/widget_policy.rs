#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct WidgetState {
    pub pinned: bool,
    pub dragging: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WidgetEvent {
    FocusLost,
    DragStarted,
    DragEnded,
    PinChanged(bool),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WidgetAction {
    KeepVisible,
    Collapse,
    SuspendVisualUpdates,
    ResumeVisualUpdates,
}

pub fn decide(state: WidgetState, event: WidgetEvent) -> WidgetAction {
    match event {
        WidgetEvent::FocusLost if !state.pinned && !state.dragging => WidgetAction::Collapse,
        WidgetEvent::DragStarted => WidgetAction::SuspendVisualUpdates,
        WidgetEvent::DragEnded => WidgetAction::ResumeVisualUpdates,
        WidgetEvent::PinChanged(pinned) => {
            let _pin_transition = (state.pinned, pinned);
            WidgetAction::KeepVisible
        }
        _ => WidgetAction::KeepVisible,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn focus_loss_collapses_only_when_unpinned_and_not_dragging() {
        assert_eq!(
            decide(
                WidgetState {
                    pinned: false,
                    dragging: false,
                },
                WidgetEvent::FocusLost,
            ),
            WidgetAction::Collapse,
        );
        assert_eq!(
            decide(
                WidgetState {
                    pinned: true,
                    dragging: false,
                },
                WidgetEvent::FocusLost,
            ),
            WidgetAction::KeepVisible,
        );
        assert_eq!(
            decide(
                WidgetState {
                    pinned: false,
                    dragging: true,
                },
                WidgetEvent::FocusLost,
            ),
            WidgetAction::KeepVisible,
        );
    }

    #[test]
    fn drag_suspends_then_resumes_visual_commits() {
        assert_eq!(
            decide(WidgetState::default(), WidgetEvent::DragStarted),
            WidgetAction::SuspendVisualUpdates,
        );
        assert_eq!(
            decide(
                WidgetState {
                    dragging: true,
                    ..WidgetState::default()
                },
                WidgetEvent::DragEnded,
            ),
            WidgetAction::ResumeVisualUpdates,
        );
    }

    #[test]
    fn pin_changes_do_not_collapse_or_suspend_the_widget() {
        assert_eq!(
            decide(WidgetState::default(), WidgetEvent::PinChanged(true)),
            WidgetAction::KeepVisible,
        );
        assert_eq!(
            decide(
                WidgetState {
                    pinned: true,
                    ..WidgetState::default()
                },
                WidgetEvent::PinChanged(false),
            ),
            WidgetAction::KeepVisible,
        );
    }
}
