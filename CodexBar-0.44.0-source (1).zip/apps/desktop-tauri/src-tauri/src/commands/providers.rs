use super::*;
use std::sync::Arc;

const MAX_CONCURRENT_PROVIDER_FETCHES: usize = 8;

// ── Provider refresh commands ────────────────────────────────────────

/// Build a `FetchContext` for a provider using persisted cookies/keys.
pub(crate) fn build_fetch_context(
    id: ProviderId,
    settings: &Settings,
    cookies: &ManualCookies,
    api_keys: &ApiKeys,
    token_accounts: &HashMap<ProviderId, ProviderAccountData>,
) -> FetchContext {
    let cookie_source = settings.cookie_source(id);
    let stored_cookie = cookies.get(id.cli_name()).map(|s| s.to_string());
    let stored_api_key = api_keys.get(id.cli_name()).map(|s| s.to_string());
    let token_override = token_accounts
        .get(&id)
        .and_then(|data| data.active_account())
        .cloned()
        .map(|account| TokenAccountOverride::from_account(id, account));
    let active_token_cookie = token_override
        .as_ref()
        .and_then(|override_data| override_data.cookie_header.clone());
    let active_token_env = token_override
        .as_ref()
        .and_then(|override_data| override_data.env_override.as_ref());
    let active_token_api_key = active_token_env.and_then(|env| env.values().next().cloned());
    let usage_source = SourceMode::parse(settings.usage_source(id)).unwrap_or_default();
    let api_key = stored_api_key.or(active_token_api_key);
    let has_kimi_code_api_key =
        id == ProviderId::Kimi && api_key.as_deref().is_some_and(|key| !key.trim().is_empty());

    let (source_mode, cookie_header) = if id.cookie_domain().is_none() {
        let source_mode = if active_token_env.is_some() {
            SourceMode::OAuth
        } else {
            usage_source
        };
        (source_mode, None)
    } else {
        match cookie_source {
            _ if active_token_env.is_some() => (SourceMode::OAuth, None),
            "off" if id == ProviderId::Claude && usage_source != SourceMode::Cli => {
                (SourceMode::OAuth, None)
            }
            "off" if has_kimi_code_api_key && usage_source == SourceMode::Auto => {
                (SourceMode::Auto, None)
            }
            // Droid/Factory: cookie-off must never scrape browser cookies. Map to
            // Cli (API-only in the provider) so Auto does not fall through to web.
            "off" if id == ProviderId::Factory => (SourceMode::Cli, None),
            "off" => (SourceMode::Cli, None),
            "manual" => {
                let cookie_header = active_token_cookie.or(stored_cookie);
                let source_mode = if has_kimi_code_api_key && usage_source == SourceMode::Auto {
                    SourceMode::Auto
                } else if cookie_header.is_some() {
                    SourceMode::Web
                } else if id == ProviderId::Claude && usage_source != SourceMode::Cli {
                    SourceMode::OAuth
                } else {
                    SourceMode::Cli
                };
                (source_mode, cookie_header)
            }
            // `browser` is accepted as a legacy alias from older settings.
            "auto" | "browser" | "web" => {
                // Try browser cookie extraction as fallback when no manual cookie is set.
                // On non-Windows this is a harmless no-op that returns an error.
                let cookie_header = active_token_cookie.or(stored_cookie).or_else(|| {
                    provider_cookie_domain(id, settings).and_then(|domain| {
                        codexbar::browser::cookies::get_cookie_header(domain)
                            .ok()
                            .filter(|h| !h.is_empty())
                    })
                });
                (usage_source, cookie_header)
            }
            _ => (usage_source, stored_cookie),
        }
    };

    let workspace_id = settings.workspace_id(id).trim().to_string();
    let api_region = settings.api_region(id).trim().to_string();
    let gateway_url = (id == ProviderId::Wayfinder && !settings.gateway_url(id).is_empty())
        .then(|| settings.gateway_url(id).to_string());

    FetchContext {
        source_mode,
        manual_cookie_header: cookie_header,
        api_key,
        workspace_id: (!workspace_id.is_empty()).then_some(workspace_id),
        api_region: (!api_region.is_empty()).then_some(api_region),
        gateway_url,
        ..FetchContext::default()
    }
}

pub(crate) fn provider_cookie_domain(id: ProviderId, settings: &Settings) -> Option<&'static str> {
    if id == ProviderId::MiniMax {
        return Some(
            codexbar::providers::MiniMaxProvider::cookie_domain_for_region(Some(
                settings.api_region(id),
            )),
        );
    }
    if id == ProviderId::Alibaba {
        return Some(
            codexbar::providers::AlibabaProvider::cookie_domain_for_region(Some(
                settings.api_region(id),
            )),
        );
    }
    id.cookie_domain()
}

const DEFAULT_PROVIDER_FETCH_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(35);
const SLOW_PROVIDER_FETCH_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(75);
const MAX_CONTEXT_FETCH_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(65);

pub(crate) fn provider_fetch_timeout(id: ProviderId, ctx: &FetchContext) -> std::time::Duration {
    let provider_timeout = match id {
        ProviderId::Claude | ProviderId::Codex | ProviderId::Copilot => SLOW_PROVIDER_FETCH_TIMEOUT,
        _ => DEFAULT_PROVIDER_FETCH_TIMEOUT,
    };
    let context_timeout = std::time::Duration::from_secs(ctx.web_timeout.saturating_add(5));
    provider_timeout.max(context_timeout.min(MAX_CONTEXT_FETCH_TIMEOUT))
}

pub(crate) fn is_provider_cache_fresh(
    updated_at: Option<std::time::Instant>,
    stale_after: std::time::Duration,
) -> bool {
    updated_at
        .map(|updated| updated.elapsed() <= stale_after)
        .unwrap_or(false)
}

pub(crate) fn upsert_provider_cache(
    cache: &mut Vec<ProviderUsageSnapshot>,
    snapshot: ProviderUsageSnapshot,
) {
    if let Some(existing) = cache
        .iter_mut()
        .find(|existing| existing.provider_id == snapshot.provider_id)
    {
        *existing = snapshot;
    } else {
        cache.push(snapshot);
    }
}

/// Drop cached snapshots for providers that are no longer enabled.
pub(crate) fn prune_provider_cache_to_enabled(
    cache: &mut Vec<ProviderUsageSnapshot>,
    enabled_ids: &[ProviderId],
) {
    cache.retain(|snapshot| {
        enabled_ids
            .iter()
            .any(|id| id.cli_name() == snapshot.provider_id)
    });
}

/// Invalidate in-flight publish work and remove disabled providers from cache.
///
/// Also clears the refresh lock so a follow-up force refresh can start immediately
/// (otherwise `begin_provider_refresh` no-ops while a superseded batch still holds
/// `is_refreshing`, and newly enabled providers never get a replacement run).
pub(crate) fn invalidate_provider_refresh_and_prune_disabled(
    state: &tauri::State<'_, Mutex<AppState>>,
    enabled_ids: &[ProviderId],
) -> Result<(), String> {
    invalidate_provider_refresh_state(state.inner(), enabled_ids)
}

pub(super) fn invalidate_provider_refresh_state(
    state: &Mutex<AppState>,
    enabled_ids: &[ProviderId],
) -> Result<(), String> {
    let publication_gate = provider_refresh_publication_gate(state)?;
    let _publication = publication_gate.lock().map_err(|e| e.to_string())?;
    let mut guard = state.lock().map_err(|e| e.to_string())?;
    guard.provider_refresh_generation = guard.provider_refresh_generation.wrapping_add(1);
    guard.is_refreshing = false;
    guard.provider_refresh_started_at = None;
    prune_provider_cache_to_enabled(&mut guard.provider_cache, enabled_ids);
    // Drop transient-failure counters for providers that left the enabled set.
    guard
        .transient_provider_failure_counts
        .retain(|id, _| enabled_ids.contains(id));
    Ok(())
}

pub(crate) fn is_current_provider_refresh_generation(guard: &AppState, generation: u64) -> bool {
    guard.provider_refresh_generation == generation
}

fn provider_refresh_publication_gate(
    state: &Mutex<AppState>,
) -> Result<Arc<Mutex<()>>, String> {
    let guard = state.lock().map_err(|e| e.to_string())?;
    Ok(Arc::clone(&guard.provider_refresh_publication_gate))
}

/// Serialize a generation check with externally visible publication.
///
/// Generation mutators acquire the same gate, so once the callback starts no
/// successor generation can begin until it returns. AppState is checked and
/// released before the callback, keeping window/tray calls outside its lock.
pub(super) fn with_current_provider_publication<R>(
    state: &Mutex<AppState>,
    generation: u64,
    publish: impl FnOnce() -> R,
) -> Result<Option<R>, String> {
    let publication_gate = provider_refresh_publication_gate(state)?;
    let _publication = publication_gate.lock().map_err(|e| e.to_string())?;
    {
        let guard = state.lock().map_err(|e| e.to_string())?;
        if !is_current_provider_refresh_generation(&guard, generation) {
            return Ok(None);
        }
    }
    Ok(Some(publish()))
}

/// Core refresh logic, usable from both the Tauri command and tray menu actions.
pub(crate) async fn do_refresh_providers(app: &tauri::AppHandle) -> Result<(), String> {
    do_refresh_providers_with_policy(app, true).await
}

pub(crate) async fn do_refresh_providers_if_stale(app: &tauri::AppHandle) -> Result<(), String> {
    do_refresh_providers_with_policy(app, false).await
}

async fn do_refresh_providers_with_policy(
    app: &tauri::AppHandle,
    force: bool,
) -> Result<(), String> {
    let state = app.state::<Mutex<AppState>>();

    let Some(generation) = begin_provider_refresh(state.inner(), force)? else {
        return Ok(());
    };

    let inputs = ProviderRefreshInputs::load();
    let started = with_current_provider_publication(state.inner(), generation, || {
        {
            let mut guard = state.lock().map_err(|e| e.to_string())?;
            prune_provider_cache_to_enabled(&mut guard.provider_cache, &inputs.enabled_ids);
        }
        events::emit_refresh_started(
            app,
            inputs
                .enabled_ids
                .iter()
                .map(|id| id.cli_name().to_string())
                .collect(),
        );
        Ok::<(), String>(())
    })?;
    let Some(started) = started else {
        // Inputs were loaded after this generation was invalidated. Publishing
        // a late "started" would leave the frontend paired with another batch.
        return Ok(());
    };
    started?;
    let enabled_count = inputs.enabled_ids.len();

    let handles = spawn_provider_refreshes(app, &inputs, generation);
    await_provider_refreshes(handles).await;

    let published = with_current_provider_publication(state.inner(), generation, || {
        let (error_count, cached) = {
            let guard = state.lock().map_err(|e| e.to_string())?;
            let error_count = guard
                .provider_cache
                .iter()
                .filter(|snapshot| snapshot.error.is_some())
                .count();
            (error_count, guard.provider_cache.clone())
        };

        update_tray_and_notifications(
            app,
            state.inner(),
            generation,
            &inputs.settings,
            &inputs.token_accounts,
            &cached,
        )?;
        events::emit_refresh_complete(app, enabled_count, error_count);
        crate::auto_refresh::schedule_refresh_enrichment(&inputs.settings);

        let mut guard = state.lock().map_err(|e| e.to_string())?;
        guard.is_refreshing = false;
        guard.provider_refresh_started_at = None;
        guard.provider_cache_updated_at = Some(std::time::Instant::now());
        Ok::<(), String>(())
    })?;
    let Some(published) = published else {
        // Superseded by a newer generation (or invalidate). Do not clear UI
        // "refreshing" or publish tray/events/enrichment for dead work.
        return Ok(());
    };
    published?;

    Ok(())
}

pub(super) fn begin_provider_refresh(
    state: &Mutex<AppState>,
    force: bool,
) -> Result<Option<u64>, String> {
    let publication_gate = provider_refresh_publication_gate(state)?;
    let _publication = publication_gate.lock().map_err(|e| e.to_string())?;
    let mut guard = state.lock().map_err(|e| e.to_string())?;
    if guard.is_refreshing {
        return Ok(None);
    }
    if provider_cache_can_skip_refresh(&guard, force) {
        return Ok(None);
    }

    guard.provider_refresh_generation = guard.provider_refresh_generation.wrapping_add(1);
    let generation = guard.provider_refresh_generation;
    guard.is_refreshing = true;
    guard.provider_refresh_started_at = Some(std::time::Instant::now());
    Ok(Some(generation))
}

fn provider_cache_can_skip_refresh(guard: &AppState, force: bool) -> bool {
    !force
        && !guard.provider_cache.is_empty()
        && is_provider_cache_fresh(guard.provider_cache_updated_at, PROVIDER_CACHE_STALE_AFTER)
}

struct ProviderRefreshInputs {
    settings: Settings,
    enabled_ids: Vec<ProviderId>,
    manual_cookies: ManualCookies,
    api_keys: ApiKeys,
    token_accounts: HashMap<ProviderId, ProviderAccountData>,
}

impl ProviderRefreshInputs {
    fn load() -> Self {
        let settings = Settings::load();
        let enabled_ids = settings.get_enabled_provider_ids();
        let manual_cookies = ManualCookies::load();
        let api_keys = ApiKeys::load();
        let token_accounts = TokenAccountStore::new().load().unwrap_or_else(|e| {
            tracing::warn!("failed to load token accounts for provider refresh: {e}");
            HashMap::new()
        });

        Self {
            settings,
            enabled_ids,
            manual_cookies,
            api_keys,
            token_accounts,
        }
    }
}

fn spawn_provider_refreshes(
    app: &tauri::AppHandle,
    inputs: &ProviderRefreshInputs,
    generation: u64,
) -> Vec<tokio::task::JoinHandle<()>> {
    let mut handles = Vec::with_capacity(inputs.enabled_ids.len());
    let fetch_permits = Arc::new(tokio::sync::Semaphore::new(MAX_CONCURRENT_PROVIDER_FETCHES));

    for id in &inputs.enabled_ids {
        let id = *id;
        let app_handle = app.clone();
        let fetch_permits = Arc::clone(&fetch_permits);
        let ctx = build_fetch_context(
            id,
            &inputs.settings,
            &inputs.manual_cookies,
            &inputs.api_keys,
            &inputs.token_accounts,
        );

        handles.push(tokio::spawn(async move {
            let Ok(_permit) = fetch_permits.acquire_owned().await else {
                return;
            };
            refresh_provider(app_handle, id, ctx, generation).await;
        }));
    }

    handles
}

async fn refresh_provider(
    app: tauri::AppHandle,
    id: ProviderId,
    ctx: FetchContext,
    generation: u64,
) {
    let outcome = fetch_provider_snapshot(id, ctx).await;

    let state = app.state::<Mutex<AppState>>();
    match publish_provider_refresh_result(state.inner(), generation, id, outcome, |snapshot| {
        events::emit_provider_updated(&app, snapshot);
    }) {
        Ok(ProviderRefreshDisposition::Superseded) => {
            let current = state
                .lock()
                .map(|guard| guard.provider_refresh_generation)
                .unwrap_or_default();
            tracing::debug!(
                provider = id.cli_name(),
                generation,
                current,
                "dropping superseded provider refresh result"
            );
        }
        Ok(ProviderRefreshDisposition::CredentialIdentityChanged) => {
            tracing::info!(
                provider = id.cli_name(),
                generation,
                "dropping provider refresh result after credential identity changed"
            );
        }
        Ok(ProviderRefreshDisposition::Published) => {}
        Err(error) => {
            tracing::warn!(
                provider = id.cli_name(),
                generation,
                "failed to publish provider refresh result: {error}"
            );
        }
    }
}

enum ProviderFetchOutcome {
    Publish(ProviderUsageSnapshot),
    CredentialIdentityChanged,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ProviderRefreshDisposition {
    Published,
    Superseded,
    CredentialIdentityChanged,
}

fn publish_provider_refresh_result(
    state: &Mutex<AppState>,
    generation: u64,
    id: ProviderId,
    outcome: ProviderFetchOutcome,
    publish_event: impl FnOnce(&ProviderUsageSnapshot),
) -> Result<ProviderRefreshDisposition, String> {
    let ProviderFetchOutcome::Publish(snapshot) = outcome else {
        return Ok(ProviderRefreshDisposition::CredentialIdentityChanged);
    };

    let published = with_current_provider_publication(state, generation, || {
        let snapshot = {
            let mut guard = state.lock().map_err(|e| e.to_string())?;
            let snapshot = preserve_last_good_transient_failure(&mut guard, id, snapshot);
            upsert_provider_cache(&mut guard.provider_cache, snapshot.clone());
            snapshot
        };
        publish_event(&snapshot);
        Ok::<(), String>(())
    })?;

    match published {
        None => Ok(ProviderRefreshDisposition::Superseded),
        Some(result) => {
            result?;
            Ok(ProviderRefreshDisposition::Published)
        }
    }
}

pub(super) fn preserve_last_good_transient_failure(
    guard: &mut AppState,
    id: ProviderId,
    snapshot: ProviderUsageSnapshot,
) -> ProviderUsageSnapshot {
    if snapshot.error.is_none() {
        guard.transient_provider_failure_counts.remove(&id);
        return snapshot;
    }

    if id == ProviderId::Codex && !is_codex_authentication_error(snapshot.error.as_deref()) {
        guard.transient_provider_failure_counts.remove(&id);
        let current_account_id = snapshot.credential_account_id.as_deref();
        if let Some(mut previous) = guard
            .provider_cache
            .iter()
            .find(|cached| {
                cached.provider_id == id.cli_name()
                    && !cached.primary.is_informational
                    && current_account_id.is_some()
                    && cached.credential_account_id.as_deref() == current_account_id
            })
            .cloned()
        {
            previous.error = snapshot.error;
            previous.fetch_duration_ms = snapshot.fetch_duration_ms;
            tracing::warn!(
                provider = id.cli_name(),
                "preserving last good quota after ordinary refresh failure"
            );
            return previous;
        }
        return snapshot;
    }

    if id != ProviderId::Claude || !is_transient_claude_auth_error(snapshot.error.as_deref()) {
        guard.transient_provider_failure_counts.remove(&id);
        return snapshot;
    }

    let Some(previous) = guard
        .provider_cache
        .iter()
        .find(|cached| cached.provider_id == id.cli_name() && cached.error.is_none())
        .cloned()
    else {
        return snapshot;
    };

    let count = guard
        .transient_provider_failure_counts
        .entry(id)
        .or_insert(0);
    if *count == 0 {
        *count = 1;
        tracing::warn!(
            provider = id.cli_name(),
            "preserving last good provider snapshot after transient auth failure"
        );
        previous
    } else {
        *count = count.saturating_add(1);
        snapshot
    }
}

fn is_codex_authentication_error(error: Option<&str>) -> bool {
    let Some(error) = error else {
        return false;
    };
    let lower = error.to_ascii_lowercase();
    [
        "auth.json not found",
        "authentication required",
        "auth required",
        "login required",
        "sign in required",
        "sign-in required",
        "not logged in",
        "unauthorized",
        "forbidden",
        "token expired",
        "token invalid",
        "invalid codex credentials json",
        "contains no tokens",
        "missing access_token",
    ]
    .iter()
    .any(|marker| lower.contains(marker))
}

fn is_transient_claude_auth_error(error: Option<&str>) -> bool {
    let Some(error) = error else {
        return false;
    };
    let lower = error.to_ascii_lowercase();
    lower.contains("unauthorized")
        || lower.contains("authentication required")
        || lower.contains("auth required")
        || lower.contains("oauth")
}

fn stable_codex_credential_account_id(
    before_fetch: Option<String>,
    after_fetch: Option<String>,
) -> Option<String> {
    match (before_fetch, after_fetch) {
        (Some(before), Some(after)) if before == after => Some(after),
        _ => None,
    }
}

fn finalize_provider_fetch(
    id: ProviderId,
    credential_account_id_before: Option<String>,
    credential_account_id_after: Option<String>,
    mut snapshot: ProviderUsageSnapshot,
) -> ProviderFetchOutcome {
    if id != ProviderId::Codex {
        return ProviderFetchOutcome::Publish(snapshot);
    }

    if credential_account_id_before != credential_account_id_after {
        return ProviderFetchOutcome::CredentialIdentityChanged;
    }

    let stable_credential_account_id = stable_codex_credential_account_id(
        credential_account_id_before,
        credential_account_id_after,
    );
    snapshot.credential_account_id = snapshot
        .credential_account_id
        .or(stable_credential_account_id);
    ProviderFetchOutcome::Publish(snapshot)
}

async fn fetch_provider_snapshot(id: ProviderId, ctx: FetchContext) -> ProviderFetchOutcome {
    // Capture only the provider-native account id, never the token. Re-read it
    // after the await so a result fetched with old credentials cannot publish
    // after auth.json changes while the request is in flight.
    let credential_account_id_before = (id == ProviderId::Codex)
        .then(|| codexbar::providers::CodexApi::new().current_credential_account_id())
        .flatten();
    let provider = instantiate_provider(id);
    let metadata = provider.metadata().clone();
    let started = std::time::Instant::now();

    let mut snapshot =
        match tokio::time::timeout(provider_fetch_timeout(id, &ctx), provider.fetch_usage(&ctx))
            .await
        {
            Ok(Ok(result)) => ProviderUsageSnapshot::from_fetch_result(id, &metadata, &result),
            Ok(Err(e)) => ProviderUsageSnapshot::from_error(
                id,
                &metadata,
                codexbar::logging::safe_error_message(e),
            ),
            Err(_) => ProviderUsageSnapshot::from_error(id, &metadata, "Timeout".to_string()),
        };

    record_provider_fetch_duration(id, &mut snapshot, started);
    let credential_account_id_after = (id == ProviderId::Codex)
        .then(|| codexbar::providers::CodexApi::new().current_credential_account_id())
        .flatten();
    finalize_provider_fetch(
        id,
        credential_account_id_before,
        credential_account_id_after,
        snapshot,
    )
}

fn record_provider_fetch_duration(
    id: ProviderId,
    snapshot: &mut ProviderUsageSnapshot,
    started: std::time::Instant,
) {
    let fetch_duration_ms = started.elapsed().as_millis();
    snapshot.fetch_duration_ms = Some(fetch_duration_ms);
    if fetch_duration_ms > 5_000 {
        tracing::warn!(
            provider = id.cli_name(),
            fetch_duration_ms,
            "slow provider refresh"
        );
    }
}

async fn await_provider_refreshes(handles: Vec<tokio::task::JoinHandle<()>>) {
    for handle in handles {
        let _ = handle.await;
    }
}

fn update_tray_and_notifications(
    app: &tauri::AppHandle,
    state: &Mutex<AppState>,
    generation: u64,
    settings: &Settings,
    token_accounts: &HashMap<ProviderId, ProviderAccountData>,
    cached: &[ProviderUsageSnapshot],
) -> Result<(), String> {
    // Tray rendering can touch the windowing system, so keep it outside the
    // AppState lock. Notification publication re-checks generation separately.
    crate::tray_bridge::update_tray_status_items(app, cached);
    crate::tray_bridge::update_tray_icon_and_tooltip(app, cached);
    notify_usage_thresholds(state, generation, settings, token_accounts, cached)?;
    Ok(())
}

fn notify_usage_thresholds(
    state: &Mutex<AppState>,
    generation: u64,
    settings: &Settings,
    token_accounts: &HashMap<ProviderId, ProviderAccountData>,
    cached: &[ProviderUsageSnapshot],
) -> Result<(), String> {
    let cli_map = codexbar::core::cli_name_map();
    let mut active_lanes = Vec::new();
    let mut active_predictive_lanes = Vec::new();
    let mut active_providers = Vec::new();
    let mut uncertain_providers = Vec::new();
    for snapshot in cached {
        let Some(&provider) = cli_map.get(snapshot.provider_id.as_str()) else {
            continue;
        };
        active_providers.push(provider);
        if snapshot.error.is_some() {
            uncertain_providers.push(provider);
            continue;
        }
        let token_account_id = token_accounts
            .get(&provider)
            .and_then(ProviderAccountData::active_account)
            .map(|account| account.id);
        let account = quota_notification_account_identity(snapshot, token_account_id);
        let predictive_identity = predictive_warning_identity(
            provider,
            &snapshot.source_label,
            snapshot.account_id.as_deref(),
            snapshot.account_email.as_deref(),
            token_account_id,
        );
        for (kind, _) in usage_notification_lanes(snapshot) {
            active_lanes.push((provider, account.clone(), kind.as_str().to_string()));
            if let Some(identity) = predictive_identity.as_ref() {
                active_predictive_lanes.push((
                    provider,
                    identity.clone(),
                    predictive_window_kind(kind),
                ));
            }
        }
    }

    let manager = {
        let mut guard = state.lock().map_err(|e| e.to_string())?;
        take_current_notification_manager(&mut guard, generation)
    };
    let Some(mut manager) = manager else {
        return Ok(());
    };

    manager.retain_active_usage_lanes(
        &active_lanes,
        &active_providers,
        &uncertain_providers,
    );
    manager.retain_active_predictive_lanes(
        &active_predictive_lanes,
        &uncertain_providers,
    );
    for snapshot in cached {
        if snapshot.error.is_none()
            && let Some(&provider) = cli_map.get(snapshot.provider_id.as_str())
        {
            let token_account_id = token_accounts
                .get(&provider)
                .and_then(ProviderAccountData::active_account)
                .map(|account| account.id);
            let account = quota_notification_account_identity(snapshot, token_account_id);
            for (kind, window) in usage_notification_lanes(snapshot) {
                let window_name = kind.as_str();
                let reset_cycle = tracked_quota_reset_cycle(
                    &mut manager,
                    provider,
                    &account,
                    window_name,
                    window,
                );
                manager.check_and_notify(
                    provider,
                    &account,
                    window_name,
                    &reset_cycle,
                    window.used_percent,
                    settings,
                );
                if kind == RateWindowKind::Session {
                    manager.check_session_transition(
                        provider,
                        &account,
                        window.used_percent,
                        settings,
                    );
                }
            }
            notify_predictive_pace(
                &mut manager,
                provider,
                snapshot,
                token_accounts,
                settings,
            );
        }
    }

    let mut guard = state.lock().map_err(|e| e.to_string())?;
    if is_current_provider_refresh_generation(&guard, generation) {
        guard.notification_manager = manager;
    } else {
        tracing::debug!(
            generation,
            current = guard.provider_refresh_generation,
            "dropping notification state from superseded provider publication"
        );
    }
    Ok(())
}

pub(super) fn usage_notification_lanes(
    snapshot: &ProviderUsageSnapshot,
) -> Vec<(RateWindowKind, &RateWindowSnapshot)> {
    let mut lanes = Vec::with_capacity(2);
    if !snapshot.primary.is_informational {
        lanes.push((snapshot.primary_window_kind, &snapshot.primary));
    }
    if snapshot.primary_window_kind != RateWindowKind::Weekly
        && let Some(secondary) = snapshot
            .secondary
            .as_ref()
            .filter(|window| !window.is_informational)
    {
        lanes.push((RateWindowKind::Weekly, secondary));
    }
    lanes
}

fn predictive_window_kind(
    kind: RateWindowKind,
) -> codexbar::notifications::PredictiveWarningWindow {
    match kind {
        RateWindowKind::Session => {
            codexbar::notifications::PredictiveWarningWindow::Session
        }
        RateWindowKind::Weekly => {
            codexbar::notifications::PredictiveWarningWindow::Weekly
        }
    }
}

/// Move notification state out of AppState only when this batch still owns the
/// generation. The caller can then dispatch external notifications without
/// holding AppState; the outer provider publication gate prevents a successor
/// generation until the state is restored.
pub(super) fn take_current_notification_manager(
    guard: &mut AppState,
    generation: u64,
) -> Option<codexbar::notifications::NotificationManager> {
    if !is_current_provider_refresh_generation(guard, generation) {
        return None;
    }
    Some(std::mem::take(&mut guard.notification_manager))
}

const PROCESS_LIFETIME_RESET_CYCLE: &str = "process-lifetime";

/// Stable reset-cycle discriminator for threshold notification dedupe.
/// Absolute reset timestamps are preferred because human-readable provider
/// descriptions may be localized or rounded. The fallback is intentionally
/// process-local: without reset metadata there is no safe cycle to infer.
fn tracked_quota_reset_cycle(
    manager: &mut codexbar::notifications::NotificationManager,
    provider: ProviderId,
    account: &str,
    window_name: &str,
    window: &RateWindowSnapshot,
) -> String {
    if let Some(value) = window
        .resets_at
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
    {
        return manager.normalize_threshold_reset_cycle(
            provider,
            account,
            window_name,
            value,
            window.window_minutes,
        );
    }

    quota_reset_cycle(window)
}

fn quota_reset_cycle(window: &RateWindowSnapshot) -> String {
    window
        .resets_at
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(|value| format!("resets-at:{value}"))
        .or_else(|| {
            window
                .reset_description
                .as_deref()
                .map(str::trim)
                .filter(|value| is_stable_reset_description(value))
                .map(|value| format!("description:{value}"))
        })
        .unwrap_or_else(|| PROCESS_LIFETIME_RESET_CYCLE.to_string())
}

/// Returns true only when a description identifies a fixed reset point.
/// Dynamic quota counters and relative countdowns intentionally fall back to
/// the process-lifetime lane so routine refreshes cannot re-arm notifications.
fn is_stable_reset_description(description: &str) -> bool {
    let value = description.trim();
    if value.is_empty() {
        return false;
    }
    if chrono::DateTime::parse_from_rfc3339(value).is_ok() {
        return true;
    }

    let lower = value.to_lowercase();
    let dynamic_quota_terms = [
        "%", "usage", "used", "remaining", "balance", "request", "token", "credit",
        "用量", "已用", "剩余", "剩餘", "余额", "餘額", "请求", "請求", "令牌",
    ];
    if dynamic_quota_terms.iter().any(|term| lower.contains(term)) {
        return false;
    }

    let has_reset_semantics = ["reset", "重置", "重設", "更新"]
        .iter()
        .any(|term| lower.contains(term));

    (has_reset_semantics && contains_iso_date(&lower))
        || (lower.contains("end") && contains_month_day(&lower))
}

fn contains_iso_date(value: &str) -> bool {
    value.as_bytes().windows(10).any(|window| {
        window[0..4].iter().all(u8::is_ascii_digit)
            && matches!(window[4], b'-' | b'/')
            && window[5..7].iter().all(u8::is_ascii_digit)
            && window[7] == window[4]
            && window[8..10].iter().all(u8::is_ascii_digit)
    })
}

fn contains_month_day(value: &str) -> bool {
    value.split_whitespace().any(|token| {
        let token = token.trim_matches(|ch: char| !ch.is_ascii_digit() && ch != '/');
        let Some((month, day)) = token.split_once('/') else {
            return false;
        };
        if day.contains('/') {
            return false;
        }
        let (Ok(month), Ok(day)) = (month.parse::<u32>(), day.parse::<u32>()) else {
            return false;
        };
        let max_day = match month {
            1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
            4 | 6 | 9 | 11 => 30,
            2 => 29,
            _ => return false,
        };
        (1..=max_day).contains(&day)
    })
}

/// Stable account discriminator for threshold/session toast dedupe.
/// Prefer token-account id, then email, org, plan; empty for single-account lanes.
fn quota_notification_account_identity(
    snapshot: &ProviderUsageSnapshot,
    token_account_id: Option<uuid::Uuid>,
) -> String {
    if let Some(id) = token_account_id {
        return format!("token-account:{}", id.as_hyphenated());
    }
    if let Some(account_id) = snapshot
        .account_id
        .as_deref()
        .map(str::trim)
        .filter(|account_id| !account_id.is_empty())
    {
        return format!("provider-account:{account_id}");
    }
    if let Some(email) = snapshot
        .account_email
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty())
    {
        return email.to_ascii_lowercase();
    }
    if let Some(org) = snapshot
        .account_organization
        .as_deref()
        .map(str::trim)
        .filter(|s| !s.is_empty())
    {
        return format!("org:{}", org.to_ascii_lowercase());
    }
    // Do not fall back to plan_name/login_method — those are display tiers and
    // flicker across refreshes, re-arming still-hot windows for a new identity.
    String::new()
}

fn notify_predictive_pace(
    manager: &mut codexbar::notifications::NotificationManager,
    provider: ProviderId,
    snapshot: &ProviderUsageSnapshot,
    token_accounts: &HashMap<ProviderId, ProviderAccountData>,
    settings: &Settings,
) {
    let enabled = settings.show_notifications && settings.predictive_pace_warning_enabled;
    manager.set_predictive_warnings_enabled(provider, enabled);
    if !enabled || !matches!(provider, ProviderId::Claude | ProviderId::Codex) {
        return;
    }

    let token_account_id = token_accounts
        .get(&provider)
        .and_then(ProviderAccountData::active_account)
        .map(|account| account.id);
    let Some(identity) = predictive_warning_identity(
        provider,
        &snapshot.source_label,
        snapshot.account_id.as_deref(),
        snapshot.account_email.as_deref(),
        token_account_id,
    ) else {
        return;
    };
    let observed_at = chrono::DateTime::parse_from_rfc3339(&snapshot.updated_at)
        .ok()
        .map(|date| date.with_timezone(&chrono::Utc));

    for (kind, window) in usage_notification_lanes(snapshot) {
        let (warning_window, default_window_minutes) = match kind {
            RateWindowKind::Session => (
                codexbar::notifications::PredictiveWarningWindow::Session,
                300,
            ),
            RateWindowKind::Weekly => (
                codexbar::notifications::PredictiveWarningWindow::Weekly,
                10080,
            ),
        };
        let rate_window = RateWindow::with_details(
            window.used_percent,
            window.window_minutes,
            window
                .resets_at
                .as_deref()
                .and_then(|value| chrono::DateTime::parse_from_rfc3339(value).ok())
                .map(|date| date.with_timezone(&chrono::Utc)),
            window.reset_description.clone(),
        );
        let Some(pace) =
            codexbar::core::UsagePace::weekly(&rate_window, observed_at, default_window_minutes)
        else {
            continue;
        };
        manager.check_predictive_pace(
            provider,
            &identity,
            warning_window,
            &rate_window,
            &pace,
            settings,
        );
    }
}

fn predictive_warning_identity(
    provider: ProviderId,
    source_label: &str,
    provider_account_id: Option<&str>,
    account_email: Option<&str>,
    token_account_id: Option<uuid::Uuid>,
) -> Option<String> {
    if !matches!(provider, ProviderId::Claude | ProviderId::Codex) {
        return None;
    }
    if let Some(id) = token_account_id {
        return Some(format!("token-account:{}", id.as_hyphenated()));
    }
    if let Some(account_id) = provider_account_id
        .map(str::trim)
        .filter(|account_id| !account_id.is_empty())
    {
        return Some(format!("provider-account:{account_id}"));
    }
    let source = source_label.trim().to_ascii_lowercase();
    let account = account_email?.trim().to_ascii_lowercase();
    if source.is_empty() || account.is_empty() {
        return None;
    }
    Some(format!("{source}:{account}"))
}

#[tauri::command]
pub async fn refresh_providers(app: tauri::AppHandle) -> Result<(), String> {
    do_refresh_providers(&app).await
}

#[tauri::command]
pub async fn refresh_providers_if_stale(app: tauri::AppHandle) -> Result<(), String> {
    do_refresh_providers_if_stale(&app).await
}

#[tauri::command]
pub fn get_cached_providers(
    state: tauri::State<'_, Mutex<AppState>>,
) -> Vec<ProviderUsageSnapshot> {
    let mut snapshots = state
        .lock()
        .map(|guard| guard.provider_cache.clone())
        .unwrap_or_default();
    let spark_usage_visible = Settings::load().codex_spark_usage_visible();
    for snapshot in &mut snapshots {
        super::filter_hidden_codex_spark_rows(snapshot, spark_usage_visible);
    }

    snapshots
}

#[cfg(test)]
mod predictive_warning_tests {
    use super::*;

    #[test]
    fn production_refresh_discards_codex_a_result_after_credentials_switch_to_b() {
        let metadata = instantiate_provider(ProviderId::Codex).metadata().clone();
        let account_a_result = ProviderFetchResult {
            usage: codexbar::core::UsageSnapshot::new(codexbar::core::RateWindow::new(91.0))
                .with_account_id("acct-a"),
            cost: None,
            wayfinder_usage: None,
            source_label: "oauth".to_string(),
        };
        let account_a = ProviderUsageSnapshot::from_fetch_result(
            ProviderId::Codex,
            &metadata,
            &account_a_result,
        );

        let account_b_result = ProviderFetchResult {
            usage: codexbar::core::UsageSnapshot::new(codexbar::core::RateWindow::new(22.0))
                .with_account_id("acct-b"),
            cost: None,
            wayfinder_usage: None,
            source_label: "oauth".to_string(),
        };
        let account_b = ProviderUsageSnapshot::from_fetch_result(
            ProviderId::Codex,
            &metadata,
            &account_b_result,
        );

        let state = Mutex::new(AppState::new());
        {
            let mut guard = state.lock().unwrap();
            guard.provider_refresh_generation = 7;
            guard.is_refreshing = true;
            guard.provider_cache.push(account_b);
        }

        let outcome = finalize_provider_fetch(
            ProviderId::Codex,
            Some("acct-a".to_string()),
            Some("acct-b".to_string()),
            account_a,
        );
        let mut emitted = false;
        let disposition = publish_provider_refresh_result(
            &state,
            7,
            ProviderId::Codex,
            outcome,
            |_| emitted = true,
        )
        .unwrap();

        assert_eq!(
            disposition,
            ProviderRefreshDisposition::CredentialIdentityChanged
        );
        assert!(!emitted, "the stale A snapshot must not publish an event");
        let guard = state.lock().unwrap();
        assert_eq!(guard.provider_cache.len(), 1);
        assert_eq!(
            guard.provider_cache[0].credential_account_id.as_deref(),
            Some("acct-b")
        );
        assert_eq!(guard.provider_cache[0].primary.used_percent, 22.0);
        assert_eq!(guard.provider_refresh_generation, 7);
        assert!(
            guard.is_refreshing,
            "discarding one provider must not invalidate or restart the batch"
        );
    }

    #[test]
    fn codex_cache_identity_requires_the_same_account_before_and_after_fetch() {
        assert_eq!(
            stable_codex_credential_account_id(
                Some("acct-a".to_string()),
                Some("acct-a".to_string()),
            ),
            Some("acct-a".to_string())
        );
        assert_eq!(
            stable_codex_credential_account_id(
                Some("acct-a".to_string()),
                Some("acct-b".to_string()),
            ),
            None
        );
        assert_eq!(
            stable_codex_credential_account_id(None, Some("acct-a".to_string())),
            None
        );
    }

    #[test]
    fn predictive_warning_identity_keeps_claude_sources_and_token_accounts_separate() {
        let account_id = uuid::Uuid::parse_str("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa").unwrap();

        assert_eq!(
            predictive_warning_identity(
                ProviderId::Claude,
                "cli",
                None,
                Some("Person@Example.com"),
                None,
            )
            .as_deref(),
            Some("cli:person@example.com")
        );
        assert_eq!(
            predictive_warning_identity(
                ProviderId::Claude,
                "oauth",
                None,
                Some("Person@Example.com"),
                None,
            )
            .as_deref(),
            Some("oauth:person@example.com")
        );
        assert_eq!(
            predictive_warning_identity(
                ProviderId::Claude,
                "oauth",
                None,
                Some("Person@Example.com"),
                Some(account_id),
            )
            .as_deref(),
            Some("token-account:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")
        );
    }

    #[test]
    fn predictive_warning_identity_skips_unidentified_accounts() {
        assert_eq!(
            predictive_warning_identity(ProviderId::Claude, "oauth", None, None, None),
            None
        );
        assert_eq!(
            predictive_warning_identity(ProviderId::Codex, "cli", None, Some("  "), None),
            None
        );
    }

    fn empty_snapshot() -> ProviderUsageSnapshot {
        let metadata = codexbar::core::instantiate_provider(ProviderId::Claude)
            .metadata()
            .clone();
        ProviderUsageSnapshot::from_error(ProviderId::Claude, &metadata, "unused".to_string())
    }

    fn tracked_reset_cycle(
        manager: &mut codexbar::notifications::NotificationManager,
        window: &RateWindowSnapshot,
    ) -> String {
        tracked_quota_reset_cycle(
            manager,
            ProviderId::Claude,
            "account-a",
            "session",
            window,
        )
    }

    #[test]
    fn quota_notification_account_identity_prefers_token_then_email() {
        let account_id = uuid::Uuid::parse_str("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa").unwrap();
        let mut snapshot = empty_snapshot();
        snapshot.account_email = Some("Person@Example.com".to_string());
        snapshot.account_organization = Some("Acme Org".to_string());
        snapshot.plan_name = Some("Pro".to_string());

        assert_eq!(
            quota_notification_account_identity(&snapshot, Some(account_id)),
            "token-account:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
        );
        assert_eq!(
            quota_notification_account_identity(&snapshot, None),
            "person@example.com"
        );

        snapshot.account_email = None;
        assert_eq!(
            quota_notification_account_identity(&snapshot, None),
            "org:acme org"
        );

        snapshot.account_organization = None;
        // plan_name/login_method is not a stable ownership key — fall through to "".
        assert_eq!(quota_notification_account_identity(&snapshot, None), "");

        snapshot.plan_name = None;
        assert_eq!(quota_notification_account_identity(&snapshot, None), "");
    }

    #[test]
    fn quota_reset_cycle_prefers_timestamp_then_stable_description_then_process_lane() {
        let mut snapshot = empty_snapshot();
        snapshot.primary.resets_at = Some("2026-07-20T05:00:00Z".to_string());
        snapshot.primary.reset_description =
            Some("Resets at 05:00 UTC on 2026-07-20".to_string());
        assert_eq!(
            quota_reset_cycle(&snapshot.primary),
            "resets-at:2026-07-20T05:00:00Z"
        );

        snapshot.primary.resets_at = None;
        assert_eq!(
            quota_reset_cycle(&snapshot.primary),
            "description:Resets at 05:00 UTC on 2026-07-20"
        );

        snapshot.primary.reset_description = None;
        assert_eq!(
            quota_reset_cycle(&snapshot.primary),
            PROCESS_LIFETIME_RESET_CYCLE
        );
    }

    #[test]
    fn quota_reset_cycle_ignores_dynamic_usage_and_balance_descriptions() {
        let mut snapshot = empty_snapshot();
        snapshot.primary.reset_description = Some("81/100 requests used".to_string());
        let first_cycle = quota_reset_cycle(&snapshot.primary);
        snapshot.primary.reset_description = Some("82/100 requests used".to_string());
        let second_cycle = quota_reset_cycle(&snapshot.primary);

        assert_eq!(first_cycle, PROCESS_LIFETIME_RESET_CYCLE);
        assert_eq!(second_cycle, first_cycle);

        for description in [
            "12.34 credits remaining",
            "Balance $19.50",
            "90% used; resets at 05:00 UTC on 2026-07-20",
            "Resets in 2h",
        ] {
            assert!(!is_stable_reset_description(description), "{description}");
        }
    }

    #[test]
    fn stable_reset_descriptions_can_start_a_new_cycle() {
        let mut snapshot = empty_snapshot();
        snapshot.primary.reset_description =
            Some("Resets at 05:00 UTC on 2026-07-20".to_string());
        let first_cycle = quota_reset_cycle(&snapshot.primary);
        snapshot.primary.reset_description =
            Some("Resets at 05:00 UTC on 2026-07-27".to_string());
        let second_cycle = quota_reset_cycle(&snapshot.primary);

        assert_ne!(first_cycle, second_cycle);
        assert!(is_stable_reset_description(
            "重置时间：2026-07-27 05:00 UTC"
        ));
    }

    #[test]
    fn calculated_reset_timestamp_jitter_stays_in_one_cycle() {
        let mut manager = codexbar::notifications::NotificationManager::new();
        let mut snapshot = empty_snapshot();
        snapshot.primary.window_minutes = Some(300);
        snapshot.primary.resets_at = Some("2026-07-20T05:00:29Z".to_string());
        let first_cycle = tracked_reset_cycle(&mut manager, &snapshot.primary);
        snapshot.primary.resets_at = Some("2026-07-20T05:00:31Z".to_string());
        let second_cycle = tracked_reset_cycle(&mut manager, &snapshot.primary);

        assert_eq!(first_cycle, second_cycle);
    }

    #[test]
    fn a_real_next_reset_window_starts_a_new_cycle() {
        let mut manager = codexbar::notifications::NotificationManager::new();
        let mut snapshot = empty_snapshot();
        snapshot.primary.window_minutes = Some(300);
        snapshot.primary.resets_at = Some("2026-07-20T05:00:02.125Z".to_string());
        let first_cycle = tracked_reset_cycle(&mut manager, &snapshot.primary);
        snapshot.primary.resets_at = Some("2026-07-20T10:00:01.500Z".to_string());
        let second_cycle = tracked_reset_cycle(&mut manager, &snapshot.primary);

        assert_ne!(first_cycle, second_cycle);
    }

    #[test]
    fn reset_timestamp_jitter_does_not_cross_account_lanes() {
        let mut manager = codexbar::notifications::NotificationManager::new();
        let mut snapshot = empty_snapshot();
        snapshot.primary.window_minutes = Some(300);
        snapshot.primary.resets_at = Some("2026-07-20T05:00:29Z".to_string());
        let account_a = tracked_quota_reset_cycle(
            &mut manager,
            ProviderId::Claude,
            "account-a",
            "session",
            &snapshot.primary,
        );
        snapshot.primary.resets_at = Some("2026-07-20T05:00:31Z".to_string());
        let account_b = tracked_quota_reset_cycle(
            &mut manager,
            ProviderId::Claude,
            "account-b",
            "session",
            &snapshot.primary,
        );

        assert_ne!(account_a, account_b);
    }

    #[test]
    fn augment_month_day_description_identifies_a_reset_cycle() {
        let mut snapshot = empty_snapshot();
        snapshot.primary.reset_description = Some("ends 7/31".to_string());

        assert_eq!(
            quota_reset_cycle(&snapshot.primary),
            "description:ends 7/31"
        );
        assert!(is_stable_reset_description("ends 7/31"));
        assert!(!is_stable_reset_description("81/100 requests used"));
    }
}
