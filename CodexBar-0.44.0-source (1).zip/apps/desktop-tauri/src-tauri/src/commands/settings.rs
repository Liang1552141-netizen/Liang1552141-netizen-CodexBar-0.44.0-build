use super::*;

static SHORTCUT_CHANGE: std::sync::LazyLock<Mutex<()>> =
    std::sync::LazyLock::new(|| Mutex::new(()));
static START_AT_LOGIN_CHANGE: std::sync::LazyLock<Mutex<()>> =
    std::sync::LazyLock::new(|| Mutex::new(()));

// ── Settings mutation ─────────────────────────────────────────────────

/// Partial settings update — every field is optional so the frontend can
/// send only what changed.
#[derive(Debug, Clone, Default, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct SettingsUpdate {
    pub enabled_providers: Option<Vec<String>>,
    pub refresh_interval_secs: Option<u64>,
    pub refresh_all_providers_on_menu_open: Option<bool>,
    pub start_at_login: Option<bool>,
    pub start_minimized: Option<bool>,
    pub show_notifications: Option<bool>,
    pub sound_enabled: Option<bool>,
    pub sound_volume: Option<u8>,
    pub high_usage_threshold: Option<f64>,
    pub critical_usage_threshold: Option<f64>,
    pub provider_usage_thresholds:
        Option<std::collections::HashMap<String, codexbar::settings::UsageThresholdOverride>>,
    pub predictive_pace_warning_enabled: Option<bool>,
    pub tray_icon_mode: Option<String>,
    pub switcher_shows_icons: Option<bool>,
    pub menu_bar_shows_highest_usage: Option<bool>,
    pub menu_bar_shows_percent: Option<bool>,
    pub show_as_used: Option<bool>,
    pub show_all_token_accounts_in_menu: Option<bool>,
    pub enable_animations: Option<bool>,
    pub reset_time_relative: Option<bool>,
    pub show_reset_when_exhausted: Option<bool>,
    pub menu_bar_display_mode: Option<String>,
    pub hide_personal_info: Option<bool>,
    pub update_channel: Option<String>,
    pub auto_download_updates: Option<bool>,
    pub install_updates_on_quit: Option<bool>,
    pub global_shortcut: Option<String>,
    pub codex_custom_sessions_dirs: Option<Vec<String>>,
    pub agent_sessions_enabled: Option<bool>,
    pub agent_session_ssh_hosts: Option<Vec<String>>,
    pub ui_language: Option<String>,
    pub widget_theme: Option<codexbar::settings::WidgetTheme>,
    pub widget_pinned: Option<bool>,
    pub widget_smart_topmost: Option<bool>,
    pub widget_hide_fullscreen: Option<bool>,
    pub theme: Option<String>,
    pub window_scale_percent: Option<u16>,
    pub tray_scale_percent: Option<u16>,
    pub powertoys_status_pipe_enabled: Option<bool>,
    pub claude_avoid_keychain_prompts: Option<bool>,
    pub codex_spark_usage_visible: Option<bool>,
    pub disable_keychain_access: Option<bool>,
    /// Map of provider CLI name → metric preference label.
    pub provider_metrics: Option<std::collections::HashMap<String, String>>,
    pub float_bar_enabled: Option<bool>,
    pub float_bar_opacity: Option<u8>,
    pub float_bar_scale: Option<u8>,
    pub float_bar_orientation: Option<String>,
    pub float_bar_style: Option<String>,
    pub float_bar_click_through: Option<bool>,
    pub float_bar_provider_ids: Option<Vec<String>>,
    pub float_bar_dark_text: Option<bool>,
    pub float_bar_show_reset_inline: Option<bool>,
    pub float_bar_show_cost: Option<bool>,
    pub promote_tray_icon: Option<bool>,
}

impl SettingsUpdate {
    fn refreshes_provider_data(&self) -> bool {
        self.enabled_providers.is_some()
    }

    fn notifies_float_bar(&self) -> bool {
        self.enabled_providers.is_some()
            || self.refresh_interval_secs.is_some()
            || self.codex_custom_sessions_dirs.is_some()
            || self.high_usage_threshold.is_some()
            || self.critical_usage_threshold.is_some()
            || self.provider_usage_thresholds.is_some()
            || self.show_as_used.is_some()
            || self.reset_time_relative.is_some()
            || self.show_reset_when_exhausted.is_some()
            || self.widget_theme.is_some()
            || self.widget_pinned.is_some()
    }

    fn rebuilds_tray_menu(&self) -> bool {
        self.float_bar_enabled.is_some() || self.ui_language.is_some()
    }

    pub fn changes_tray_promotion(&self) -> bool {
        self.promote_tray_icon.is_some()
    }

    fn refreshes_tray_presentation(&self) -> bool {
        self.tray_icon_mode.is_some()
            || self.switcher_shows_icons.is_some()
            || self.menu_bar_shows_highest_usage.is_some()
            || self.menu_bar_shows_percent.is_some()
            || self.show_as_used.is_some()
            || self.reset_time_relative.is_some()
            || self.menu_bar_display_mode.is_some()
            || self.provider_metrics.is_some()
            || self.codex_spark_usage_visible.is_some()
            || self.enabled_providers.is_some()
            || self.ui_language.is_some()
    }

    fn validate_shortcut_change(
        &self,
        app: &tauri::AppHandle,
        current_shortcut: &str,
    ) -> Result<(), String> {
        let Some(new_shortcut) = &self.global_shortcut else {
            return Ok(());
        };

        if new_shortcut.trim().is_empty() {
            crate::shortcut_bridge::unregister_shortcut(app, current_shortcut)?;
        } else if new_shortcut != current_shortcut {
            crate::shortcut_bridge::reregister_shortcut(app, current_shortcut, new_shortcut)?;
        }

        Ok(())
    }

    fn apply_provider_settings(self, settings: &mut Settings) -> Self {
        if let Some(providers) = self.enabled_providers.clone() {
            settings.enabled_providers = providers.into_iter().collect::<HashSet<_>>();
        }
        if let Some(v) = self.refresh_interval_secs {
            settings.refresh_interval_secs = v;
        }
        if let Some(v) = self.refresh_all_providers_on_menu_open {
            settings.refresh_all_providers_on_menu_open = v;
        }
        if let Some(ref s) = self.tray_icon_mode
            && let Some(mode) = parse_tray_icon_mode(s)
        {
            settings.tray_icon_mode = mode;
        }
        if let Some(v) = self.provider_metrics.clone() {
            apply_provider_metrics(settings, v);
        }
        self
    }

    fn apply_general_settings(self, settings: &mut Settings) -> Result<Self, String> {
        if let Some(v) = self.start_at_login {
            // Registry I/O is applied by update_settings before entering the
            // settings load/modify/save critical section.
            settings.start_at_login = v;
        }
        if let Some(v) = self.start_minimized {
            settings.start_minimized = v;
        }
        if let Some(v) = self.global_shortcut.clone() {
            settings.global_shortcut = v;
        }
        if let Some(v) = self.ui_language.as_deref().and_then(parse_language)
            && settings.ui_language != v
        {
            settings.ui_language = v;
        }
        if let Some(v) = self.theme.as_deref().and_then(parse_theme) {
            settings.theme = v;
        }
        Ok(self)
    }

    fn apply_display_settings(self, settings: &mut Settings) -> Self {
        if let Some(v) = self.show_as_used {
            settings.show_as_used = v;
        }
        if let Some(v) = self.reset_time_relative {
            settings.reset_time_relative = v;
        }
        if let Some(v) = self.show_reset_when_exhausted {
            settings.show_reset_when_exhausted = v;
        }
        if let Some(v) = self.menu_bar_display_mode.clone() {
            settings.menu_bar_display_mode = v;
        }
        if let Some(v) = self.window_scale_percent {
            settings.window_scale_percent = codexbar::settings::clamp_window_scale_percent(v);
        }
        if let Some(v) = self.tray_scale_percent {
            settings.tray_scale_percent = codexbar::settings::clamp_tray_scale_percent(v);
        }
        if let Some(v) = self.switcher_shows_icons {
            settings.switcher_shows_icons = v;
        }
        if let Some(v) = self.menu_bar_shows_highest_usage {
            settings.menu_bar_shows_highest_usage = v;
        }
        if let Some(v) = self.menu_bar_shows_percent {
            settings.menu_bar_shows_percent = v;
        }
        if let Some(v) = self.widget_theme {
            settings.widget_theme = v;
        }
        if let Some(v) = self.widget_pinned {
            settings.widget_pinned = v;
        }
        if let Some(v) = self.widget_smart_topmost {
            settings.widget_smart_topmost = v;
        }
        if let Some(v) = self.widget_hide_fullscreen {
            settings.widget_hide_fullscreen = v;
        }
        if let Some(v) = self.show_all_token_accounts_in_menu {
            settings.show_all_token_accounts_in_menu = v;
        }
        if let Some(v) = self.promote_tray_icon {
            settings.promote_tray_icon = v;
        }
        self
    }

    fn apply_notification_settings(self, settings: &mut Settings) -> Self {
        let thresholds_changed = self.high_usage_threshold.is_some()
            || self.critical_usage_threshold.is_some()
            || self.provider_usage_thresholds.is_some();
        if let Some(v) = self.show_notifications {
            settings.show_notifications = v;
        }
        if let Some(v) = self.sound_enabled {
            settings.sound_enabled = v;
        }
        if let Some(v) = self.sound_volume {
            settings.sound_volume = v;
        }
        if let Some(v) = self.high_usage_threshold {
            settings.high_usage_threshold = v.clamp(0.0, 100.0);
        }
        if let Some(v) = self.critical_usage_threshold {
            settings.critical_usage_threshold = v.clamp(0.0, 100.0);
        }
        if let Some(values) = self.provider_usage_thresholds.clone() {
            settings.provider_usage_thresholds =
                codexbar::settings::normalize_usage_threshold_overrides(values);
        }
        if thresholds_changed {
            let (high, critical, overrides) =
                codexbar::settings::normalize_fixed_usage_thresholds(
                    settings.high_usage_threshold,
                    settings.critical_usage_threshold,
                    std::mem::take(&mut settings.provider_usage_thresholds),
                );
            settings.high_usage_threshold = high;
            settings.critical_usage_threshold = critical;
            settings.provider_usage_thresholds = overrides;
        }
        if let Some(v) = self.predictive_pace_warning_enabled {
            settings.predictive_pace_warning_enabled = v;
        }
        self
    }

    fn apply_advanced_settings(self, settings: &mut Settings) -> Self {
        if let Some(v) = self.enable_animations {
            settings.enable_animations = v;
        }
        if let Some(v) = self.hide_personal_info {
            settings.hide_personal_info = v;
        }
        if let Some(v) = self
            .update_channel
            .as_deref()
            .and_then(parse_update_channel)
        {
            settings.update_channel = v;
        }
        if let Some(v) = self.auto_download_updates {
            settings.auto_download_updates = v;
        }
        if let Some(v) = self.codex_custom_sessions_dirs.clone() {
            settings.codex_custom_sessions_dirs = normalize_custom_sessions_dirs(v);
        }
        if let Some(v) = self.agent_sessions_enabled {
            settings.agent_sessions_enabled = v;
        }
        if let Some(v) = self.agent_session_ssh_hosts.clone() {
            settings.agent_session_ssh_hosts =
                codexbar::agent_sessions::RemoteSessionFetcher::sanitized_hosts(&v);
        }
        if let Some(v) = self.install_updates_on_quit {
            settings.install_updates_on_quit = v;
        }
        if let Some(v) = self.powertoys_status_pipe_enabled {
            settings.powertoys_status_pipe_enabled = v;
        }
        if let Some(v) = self.claude_avoid_keychain_prompts {
            settings.set_claude_avoid_keychain_prompts(v);
        }
        if let Some(v) = self.codex_spark_usage_visible {
            settings.set_codex_spark_usage_visible(v);
        }
        if let Some(v) = self.disable_keychain_access {
            settings.disable_keychain_access = v;
            if v {
                settings.set_claude_avoid_keychain_prompts(true);
            }
        }
        self
    }

    fn float_bar_patch(&self) -> crate::floatbar::SettingsPatch {
        crate::floatbar::SettingsPatch {
            enabled: self.float_bar_enabled,
            opacity: self.float_bar_opacity,
            scale: self.float_bar_scale,
            orientation: self.float_bar_orientation.clone(),
            style: self.float_bar_style.clone(),
            click_through: self.float_bar_click_through,
            provider_ids: self.float_bar_provider_ids.clone(),
            dark_text: self.float_bar_dark_text,
            show_reset_inline: self.float_bar_show_reset_inline,
            show_cost: self.float_bar_show_cost,
            widget_theme: self.widget_theme,
            widget_pinned: self.widget_pinned,
        }
    }

    fn apply_to(self, settings: &mut Settings) -> Result<crate::floatbar::SettingsPatch, String> {
        let float_bar_patch = self.float_bar_patch();
        self.apply_provider_settings(settings)
            .apply_general_settings(settings)?
            .apply_display_settings(settings)
            .apply_notification_settings(settings)
            .apply_advanced_settings(settings);
        float_bar_patch.apply(settings);
        Ok(float_bar_patch)
    }
}

fn normalize_custom_sessions_dirs(dirs: Vec<String>) -> Vec<String> {
    let mut seen = HashSet::new();
    let mut out = Vec::new();

    for dir in dirs {
        let trimmed = dir.trim();
        if trimmed.is_empty() {
            continue;
        }
        let key = trimmed.replace('/', "\\").to_ascii_lowercase();
        if seen.insert(key) {
            out.push(trimmed.to_string());
        }
    }

    out
}

fn apply_provider_metrics(
    settings: &mut Settings,
    metrics_map: std::collections::HashMap<String, String>,
) {
    for (provider, label) in metrics_map {
        if let Some(pref) = parse_metric_preference(&label) {
            settings.provider_metrics.insert(provider, pref);
        }
    }
}

fn parse_tray_icon_mode(s: &str) -> Option<TrayIconMode> {
    match s {
        "single" => Some(TrayIconMode::Single),
        "perProvider" => Some(TrayIconMode::PerProvider),
        _ => None,
    }
}

fn parse_update_channel(s: &str) -> Option<UpdateChannel> {
    match s {
        "stable" => Some(UpdateChannel::Stable),
        "beta" => Some(UpdateChannel::Beta),
        _ => None,
    }
}

fn parse_language(s: &str) -> Option<Language> {
    Language::resolve(s)
}

#[tauri::command]
pub async fn update_settings(
    app: tauri::AppHandle,
    patch: SettingsUpdate,
) -> Result<SettingsSnapshot, String> {
    let notify_float_bar = patch.notifies_float_bar();
    let refresh_provider_data = patch.refreshes_provider_data();
    let clear_local_usage_cache = patch.codex_custom_sessions_dirs.is_some();
    let rebuild_tray_menu = patch.rebuilds_tray_menu();
    let refresh_tray_presentation = patch.refreshes_tray_presentation();
    let tray_promotion_changed = patch.changes_tray_promotion();
    let widget_pinned = patch.widget_pinned;

    // OS/plugin side effects must not run while the settings transaction lock
    // is held. Shortcut and start-at-login changes use narrow ordering locks
    // so concurrent patches cannot reorder side effects vs persistence.
    let shortcut_change = patch.global_shortcut.is_some();
    let shortcut_guard = if shortcut_change {
        Some(
            SHORTCUT_CHANGE
                .lock()
                .map_err(|_| "shortcut mutation lock is poisoned".to_string())?,
        )
    } else {
        None
    };
    let start_at_login_guard = if patch.start_at_login.is_some() {
        Some(
            START_AT_LOGIN_CHANGE
                .lock()
                .map_err(|_| "start-at-login mutation lock is poisoned".to_string())?,
        )
    } else {
        None
    };
    if shortcut_change {
        let current_shortcut =
            crate::settings_mutation::read(|settings| settings.global_shortcut.clone())?;
        patch.validate_shortcut_change(&app, &current_shortcut)?;
    }
    if let Some(enabled) = patch.start_at_login {
        Settings::apply_start_at_login_registry(enabled).map_err(|error| error.to_string())?;
    }

    let (settings, (float_bar_patch, previous_promoted, previous_language)) =
        crate::settings_mutation::mutate_with_save(
            |settings| {
                let previous_promoted = settings.promote_tray_icon;
                let previous_language = settings.ui_language;

                let float_bar_patch = patch.apply_to(settings)?;
                Ok((float_bar_patch, previous_promoted, previous_language))
            },
            |settings| {
                crate::floatbar::save_settings_with_widget_state(
                    &app,
                    settings,
                    widget_pinned,
                )
            },
        )?;
    drop(start_at_login_guard);
    drop(shortcut_guard);

    if settings.ui_language != previous_language {
        let _ = app.emit(events::LOCALE_CHANGED, language_label(settings.ui_language));
    }
    if clear_local_usage_cache {
        crate::commands::clear_provider_local_usage_cache();
    }

    if refresh_provider_data {
        // Invalidate any in-flight publish work and drop disabled providers from
        // the live cache before a follow-up refresh starts.
        let enabled_ids = settings.get_enabled_provider_ids();
        let state = app.state::<Mutex<AppState>>();
        let _ =
            crate::commands::invalidate_provider_refresh_and_prune_disabled(&state, &enabled_ids);
    }

    crate::floatbar::after_settings_saved(&app, &float_bar_patch, &settings, notify_float_bar);
    if rebuild_tray_menu {
        crate::tray_bridge::rebuild_tray_menu(&app);
    }
    if refresh_tray_presentation {
        crate::tray_bridge::refresh_tray_presentation(&app);
    }
    if tray_promotion_changed {
        let new_promoted = settings.promote_tray_icon;
        if new_promoted
            || crate::tray_visibility::should_write_demotion(previous_promoted, new_promoted)
        {
            crate::tray_visibility::apply_promotion(new_promoted);
        }
    }

    // Notify other windows (PopOut dashboard, tray, float bar) so they re-read
    // settings live — e.g. the Display tab's window-scale slider takes effect
    // immediately instead of only after the PopOut is reopened.
    events::emit_settings_changed(&app);
    if refresh_provider_data {
        let app = app.clone();
        tauri::async_runtime::spawn(async move {
            let _ = crate::commands::do_refresh_providers(&app).await;
        });
    }

    Ok(SettingsSnapshot::from(settings))
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Arc, Barrier, Mutex as StdMutex, mpsc};
    use std::time::Duration;

    #[test]
    fn start_at_login_side_effect_and_persistence_are_ordered_together() {
        let events = Arc::new(StdMutex::new(Vec::new()));
        let first_started = Arc::new(Barrier::new(2));
        let release_first = Arc::new(Barrier::new(2));
        let (second_entered_tx, second_entered_rx) = mpsc::channel();

        let first_events = Arc::clone(&events);
        let first_started_worker = Arc::clone(&first_started);
        let release_first_worker = Arc::clone(&release_first);
        let first = std::thread::spawn(move || {
            let _guard = START_AT_LOGIN_CHANGE.lock().unwrap();
            first_events.lock().unwrap().push("registry:true");
            first_started_worker.wait();
            release_first_worker.wait();
            first_events.lock().unwrap().push("settings:true");
        });

        first_started.wait();
        let second_events = Arc::clone(&events);
        let second = std::thread::spawn(move || {
            let _guard = START_AT_LOGIN_CHANGE.lock().unwrap();
            second_entered_tx.send(()).unwrap();
            second_events.lock().unwrap().push("registry:false");
            second_events.lock().unwrap().push("settings:false");
        });

        assert!(
            second_entered_rx
                .recv_timeout(Duration::from_millis(50))
                .is_err()
        );
        release_first.wait();
        first.join().unwrap();
        second_entered_rx
            .recv_timeout(Duration::from_secs(1))
            .unwrap();
        second.join().unwrap();

        assert_eq!(
            *events.lock().unwrap(),
            vec![
                "registry:true",
                "settings:true",
                "registry:false",
                "settings:false",
            ]
        );
    }

    #[test]
    fn only_data_affecting_settings_refresh_providers() {
        assert!(
            SettingsUpdate {
                enabled_providers: Some(vec!["codex".to_string()]),
                ..Default::default()
            }
            .refreshes_provider_data()
        );
        assert!(
            !SettingsUpdate {
                provider_metrics: Some(Default::default()),
                tray_icon_mode: Some("single".to_string()),
                ..Default::default()
            }
            .refreshes_provider_data()
        );
    }

    #[test]
    fn display_settings_that_affect_tray_trigger_presentation_refresh() {
        assert!(
            SettingsUpdate {
                switcher_shows_icons: Some(false),
                ..Default::default()
            }
            .refreshes_tray_presentation()
        );
        assert!(
            SettingsUpdate {
                reset_time_relative: Some(false),
                ..Default::default()
            }
            .refreshes_tray_presentation()
        );
    }

    #[test]
    fn ui_language_change_refreshes_tray_presentation() {
        assert!(
            SettingsUpdate {
                ui_language: Some("japanese".to_string()),
                ..Default::default()
            }
            .refreshes_tray_presentation()
        );
    }

    #[test]
    fn apply_display_settings_clamps_window_scale_percent() {
        let mut settings = Settings::default();

        SettingsUpdate {
            window_scale_percent: Some(300),
            ..Default::default()
        }
        .apply_display_settings(&mut settings);
        assert_eq!(settings.window_scale_percent, 250);

        SettingsUpdate {
            window_scale_percent: Some(50),
            ..Default::default()
        }
        .apply_display_settings(&mut settings);
        assert_eq!(settings.window_scale_percent, 100);
    }

    #[test]
    fn apply_display_settings_clamps_tray_scale_percent() {
        let mut settings = Settings::default();

        SettingsUpdate {
            tray_scale_percent: Some(300),
            ..Default::default()
        }
        .apply_display_settings(&mut settings);
        assert_eq!(settings.tray_scale_percent, 200);

        SettingsUpdate {
            tray_scale_percent: Some(50),
            ..Default::default()
        }
        .apply_display_settings(&mut settings);
        assert_eq!(settings.tray_scale_percent, 100);
    }

    #[test]
    fn notification_updates_preserve_the_fixed_two_state_invariant() {
        let mut settings = Settings::default();
        settings.high_usage_threshold = 100.0;
        settings.critical_usage_threshold = 100.0;

        SettingsUpdate {
            provider_usage_thresholds: Some(std::collections::HashMap::from([(
                "codex:session".to_string(),
                codexbar::settings::UsageThresholdOverride {
                    high: Some(75.0),
                    critical: Some(100.0),
                },
            )])),
            ..Default::default()
        }
        .apply_notification_settings(&mut settings);

        assert_eq!(settings.high_usage_threshold, 80.0);
        assert_eq!(settings.critical_usage_threshold, 100.0);
        assert!(settings.provider_usage_thresholds.is_empty());
    }

    #[test]
    fn widget_settings_update_applies_all_widget_fields() {
        let mut settings = Settings::default();
        let patch: SettingsUpdate = serde_json::from_value(serde_json::json!({
            "widgetTheme": "deepBlue",
            "widgetPinned": true,
            "widgetSmartTopmost": false,
            "widgetHideFullscreen": false
        }))
        .unwrap();

        patch.apply_display_settings(&mut settings);

        assert_eq!(
            settings.widget_theme,
            codexbar::settings::WidgetTheme::DeepBlue
        );
        assert!(settings.widget_pinned);
        assert!(!settings.widget_smart_topmost);
        assert!(!settings.widget_hide_fullscreen);
    }

    #[test]
    fn widget_theme_and_pin_updates_notify_the_float_bar() {
        for json in [
            serde_json::json!({ "widgetTheme": "system" }),
            serde_json::json!({ "widgetPinned": true }),
        ] {
            let patch: SettingsUpdate = serde_json::from_value(json).unwrap();
            assert!(patch.notifies_float_bar());
        }
    }

    #[test]
    fn widget_theme_and_pin_updates_are_carried_by_the_float_bar_patch() {
        let update: SettingsUpdate = serde_json::from_value(serde_json::json!({
            "widgetTheme": "deepBlue",
            "widgetPinned": true
        }))
        .unwrap();

        let patch = update.float_bar_patch();

        assert_eq!(
            patch.widget_theme,
            Some(codexbar::settings::WidgetTheme::DeepBlue)
        );
        assert_eq!(patch.widget_pinned, Some(true));
    }
}
