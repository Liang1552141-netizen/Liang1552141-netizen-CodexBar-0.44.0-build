import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const tauriMocks = vi.hoisted(() => ({
  getLocaleStrings: vi.fn(),
  setUiLanguage: vi.fn(),
}));

const eventMocks = vi.hoisted(() => ({
  listen: vi.fn(),
}));

vi.mock("../lib/tauri", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../lib/tauri")>()),
  ...tauriMocks,
}));
vi.mock("@tauri-apps/api/event", () => eventMocks);

import { LocaleProvider } from "../i18n/LocaleProvider";
import { buildBundle } from "../test/localeHarness";
import type { CodexWidgetModel } from "./model";
import { MiniUsageCard } from "./MiniUsageCard";

let dateNowSpy: ReturnType<typeof vi.spyOn>;

const model82: CodexWidgetModel = {
  status: "fresh",
  tone: "ok",
  planName: "Plus",
  updatedAt: "2026-07-19T11:00:00Z",
  session: {
    usedPercent: 22,
    remainingPercent: 78,
    resetsAt: null,
    resetDescription: "4小时",
  },
  weekly: {
    usedPercent: 18,
    remainingPercent: 82,
    resetsAt: null,
    resetDescription: "6天1小时",
  },
  pace: null,
  error: null,
};

function renderCard(model: CodexWidgetModel, onExpand = vi.fn()) {
  return {
    onExpand,
    ...render(
      <LocaleProvider>
        <MiniUsageCard model={model} onExpand={onExpand} />
      </LocaleProvider>,
    ),
  };
}

describe("MiniUsageCard", () => {
  beforeEach(() => {
    dateNowSpy = vi
      .spyOn(Date, "now")
      .mockReturnValue(new Date("2026-07-19T12:00:00Z").getTime());
    vi.clearAllMocks();
    eventMocks.listen.mockResolvedValue(() => {});
    tauriMocks.getLocaleStrings.mockResolvedValue(
      buildBundle({
        ProviderWeekly: "本周",
        TrayPopOutDashboard: "展开详细用量",
        WidgetQuotaUnavailable: "账户暂未提供此额度",
        WidgetRefreshFailed: "数据更新失败，正在显示上次结果",
        WidgetRemaining: "剩余",
        WidgetSyncedJustNow: "刚刚同步",
        ResetsInHoursMinutes: "{}小时{}分钟后重置",
        ResetsInMinutes: "{}分钟后重置",
        ResetsInDaysHours: "{}天{}小时后重置",
        TrayResetsDueNow: "正在重置",
      }),
    );
  });

  afterEach(() => {
    dateNowSpy.mockRestore();
  });

  it("shows weekly remaining usage without an automatic Tauri drag region", async () => {
    const { onExpand } = renderCard(model82);

    expect(await screen.findByText("82%")).toBeVisible();
    expect(screen.getByText("6天1小时")).toBeVisible();

    const card = screen.getByTestId("widget-drag-region");
    const expand = screen.getByRole("button", { name: "展开详细用量" });
    expect(card).not.toHaveAttribute("data-tauri-drag-region");
    expect(expand).not.toHaveAttribute("data-tauri-drag-region");
    expect(card.querySelector("[data-tauri-drag-region]")).toBeNull();

    fireEvent.click(expand);
    expect(onExpand).toHaveBeenCalledTimes(1);
  });

  it("uses the offline tone and localized empty copy when no quota exists", async () => {
    renderCard({
      ...model82,
      status: "empty",
      tone: "offline",
      session: null,
      weekly: null,
      updatedAt: null,
      planName: null,
    });

    expect(await screen.findByText("--")).toBeVisible();
    expect(screen.getByText("账户暂未提供此额度")).toBeVisible();
    expect(screen.getByTestId("widget-drag-region")).toHaveClass(
      "usage-widget--offline",
    );
  });

  it("renders a real reset timestamp through the active locale", async () => {
    renderCard({
      ...model82,
      weekly: {
        ...model82.weekly!,
        resetsAt: "2026-07-19T16:30:00Z",
        resetDescription: "4h 30m",
      },
    });

    expect(await screen.findByText("4小时30分钟后重置")).toBeVisible();
    expect(screen.queryByText("4h 30m")).not.toBeInTheDocument();
  });
});
