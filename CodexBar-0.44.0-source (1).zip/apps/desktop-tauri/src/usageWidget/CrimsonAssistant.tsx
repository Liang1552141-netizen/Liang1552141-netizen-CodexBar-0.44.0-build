import { useEffect, useState } from "react";
import assistantCenter from "../assets/crimson-assistant.webp";
import assistantBlink from "../assets/crimson-assistant-blink.webp";
import assistantLeft from "../assets/crimson-assistant-left.webp";
import assistantRight from "../assets/crimson-assistant-right.webp";
import "./CrimsonAssistant.css";

type Gaze = "center" | "left" | "right";

export function CrimsonAssistant({ paused }: { paused: boolean }) {
  const [gaze, setGaze] = useState<Gaze>("center");
  const [pageVisible, setPageVisible] = useState(
    () => document.visibilityState !== "hidden",
  );
  const [reducedMotion, setReducedMotion] = useState(
    () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false,
  );
  const motionPaused = paused || !pageVisible || reducedMotion;

  useEffect(() => {
    const media = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!media) return;
    const update = () => setReducedMotion(media.matches);
    media.addEventListener?.("change", update);
    return () => media.removeEventListener?.("change", update);
  }, []);

  useEffect(() => {
    const update = () => setPageVisible(document.visibilityState !== "hidden");
    document.addEventListener("visibilitychange", update);
    return () => document.removeEventListener("visibilitychange", update);
  }, []);

  useEffect(() => {
    if (motionPaused) {
      setGaze("center");
      return;
    }

    const moveGaze = (event: PointerEvent) => {
      const position = event.clientX / Math.max(window.innerWidth, 1);
      const next: Gaze =
        position < 0.36 ? "left" : position > 0.64 ? "right" : "center";
      setGaze((current) => (current === next ? current : next));
    };
    window.addEventListener("pointermove", moveGaze, { passive: true });
    return () => window.removeEventListener("pointermove", moveGaze);
  }, [motionPaused]);

  return (
    <figure
      className="crimson-assistant"
      aria-hidden="true"
      data-testid="crimson-assistant"
      data-gaze={gaze}
      data-motion={motionPaused ? "paused" : "playing"}
    >
      <img
        className="crimson-assistant__frame crimson-assistant__frame--center"
        src={assistantCenter}
        alt=""
        draggable={false}
      />
      <img
        className="crimson-assistant__frame crimson-assistant__frame--left"
        src={assistantLeft}
        alt=""
        draggable={false}
      />
      <img
        className="crimson-assistant__frame crimson-assistant__frame--right"
        src={assistantRight}
        alt=""
        draggable={false}
      />
      <img
        className="crimson-assistant__frame crimson-assistant__frame--blink"
        src={assistantBlink}
        alt=""
        draggable={false}
      />
    </figure>
  );
}
