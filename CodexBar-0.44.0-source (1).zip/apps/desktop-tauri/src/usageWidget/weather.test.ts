import { describe, expect, it, vi } from "vitest";
import { fetchWeather, weatherLabel } from "./weather";

function response(body: unknown): Response {
  return {
    ok: true,
    json: vi.fn().mockResolvedValue(body),
  } as unknown as Response;
}

describe("fetchWeather", () => {
  it("uses coarse IP coordinates and returns the current conditions", async () => {
    const fetcher = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(
        response({ latitude: 34.05, longitude: -118.24, city: "Los Angeles" }),
      )
      .mockResolvedValueOnce(
        response({
          current: { temperature_2m: 27.4, weather_code: 2 },
        }),
      );

    await expect(fetchWeather(new AbortController().signal, fetcher)).resolves.toEqual({
      temperatureC: 27,
      condition: "多云",
      city: "Los Angeles",
    });
    expect(fetcher).toHaveBeenCalledTimes(2);
  });

  it("rejects malformed location data instead of issuing a forecast request", async () => {
    const fetcher = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(response({ city: "Unknown" }));

    await expect(
      fetchWeather(new AbortController().signal, fetcher),
    ).rejects.toThrow("weather location unavailable");
    expect(fetcher).toHaveBeenCalledTimes(1);
  });

  it("localizes known and unknown WMO weather codes", () => {
    expect(weatherLabel(0)).toBe("晴");
    expect(weatherLabel(61)).toBe("小雨");
    expect(weatherLabel(95)).toBe("雷雨");
    expect(weatherLabel(999)).toBe("天气未知");
  });
});
