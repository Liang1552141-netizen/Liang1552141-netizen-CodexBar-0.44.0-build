import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { CrimsonAssistant } from "./CrimsonAssistant";

describe("CrimsonAssistant", () => {
  beforeEach(() => {
    Object.defineProperty(window, "innerWidth", {
      configurable: true,
      value: 1000,
    });
    Object.defineProperty(window, "matchMedia", {
      configurable: true,
      value: vi.fn().mockReturnValue({
        matches: false,
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
      }),
    });
  });

  it("renders real character frames as a decorative, non-interactive layer", () => {
    render(<CrimsonAssistant paused={false} />);

    const assistant = screen.getByTestId("crimson-assistant");
    expect(assistant).toHaveAttribute("aria-hidden", "true");
    expect(assistant).toHaveAttribute("data-motion", "playing");
    expect(assistant.querySelectorAll("img")).toHaveLength(4);
  });

  it("moves the character gaze across three pointer zones", () => {
    render(<CrimsonAssistant paused={false} />);
    const assistant = screen.getByTestId("crimson-assistant");

    fireEvent(window, new MouseEvent("pointermove", { clientX: 120 }));
    expect(assistant).toHaveAttribute("data-gaze", "left");

    fireEvent(window, new MouseEvent("pointermove", { clientX: 880 }));
    expect(assistant).toHaveAttribute("data-gaze", "right");

    fireEvent(window, new MouseEvent("pointermove", { clientX: 500 }));
    expect(assistant).toHaveAttribute("data-gaze", "center");
  });

  it("stops pointer-driven motion while native dragging is active", () => {
    render(<CrimsonAssistant paused />);
    const assistant = screen.getByTestId("crimson-assistant");

    fireEvent(window, new MouseEvent("pointermove", { clientX: 120 }));

    expect(assistant).toHaveAttribute("data-motion", "paused");
    expect(assistant).toHaveAttribute("data-gaze", "center");
  });

  it("honors reduced-motion preference", () => {
    vi.mocked(window.matchMedia).mockReturnValue({
      matches: true,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
    } as unknown as MediaQueryList);

    render(<CrimsonAssistant paused={false} />);

    expect(screen.getByTestId("crimson-assistant")).toHaveAttribute(
      "data-motion",
      "paused",
    );
  });
});
