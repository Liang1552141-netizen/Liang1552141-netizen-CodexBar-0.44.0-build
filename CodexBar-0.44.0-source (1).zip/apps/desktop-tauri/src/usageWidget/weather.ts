export type WeatherSnapshot = Readonly<{
  temperatureC: number;
  condition: string;
  city: string | null;
}>;

type Fetcher = typeof fetch;

export function weatherLabel(code: number): string {
  if (code === 0) return "晴";
  if (code === 1) return "大致晴朗";
  if (code === 2) return "多云";
  if (code === 3) return "阴";
  if (code === 45 || code === 48) return "有雾";
  if (code >= 51 && code <= 57) return "毛毛雨";
  if (code >= 61 && code <= 65) return code === 61 ? "小雨" : "有雨";
  if (code >= 66 && code <= 67) return "冻雨";
  if (code >= 71 && code <= 77) return "有雪";
  if (code >= 80 && code <= 82) return "阵雨";
  if (code >= 85 && code <= 86) return "阵雪";
  if (code >= 95 && code <= 99) return "雷雨";
  return "天气未知";
}

function finiteNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

export async function fetchWeather(
  signal: AbortSignal,
  fetcher: Fetcher = fetch,
): Promise<WeatherSnapshot> {
  const locationResponse = await fetcher("https://ipapi.co/json/", { signal });
  if (!locationResponse.ok) throw new Error("weather location unavailable");
  const location = await locationResponse.json() as Record<string, unknown>;
  const latitude = finiteNumber(location.latitude);
  const longitude = finiteNumber(location.longitude);
  if (latitude == null || longitude == null) {
    throw new Error("weather location unavailable");
  }

  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(latitude));
  url.searchParams.set("longitude", String(longitude));
  url.searchParams.set("current", "temperature_2m,weather_code");
  url.searchParams.set("temperature_unit", "celsius");
  const forecastResponse = await fetcher(url.toString(), { signal });
  if (!forecastResponse.ok) throw new Error("weather forecast unavailable");
  const forecast = await forecastResponse.json() as {
    current?: Record<string, unknown>;
  };
  const temperature = finiteNumber(forecast.current?.temperature_2m);
  const code = finiteNumber(forecast.current?.weather_code);
  if (temperature == null || code == null) {
    throw new Error("weather forecast unavailable");
  }

  return {
    temperatureC: Math.round(temperature),
    condition: weatherLabel(code),
    city: typeof location.city === "string" && location.city.trim()
      ? location.city.trim()
      : null,
  };
}
