import { describe, expect, it } from "vitest";
import type { ProviderUsageSnapshot, RateWindowSnapshot } from "../types/bridge";
import { buildCodexWidgetModel } from "./model";

const NOW = new Date("2026-07-19T12:00:00Z");

function window(usedPercent: number, remainingPercent: number): RateWindowSnapshot {
  return {
    usedPercent,
    remainingPercent,
    windowMinutes: null,
    resetsAt: "2026-07-20T00:00:00Z",
    resetDescription: "tomorrow",
    isExhausted: false,
    reservePercent: null,
    reserveDescription: null,
  };
}

function codexSnapshot(
  overrides: Partial<ProviderUsageSnapshot> & {
    primary?: RateWindowSnapshot;
    secondary?: RateWindowSnapshot | null;
  } = {},
): ProviderUsageSnapshot {
  return {
    providerId: "codex",
    displayName: "Codex",
    primary: window(22, 78),
    primaryWindowKind: "session",
    secondary: window(18, 82),
    modelSpecific: null,
    tertiary: null,
    extraRateWindows: [],
    cost: null,
    planName: "Plus",
    accountId: null,
    accountEmail: null,
    sourceLabel: "test",
    updatedAt: "2026-07-19T11:00:00Z",
    error: null,
    pace: null,
    accountOrganization: null,
    trayStatusLabel: null,
    ...overrides,
  };
}

describe("buildCodexWidgetModel", () => {
  it("maps Codex session and weekly usage without changing source values", () => {
    const model = buildCodexWidgetModel([codexSnapshot()], NOW);

    expect(model.session).toMatchObject({ usedPercent: 22, remainingPercent: 78 });
    expect(model.weekly).toMatchObject({ usedPercent: 18, remainingPercent: 82 });
    expect(model.status).toBe("fresh");
  });

  it("keeps the last successful snapshot visible when refresh fails", () => {
    const model = buildCodexWidgetModel([codexSnapshot({ error: "timeout" })], NOW);

    expect(model.weekly).toMatchObject({ usedPercent: 18, remainingPercent: 82 });
    expect(model.status).toBe("stale");
    expect(model.error).toBe("timeout");
  });

  it("does not render a synthetic quota when an initial refresh fails", () => {
    const model = buildCodexWidgetModel([
      codexSnapshot({
        error: "timeout",
        primary: { ...window(0, 100), isInformational: true },
        secondary: null,
      }),
    ], NOW);

    expect(model.status).toBe("stale");
    expect(model.session).toBeNull();
    expect(model.weekly).toBeNull();
    expect(model.tone).toBe("offline");
  });

  it("maps a weekly-only primary window to weekly without inventing a session", () => {
    const model = buildCodexWidgetModel([
      codexSnapshot({
        primary: window(40, 60),
        primaryWindowKind: "weekly",
        secondary: null,
      }),
    ], NOW);

    expect(model.session).toBeNull();
    expect(model.weekly).toMatchObject({ usedPercent: 40, remainingPercent: 60 });
  });

  it("keeps session usage when the weekly window is missing", () => {
    const model = buildCodexWidgetModel([codexSnapshot({ secondary: null })], NOW);

    expect(model.session).toMatchObject({ usedPercent: 22, remainingPercent: 78 });
    expect(model.weekly).toBeNull();
  });

  it("uses weekly remaining for tone before session remaining", () => {
    const model = buildCodexWidgetModel([
      codexSnapshot({ primary: window(95, 5), secondary: window(75, 25) }),
    ], NOW);

    expect(model.tone).toBe("ok");
  });

  it.each([
    [30, "ok"],
    [20, "warning"],
    [10, "critical"],
  ] as const)("sets %s%% remaining to %s tone", (remaining, tone) => {
    const model = buildCodexWidgetModel([
      codexSnapshot({ secondary: window(100 - remaining, remaining) }),
    ], NOW);

    expect(model.tone).toBe(tone);
  });

  it("uses session remaining for tone when the weekly window is missing", () => {
    const model = buildCodexWidgetModel([
      codexSnapshot({ primary: window(85, 15), secondary: null }),
    ], NOW);

    expect(model.tone).toBe("warning");
  });

  it("returns an offline empty model when Codex is absent", () => {
    const model = buildCodexWidgetModel([] as ProviderUsageSnapshot[], NOW);

    expect(model).toMatchObject({
      status: "empty",
      tone: "offline",
      session: null,
      weekly: null,
      pace: null,
      error: null,
    });
  });

  it("returns an offline signed-out model when Codex authentication is invalid", () => {
    const model = buildCodexWidgetModel([
      codexSnapshot({
        error: "Authentication required",
      }),
    ], NOW);

    expect(model).toMatchObject({
      status: "signedOut",
      tone: "offline",
      session: null,
      weekly: null,
    });
  });

  it.each([
    "Parse error: Invalid Codex credentials JSON: expected value at line 1 column 1",
    "Parse error: Codex auth.json exists but contains no tokens.",
  ])("treats deterministic Codex credential failure as signed out: %s", (error) => {
    const model = buildCodexWidgetModel([
      codexSnapshot({
        error,
      }),
    ], NOW);

    expect(model).toMatchObject({
      status: "signedOut",
      tone: "offline",
      planName: null,
      session: null,
      weekly: null,
      pace: null,
      error,
    });
  });
});
