import { useEffect, useState } from "react";
import { fetchWeather, type WeatherSnapshot } from "./weather";

export const WEATHER_CACHE_KEY = "codexbar.weather.v1";
const WEATHER_CACHE_MS = 30 * 60 * 1000;
const WEATHER_TIMEOUT_MS = 5_000;

type WeatherCache = WeatherSnapshot & { fetchedAt: number };
export type WeatherState = Readonly<{
  status: "idle" | "loading" | "ready" | "unavailable";
  snapshot: WeatherSnapshot | null;
}>;

function readCache(now: number): WeatherSnapshot | null {
  try {
    const parsed = JSON.parse(
      localStorage.getItem(WEATHER_CACHE_KEY) ?? "null",
    ) as Partial<WeatherCache> | null;
    if (
      !parsed ||
      typeof parsed.fetchedAt !== "number" ||
      now - parsed.fetchedAt >= WEATHER_CACHE_MS ||
      typeof parsed.temperatureC !== "number" ||
      typeof parsed.condition !== "string"
    ) {
      return null;
    }
    return {
      temperatureC: parsed.temperatureC,
      condition: parsed.condition,
      city: typeof parsed.city === "string" ? parsed.city : null,
    };
  } catch {
    return null;
  }
}

export function useWeather({
  enabled,
  paused = false,
  fetcher = fetch,
}: {
  enabled: boolean;
  paused?: boolean;
  fetcher?: typeof fetch;
}): WeatherState {
  const [state, setState] = useState<WeatherState>({
    status: enabled ? "loading" : "idle",
    snapshot: null,
  });

  useEffect(() => {
    if (!enabled) {
      setState({ status: "idle", snapshot: null });
      return;
    }
    if (paused) return;
    const cached = readCache(Date.now());
    if (cached) {
      setState({ status: "ready", snapshot: cached });
      return;
    }

    let active = true;
    const controller = new AbortController();
    const timeout = window.setTimeout(
      () => controller.abort(),
      WEATHER_TIMEOUT_MS,
    );
    setState({ status: "loading", snapshot: null });
    void fetchWeather(controller.signal, fetcher)
      .then((snapshot) => {
        if (!active) return;
        localStorage.setItem(
          WEATHER_CACHE_KEY,
          JSON.stringify({ ...snapshot, fetchedAt: Date.now() }),
        );
        setState({ status: "ready", snapshot });
      })
      .catch(() => {
        if (active) setState({ status: "unavailable", snapshot: null });
      })
      .finally(() => window.clearTimeout(timeout));

    return () => {
      active = false;
      window.clearTimeout(timeout);
      controller.abort();
    };
  }, [enabled, fetcher, paused]);

  return state;
}
