import type { CodexWidgetModel, QuotaView } from "./model";

export type DashboardView = Readonly<{
  primaryQuota: QuotaView | null;
  primaryLabel: "本周额度" | "本次额度" | "额度";
  remainingPercent: number | null;
  usedPercent: number | null;
  modelName: "Codex";
  planName: string;
  connected: boolean;
  estimatedHours: number | null;
}>;

export function buildDashboardView(model: CodexWidgetModel): DashboardView {
  const primaryQuota = model.weekly ?? model.session;

  return {
    primaryQuota,
    primaryLabel: model.weekly
      ? "本周额度"
      : model.session
        ? "本次额度"
        : "额度",
    remainingPercent: primaryQuota?.remainingPercent ?? null,
    usedPercent: primaryQuota?.usedPercent ?? null,
    modelName: "Codex",
    planName: model.planName ?? "暂不可用",
    connected: model.status === "fresh",
    estimatedHours:
      model.pace?.etaSeconds == null
        ? null
        : Math.max(0, Math.round(model.pace.etaSeconds / 3600)),
  };
}
