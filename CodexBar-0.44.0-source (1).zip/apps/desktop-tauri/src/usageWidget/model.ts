import type { ProviderUsageSnapshot, RateWindowSnapshot } from "../types/bridge";

export type WidgetTone = "ok" | "warning" | "critical" | "offline";

export type QuotaView = Readonly<{
  usedPercent: number;
  remainingPercent: number;
  resetsAt: string | null;
  resetDescription: string | null;
}>;

export type CodexWidgetModel = Readonly<{
  status: "fresh" | "stale" | "signedOut" | "empty";
  tone: WidgetTone;
  planName: string | null;
  updatedAt: string | null;
  session: QuotaView | null;
  weekly: QuotaView | null;
  pace: ProviderUsageSnapshot["pace"];
  error: string | null;
}>;

function quotaView(window: RateWindowSnapshot): QuotaView {
  return {
    usedPercent: window.usedPercent,
    remainingPercent: window.remainingPercent,
    resetsAt: window.resetsAt,
    resetDescription: window.resetDescription,
  };
}

function toneForRemaining(remainingPercent: number): WidgetTone {
  if (remainingPercent <= 10) return "critical";
  if (remainingPercent <= 20) return "warning";
  return "ok";
}

export function isAuthenticationError(error: string | null): boolean {
  if (!error) return false;
  const normalized = error.toLowerCase();
  return [
    "auth.json not found",
    "authentication required",
    "auth required",
    "login required",
    "sign in required",
    "sign-in required",
    "not logged in",
    "unauthorized",
    "forbidden",
    "token expired",
    "token invalid",
    "invalid codex credentials json",
    "contains no tokens",
    "missing access_token",
  ].some((marker) => normalized.includes(marker));
}

export function buildCodexWidgetModel(
  providers: readonly ProviderUsageSnapshot[],
  _now: Date,
): CodexWidgetModel {
  const codex = providers.find((provider) => provider.providerId === "codex");

  if (!codex) {
    return {
      status: "empty",
      tone: "offline",
      planName: null,
      updatedAt: null,
      session: null,
      weekly: null,
      pace: null,
      error: null,
    };
  }

  if (isAuthenticationError(codex.error)) {
    return {
      status: "signedOut",
      tone: "offline",
      planName: null,
      updatedAt: codex.updatedAt,
      session: null,
      weekly: null,
      pace: null,
      error: codex.error,
    };
  }

  const primary = codex.primary.isInformational ? null : quotaView(codex.primary);
  const session = codex.primaryWindowKind === "session" ? primary : null;
  const weekly = codex.primaryWindowKind === "weekly"
    ? primary
    : codex.secondary && !codex.secondary.isInformational
      ? quotaView(codex.secondary)
      : null;
  const toneSource = weekly ?? session;

  return {
    status: codex.error ? "stale" : "fresh",
    tone: toneSource ? toneForRemaining(toneSource.remainingPercent) : "offline",
    planName: codex.planName,
    updatedAt: codex.updatedAt,
    session,
    weekly,
    pace: codex.pace,
    error: codex.error,
  };
}
