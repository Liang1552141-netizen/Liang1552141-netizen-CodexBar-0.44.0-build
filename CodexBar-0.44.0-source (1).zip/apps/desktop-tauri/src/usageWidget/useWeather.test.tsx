import { act, renderHook, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { WEATHER_CACHE_KEY, useWeather } from "./useWeather";

describe("useWeather", () => {
  beforeEach(() => {
    localStorage.clear();
    vi.restoreAllMocks();
  });

  it("uses a fresh thirty-minute cache without making a request", async () => {
    localStorage.setItem(
      WEATHER_CACHE_KEY,
      JSON.stringify({
        fetchedAt: Date.now() - 60_000,
        temperatureC: 22,
        condition: "晴",
        city: "Test",
      }),
    );
    const fetcher = vi.fn<typeof fetch>();

    const { result } = renderHook(() => useWeather({ enabled: true, fetcher }));

    await waitFor(() => expect(result.current.status).toBe("ready"));
    expect(result.current.snapshot?.temperatureC).toBe(22);
    expect(fetcher).not.toHaveBeenCalled();
  });

  it("falls back without blocking when weather requests fail", async () => {
    const fetcher = vi.fn<typeof fetch>().mockRejectedValue(new Error("offline"));

    const { result } = renderHook(() => useWeather({ enabled: true, fetcher }));

    await waitFor(() => expect(result.current.status).toBe("unavailable"));
    expect(result.current.snapshot).toBeNull();
  });

  it("does not request weather while disabled", async () => {
    const fetcher = vi.fn<typeof fetch>();

    const { result } = renderHook(() => useWeather({ enabled: false, fetcher }));

    expect(result.current.status).toBe("idle");
    expect(fetcher).not.toHaveBeenCalled();
  });

  it("retains the latest weather and performs no work while visuals are paused", async () => {
    localStorage.setItem(
      WEATHER_CACHE_KEY,
      JSON.stringify({
        fetchedAt: Date.now() - 60_000,
        temperatureC: 22,
        condition: "晴",
        city: "Test",
      }),
    );
    const fetcher = vi.fn<typeof fetch>();
    const { result, rerender } = renderHook(
      ({ paused }) => useWeather({ enabled: true, paused, fetcher }),
      { initialProps: { paused: false } },
    );

    await waitFor(() => expect(result.current.status).toBe("ready"));
    rerender({ paused: true });
    localStorage.clear();

    expect(result.current.status).toBe("ready");
    expect(result.current.snapshot?.temperatureC).toBe(22);
    expect(fetcher).not.toHaveBeenCalled();
  });

  it("does not start a weather request when mounted during a native drag", () => {
    const fetcher = vi.fn<typeof fetch>();

    const { result } = renderHook(() =>
      useWeather({ enabled: true, paused: true, fetcher }),
    );

    expect(result.current.status).toBe("loading");
    expect(fetcher).not.toHaveBeenCalled();
  });

  it("aborts an in-flight request after five seconds", async () => {
    vi.useFakeTimers();
    const fetcher = vi.fn<typeof fetch>((_, init) => new Promise((_, reject) => {
      init?.signal?.addEventListener("abort", () => reject(new Error("aborted")));
    }));

    const { result } = renderHook(() => useWeather({ enabled: true, fetcher }));
    await act(async () => {
      await vi.advanceTimersByTimeAsync(5_100);
    });

    expect(result.current.status).toBe("unavailable");
    vi.useRealTimers();
  });
});
