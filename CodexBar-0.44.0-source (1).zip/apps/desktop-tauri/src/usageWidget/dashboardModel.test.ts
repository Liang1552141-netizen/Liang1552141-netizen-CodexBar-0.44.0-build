import { describe, expect, it } from "vitest";
import type { CodexWidgetModel } from "./model";
import { buildDashboardView } from "./dashboardModel";

const base: CodexWidgetModel = {
  status: "fresh",
  tone: "ok",
  planName: "ChatGPT Plus",
  updatedAt: "2026-07-28T02:00:00Z",
  session: {
    usedPercent: 21,
    remainingPercent: 79,
    resetsAt: null,
    resetDescription: "4小时",
  },
  weekly: {
    usedPercent: 10,
    remainingPercent: 90,
    resetsAt: "2026-08-03T09:50:00Z",
    resetDescription: "6天20小时",
  },
  pace: {
    stage: "on_track",
    deltaPercent: 0,
    willLastToReset: true,
    etaSeconds: 64_800,
    expectedUsedPercent: 10,
    actualUsedPercent: 10,
  },
  error: null,
};

describe("buildDashboardView", () => {
  it("uses the weekly quota as the primary eclipse ring", () => {
    const view = buildDashboardView(base);

    expect(view.primaryQuota).toEqual(base.weekly);
    expect(view.primaryLabel).toBe("本周额度");
  });

  it("falls back to the session quota when weekly quota is unavailable", () => {
    const view = buildDashboardView({ ...base, weekly: null });

    expect(view.primaryQuota).toEqual(base.session);
    expect(view.primaryLabel).toBe("本次额度");
  });

  it("never fabricates a zero quota when the provider exposes no quota", () => {
    const view = buildDashboardView({
      ...base,
      status: "empty",
      tone: "offline",
      session: null,
      weekly: null,
      pace: null,
    });

    expect(view.primaryQuota).toBeNull();
    expect(view.remainingPercent).toBeNull();
    expect(view.usedPercent).toBeNull();
  });

  it("keeps model and plan copy stable for the dashboard", () => {
    const view = buildDashboardView(base);

    expect(view.modelName).toBe("Codex");
    expect(view.planName).toBe("ChatGPT Plus");
    expect(view.connected).toBe(true);
    expect(view.estimatedHours).toBe(18);
  });
});
