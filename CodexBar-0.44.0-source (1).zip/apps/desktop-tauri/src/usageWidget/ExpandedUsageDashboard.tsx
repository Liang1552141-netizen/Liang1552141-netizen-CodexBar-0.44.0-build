import type { CSSProperties } from "react";
import { ProviderIcon } from "../components/providers/ProviderIcon";
import { useFormattedResetTime } from "../hooks/useFormattedResetTime";
import { useLocale } from "../i18n/LocaleProvider";
import type { LocaleKey } from "../i18n/keys";
import { localeForLanguage } from "../i18n/languageLocale";
import type { Language, PaceSnapshot, WidgetTheme } from "../types/bridge";
import { CrimsonAssistant } from "./CrimsonAssistant";
import { buildDashboardView } from "./dashboardModel";
import type { CodexWidgetModel } from "./model";
import { useWeather } from "./useWeather";
import "./usageWidget.css";
import "./CrimsonDashboard.css";

export type ExpandedUsageDashboardProps = {
  model: CodexWidgetModel;
  pinned: boolean;
  theme?: WidgetTheme;
  visualsPaused?: boolean;
  onPinChange: (pinned: boolean) => void;
  onRefresh: () => void;
  onCollapse: () => void;
  onOpenSettings: () => void;
};

const PACE_STAGE_KEYS: Record<PaceSnapshot["stage"], LocaleKey> = {
  on_track: "DetailPaceOnTrack",
  slightly_ahead: "DetailPaceSlightlyAhead",
  ahead: "DetailPaceAhead",
  far_ahead: "DetailPaceFarAhead",
  slightly_behind: "DetailPaceSlightlyBehind",
  behind: "DetailPaceBehind",
  far_behind: "DetailPaceFarBehind",
};

function statusText(model: CodexWidgetModel, t: ReturnType<typeof useLocale>["t"]) {
  switch (model.status) {
    case "stale":
      return t("WidgetRefreshFailed");
    case "signedOut":
      return t("WidgetLoginRequired");
    case "empty":
      return t("WidgetQuotaUnavailable");
    case "fresh":
      return t("WidgetSyncedJustNow");
  }
}

function percent(value: number | null): string {
  return value == null ? "--" : `${Math.round(value)}%`;
}

export function formatUpdatedAt(
  updatedAt: string | null,
  language: Language,
): string {
  if (!updatedAt) return "--";
  const date = new Date(updatedAt);
  if (Number.isNaN(date.getTime())) return updatedAt;
  return new Intl.DateTimeFormat(localeForLanguage(language), {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function ExpandedUsageDashboard({
  model,
  pinned,
  theme = "emerald",
  visualsPaused = false,
  onPinChange,
  onRefresh,
  onCollapse,
  onOpenSettings,
}: ExpandedUsageDashboardProps) {
  const { t, language } = useLocale();
  const view = buildDashboardView(model);
  const weather = useWeather({ enabled: true, paused: visualsPaused });
  const primaryReset = useFormattedResetTime(
    view.primaryQuota?.resetsAt ?? null,
    view.primaryQuota?.resetDescription ?? null,
    true,
  );
  const paceLabel = model.pace
    ? t(PACE_STAGE_KEYS[model.pace.stage])
    : t("WidgetQuotaUnavailable");
  const weatherCity =
    weather.status === "ready" ? weather.snapshot?.city ?? "本地" : "当地天气";
  const weatherValue =
    weather.status === "ready" && weather.snapshot
      ? `${Math.round(weather.snapshot.temperatureC)}°C · ${weather.snapshot.condition}`
      : weather.status === "loading"
        ? "同步中"
        : "暂不可用";
  const quotaStyle = {
    "--quota-progress": view.remainingPercent ?? 0,
  } as CSSProperties;
  const paceStyle = {
    "--pace-actual": model.pace?.actualUsedPercent ?? 0,
    "--pace-expected": model.pace?.expectedUsedPercent ?? 0,
  } as CSSProperties;

  return (
    <section
      className={`usage-dashboard crimson-dashboard usage-dashboard--${model.tone}`}
      data-widget-theme={theme}
      data-visuals-paused={visualsPaused}
    >
      <header className="crimson-dashboard__header">
        <div className="crimson-dashboard__brand">
          <ProviderIcon
            providerId="codex"
            size={38}
            className="crimson-dashboard__brand-icon"
          />
          <div>
            <h1>{t("WidgetTitle")}</h1>
            <p>
              <span
                className={`crimson-dashboard__status-dot crimson-dashboard__status-dot--${model.status}`}
                aria-hidden="true"
              />
              {statusText(model, t)}
            </p>
          </div>
        </div>
        <div className="crimson-dashboard__actions">
          <button type="button" aria-label={t("ActionRefresh")} onClick={onRefresh}>
            刷新
          </button>
          <button
            type="button"
            className={pinned ? "is-active" : undefined}
            aria-label={pinned ? t("WidgetUnpin") : t("WidgetPin")}
            aria-pressed={pinned}
            onClick={() => onPinChange(!pinned)}
          >
            {pinned ? "已固定" : "固定"}
          </button>
          <button type="button" aria-label={t("ActionClose")} onClick={onCollapse}>
            收起
          </button>
        </div>
      </header>

      <main className="crimson-dashboard__main">
        <section className="crimson-dashboard__hero">
          <div className="crimson-dashboard__quota-zone">
            <div
              className="crimson-dashboard__orbit"
              style={quotaStyle}
              role={view.remainingPercent == null ? undefined : "progressbar"}
              aria-label={`${view.primaryLabel} ${t("WidgetRemaining")}`}
              aria-valuemin={view.remainingPercent == null ? undefined : 0}
              aria-valuemax={view.remainingPercent == null ? undefined : 100}
              aria-valuenow={
                view.remainingPercent == null
                  ? undefined
                  : Math.round(view.remainingPercent)
              }
            >
              <div className="crimson-dashboard__orbit-core">
                <span>{view.primaryLabel}</span>
                {view.remainingPercent == null ? (
                  <strong className="crimson-dashboard__quota-unavailable">
                    {t("WidgetQuotaUnavailable")}
                  </strong>
                ) : (
                  <>
                    <strong>{percent(view.remainingPercent)}</strong>
                    <small>{t("WidgetRemaining")}</small>
                  </>
                )}
              </div>
            </div>
            <div className="crimson-dashboard__quota-caption">
              <span>{`已使用 ${percent(view.usedPercent)}`}</span>
              <span>{primaryReset ?? t("WidgetQuotaUnavailable")}</span>
            </div>
          </div>

          <div className="crimson-dashboard__detail-zone">
            <div className="crimson-dashboard__assistant-slot">
              <CrimsonAssistant paused={visualsPaused} />
            </div>
            <dl className="crimson-dashboard__details">
              <div>
                <dt>当前模型</dt>
                <dd>{view.modelName}</dd>
              </div>
              <div>
                <dt>当前套餐</dt>
                <dd>{view.planName}</dd>
              </div>
              <div>
                <dt>重置时间</dt>
                <dd>{primaryReset ?? t("WidgetQuotaUnavailable")}</dd>
              </div>
              <div>
                <dt>{weatherCity}</dt>
                <dd>{weatherValue}</dd>
              </div>
            </dl>
          </div>
        </section>

        <section className="crimson-dashboard__pace-panel">
          <div className="crimson-dashboard__pace-heading">
            <div>
              <span>本周节奏</span>
              <strong>{paceLabel}</strong>
            </div>
            {model.pace && (
              <b>{`${Math.round(Math.abs(model.pace.deltaPercent))}%`}</b>
            )}
          </div>
          {model.pace ? (
            <div
              className="crimson-dashboard__pace-track"
              style={paceStyle}
              role="progressbar"
              aria-label="本周已使用额度"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Math.round(model.pace.actualUsedPercent)}
            >
              <span className="crimson-dashboard__pace-fill" />
              <span className="crimson-dashboard__pace-marker" />
            </div>
          ) : (
            <p className="crimson-dashboard__pace-empty">
              {t("WidgetQuotaUnavailable")}
            </p>
          )}
          <div className="crimson-dashboard__metrics">
            <div>
              <span>本次剩余</span>
              <strong>{percent(model.session?.remainingPercent ?? null)}</strong>
            </div>
            <div>
              <span>当前已用</span>
              <strong>{percent(view.usedPercent)}</strong>
            </div>
            <div>
              <span>预计可用</span>
              <strong>
                {view.estimatedHours == null ? "评估中" : `${view.estimatedHours}小时`}
              </strong>
            </div>
          </div>
        </section>
      </main>

      <footer className="crimson-dashboard__footer">
        <div>
          <span>本地数据</span>
          <time dateTime={model.updatedAt ?? undefined}>
            {formatUpdatedAt(model.updatedAt, language)}
          </time>
        </div>
        <button type="button" onClick={onOpenSettings}>
          {t("WidgetOpenSettings")}
        </button>
      </footer>
    </section>
  );
}
