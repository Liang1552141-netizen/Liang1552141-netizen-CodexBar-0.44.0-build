import type { CSSProperties } from "react";
import { useFormattedResetTime } from "../hooks/useFormattedResetTime";
import { useLocale } from "../i18n/LocaleProvider";
import type { WidgetTheme } from "../types/bridge";
import type { CodexWidgetModel } from "./model";
import "./usageWidget.css";

type MiniUsageCardProps = {
  model: CodexWidgetModel;
  onExpand: () => void;
  theme?: WidgetTheme;
};

function modelStatus(model: CodexWidgetModel, t: ReturnType<typeof useLocale>["t"]) {
  switch (model.status) {
    case "stale":
      return t("WidgetRefreshFailed");
    case "signedOut":
      return t("WidgetLoginRequired");
    case "empty":
      return t("WidgetQuotaUnavailable");
    case "fresh":
      return t("WidgetSyncedJustNow");
  }
}

export function MiniUsageCard({
  model,
  onExpand,
  theme = "emerald",
}: MiniUsageCardProps) {
  const { t } = useLocale();
  const quota = model.weekly ?? model.session;
  const remaining = quota?.remainingPercent ?? null;
  const percent = remaining == null ? "--" : `${Math.round(remaining)}%`;
  const quotaLabel = model.weekly ? t("ProviderWeekly") : t("ProviderSession");
  const resetDescription = useFormattedResetTime(
    quota?.resetsAt ?? null,
    quota?.resetDescription ?? null,
    true,
  );
  const detail = resetDescription ?? modelStatus(model, t);

  return (
    <section
      className={`usage-widget usage-widget--${model.tone}`}
      data-testid="widget-drag-region"
      data-widget-theme={theme}
    >
      <div
        className="usage-widget__ring"
        aria-label={`${t("WidgetRemaining")} ${percent}`}
        style={{ "--usage-progress": remaining ?? 0 } as CSSProperties}
      >
        <strong>{percent}</strong>
        <span>{t("WidgetRemaining")}</span>
      </div>

      <div className="usage-widget__summary">
        <div className="usage-widget__summary-line">
          <strong>{quotaLabel}</strong>
          <span className="usage-widget__status-dot" aria-hidden />
          {model.status !== "empty" && (
            <span>{modelStatus(model, t)}</span>
          )}
        </div>
        <span className="usage-widget__reset">{detail}</span>
      </div>

      <button
        className="usage-widget__expand"
        type="button"
        aria-label={t("TrayPopOutDashboard")}
        onClick={onExpand}
      >
        <span aria-hidden>›</span>
      </button>
    </section>
  );
}
