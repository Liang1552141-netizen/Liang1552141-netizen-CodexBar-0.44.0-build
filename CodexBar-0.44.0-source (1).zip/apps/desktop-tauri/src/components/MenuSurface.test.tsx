import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const tauriMocks = vi.hoisted(() => ({
  getLocaleStrings: vi.fn(),
  setUiLanguage: vi.fn(),
}));

const eventMocks = vi.hoisted(() => ({
  listen: vi.fn(),
}));

vi.mock("../lib/tauri", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../lib/tauri")>()),
  ...tauriMocks,
}));
vi.mock("@tauri-apps/api/event", () => eventMocks);

import { LocaleProvider } from "../i18n/LocaleProvider";
import { buildBundle } from "../test/localeHarness";
import MenuSurface, { MenuSummary } from "./MenuSurface";

function renderSummary(total: number) {
  return render(
    <LocaleProvider>
      <MenuSummary
        total={total}
        errorCount={0}
        isRefreshing={false}
        lastRefresh={null}
      />
    </LocaleProvider>,
  );
}

describe("MenuSummary", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    tauriMocks.getLocaleStrings.mockResolvedValue(
      buildBundle({ SummaryProvidersLabel: "providers" }),
    );
    eventMocks.listen.mockResolvedValue(() => {});
  });

  it("uses a singular provider label for one provider", async () => {
    renderSummary(1);

    expect(await screen.findByText("1 provider")).toBeInTheDocument();
  });

  it("keeps the plural provider label for multiple providers", async () => {
    renderSummary(2);

    expect(await screen.findByText("2 providers")).toBeInTheDocument();
  });
});

describe("MenuSurface tray commands and diagnostics", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    tauriMocks.getLocaleStrings.mockResolvedValue(
      buildBundle({ PanelMenu: "菜单" }, "chinese"),
    );
    eventMocks.listen.mockResolvedValue(() => {});
  });

  it("shows the five Chinese tray commands as visible menu rows", async () => {
    render(
      <LocaleProvider>
        <MenuSurface
          variant="tray"
          onRefresh={vi.fn()}
          isRefreshing={false}
          actions={[]}
          footerRows={[
            { icon: "◫", label: "显示/隐藏", onClick: vi.fn() },
            { icon: "↻", label: "立即刷新", onClick: vi.fn() },
            { icon: "◆", label: "固定窗口", onClick: vi.fn() },
            { icon: "⚙", label: "设置", onClick: vi.fn() },
            { icon: "⌧", label: "退出", onClick: vi.fn() },
          ]}
        >
          <div>用量</div>
        </MenuSurface>
      </LocaleProvider>,
    );

    expect(await screen.findByText("显示/隐藏")).toBeVisible();
    expect(screen.getByText("立即刷新")).toBeVisible();
    expect(screen.getByText("固定窗口")).toBeVisible();
    expect(screen.getByText("设置")).toBeVisible();
    expect(screen.getByText("退出")).toBeVisible();
  });

  it("renders a recovery diagnostic without replacing cached content", async () => {
    render(
      <LocaleProvider>
        <MenuSurface
          variant="tray"
          onRefresh={vi.fn()}
          isRefreshing={false}
          actions={[]}
          diagnostic={
            <div role="status">
              <p>更新失败</p>
              <button type="button">重试</button>
            </div>
          }
        >
          <div>上次额度</div>
        </MenuSurface>
      </LocaleProvider>,
    );

    expect(await screen.findByText("上次额度")).toBeVisible();
    expect(screen.getByRole("status")).toHaveTextContent("更新失败");
    expect(screen.getByRole("button", { name: "重试" })).toBeVisible();
  });
});
