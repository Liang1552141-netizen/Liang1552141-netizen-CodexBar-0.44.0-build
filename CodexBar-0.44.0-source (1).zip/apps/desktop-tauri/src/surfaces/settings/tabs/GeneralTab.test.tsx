import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

vi.mock("../../../hooks/useLocale", () => ({
  useLocale: () => ({
    t: (key: string) =>
      ({
        SectionNotifications: "额度提醒",
        ShowNotifications: "启用额度提醒",
        HighUsageAlert: "剩余 20% 时提醒",
        CriticalUsageAlert: "剩余 10% 时提醒",
      })[key] ?? key,
  }),
}));

// Mock Tauri invoke for get_available_languages
vi.mock("@tauri-apps/api/core", () => ({
  invoke: vi.fn().mockResolvedValue([
    { value: "english", display: "English" },
    { value: "chinese", display: "中文" },
    { value: "chinesetraditional", display: "繁體中文" },
    { value: "japanese", display: "日本語" },
    { value: "korean", display: "한국어" },
    { value: "spanish", display: "Español" },
  ]),
}));

import GeneralTab, { normalizeThresholdTier } from "./GeneralTab";
import type { SettingsSnapshot } from "../../../types/bridge";

const settings: SettingsSnapshot = {
  enabledProviders: [],
  refreshIntervalSecs: 300,
  refreshAllProvidersOnMenuOpen: false,
  startAtLogin: false,
  startMinimized: false,
  showNotifications: true,
  soundEnabled: true,
  soundVolume: 100,
  highUsageThreshold: 70,
  criticalUsageThreshold: 90,
  predictivePaceWarningEnabled: false,
  trayIconMode: "single",
  switcherShowsIcons: true,
  menuBarShowsHighestUsage: true,
  menuBarShowsPercent: true,
  showAsUsed: false,
  showAllTokenAccountsInMenu: true,
  enableAnimations: true,
  resetTimeRelative: true,
  menuBarDisplayMode: "compact",
  windowScalePercent: 125,
  trayScalePercent: 100,
  powertoysStatusPipeEnabled: false,
  hidePersonalInfo: false,
  autoDownloadUpdates: false,
  installUpdatesOnQuit: false,
  globalShortcut: "",
  codexCustomSessionsDirs: [],
  updateChannel: "stable",
  uiLanguage: "english",
  widgetTheme: "emerald",
  widgetPinned: false,
  widgetSmartTopmost: true,
  widgetHideFullscreen: true,
  theme: "dark",
  claudeAvoidKeychainPrompts: true,
  codexSparkUsageVisible: true,
  disableKeychainAccess: false,
  providerMetrics: {},
  floatBarEnabled: false,
  floatBarOpacity: 0.9,
  floatBarScale: 100,
  floatBarOrientation: "horizontal",
  floatBarStyle: "floating",
  floatBarClickThrough: false,
  floatBarProviderIds: [],
  floatBarDarkText: false,
  floatBarShowResetInline: false,
  floatBarShowCost: false,
  showResetWhenExhausted: false,
};

describe("GeneralTab language picker", () => {
  it("renders 6 language options when Traditional Chinese is wired", () => {
    render(<GeneralTab settings={settings} set={vi.fn()} saving={false} />);

    const select = screen.getByDisplayValue("English");
    expect(select).toBeInTheDocument();

    const options = select.querySelectorAll("option");
    expect(options).toHaveLength(6);
  });

  it("includes spanish as a selectable option", () => {
    render(<GeneralTab settings={settings} set={vi.fn()} saving={false} />);

    expect(
      screen.getByText("Español"),
    ).toBeInTheDocument();
  });

  it("includes korean as a selectable option", () => {
    render(<GeneralTab settings={settings} set={vi.fn()} saving={false} />);

    expect(
      screen.getByText("한국어"),
    ).toBeInTheDocument();
  });

  it("includes Traditional Chinese as a selectable option", () => {
    render(<GeneralTab settings={settings} set={vi.fn()} saving={false} />);

    expect(screen.getByText("繁體中文")).toBeInTheDocument();
  });

  it("updates the predictive pace warning preference", () => {
    const set = vi.fn();
    render(
      <GeneralTab
        mode="notifications"
        settings={settings}
        set={set}
        saving={false}
      />,
    );

    fireEvent.click(screen.getByRole("checkbox", { name: "PredictivePaceWarnings" }));

    expect(set).toHaveBeenCalledWith({ predictivePaceWarningEnabled: true });
  });

  it("shows Chinese remaining-quota alert labels and sends threshold payloads", () => {
    const set = vi.fn();
    render(
      <GeneralTab mode="notifications" settings={{ ...settings, highUsageThreshold: 80 }} set={set} saving={false} />,
    );

    expect(screen.getByText("额度提醒")).toBeVisible();
    expect(screen.getByRole("checkbox", { name: "启用额度提醒" })).toBeChecked();
    expect(screen.getByRole("checkbox", { name: "剩余 20% 时提醒" })).toBeChecked();
    expect(screen.getByRole("checkbox", { name: "剩余 10% 时提醒" })).toBeChecked();

    fireEvent.click(screen.getByRole("checkbox", { name: "剩余 20% 时提醒" }));
    fireEvent.click(screen.getByRole("checkbox", { name: "剩余 10% 时提醒" }));
    expect(set).toHaveBeenCalledWith({
      highUsageThreshold: 100,
      providerUsageThresholds: {},
    });
    expect(set).toHaveBeenCalledWith({
      criticalUsageThreshold: 100,
      providerUsageThresholds: {},
    });
  });

  it("does not present a legacy 70 percent threshold as the fixed 80 percent tier", () => {
    const set = vi.fn();
    render(
      <GeneralTab mode="notifications" settings={settings} set={set} saving={false} />,
    );
    expect(screen.getByRole("checkbox", { name: "剩余 20% 时提醒" })).not.toBeChecked();
  });

  it("hides numeric provider and window threshold overrides", () => {
    render(
      <GeneralTab
        mode="notifications"
        settings={settings}
        set={vi.fn()}
        saving={false}
      />,
    );
    expect(
      screen.queryByRole("spinbutton", {
        name: "ProviderNameCodex · ProviderSession 剩余 20% 时提醒",
      }),
    ).not.toBeInTheDocument();
  });

  it("clears high overrides when disabling the fixed high tier", () => {
    const withOverrides: SettingsSnapshot = {
      ...settings,
      highUsageThreshold: 80,
      providerUsageThresholds: {
        codex: { high: 80, critical: 95 },
        "codex:weekly": { high: 75 },
        claude: { critical: 92 },
      },
    };
    const payload = normalizeThresholdTier(withOverrides, "high", false);

    expect(payload).toEqual({
      highUsageThreshold: 100,
      providerUsageThresholds: {
        codex: { critical: 95 },
        claude: { critical: 92 },
      },
    });

    const normalized = { ...withOverrides, ...payload };
    expect(normalized.highUsageThreshold).toBe(100);
    expect(
      Object.values(normalized.providerUsageThresholds ?? {}).every(
        (override) => override.high === undefined,
      ),
    ).toBe(true);
  });

  it("clears matching high overrides from the toggle-off payload", () => {
    const set = vi.fn();
    render(
      <GeneralTab
        mode="notifications"
        settings={{
          ...settings,
          highUsageThreshold: 80,
          providerUsageThresholds: {
            codex: { high: 80, critical: 95 },
            "codex:weekly": { high: 80 },
          },
        }}
        set={set}
        saving={false}
      />,
    );

    const toggle = screen.getByRole("checkbox", { name: "剩余 20% 时提醒" });
    expect(toggle).toBeChecked();
    fireEvent.click(toggle);
    expect(set).toHaveBeenCalledWith({
      highUsageThreshold: 100,
      providerUsageThresholds: { codex: { critical: 95 } },
    });
  });

  it("clears only critical overrides when enabling the fixed critical tier", () => {
    const payload = normalizeThresholdTier(
      {
        ...settings,
        providerUsageThresholds: {
          codex: { high: 75, critical: 95 },
          "claude:weekly": { critical: 92 },
        },
      },
      "critical",
      true,
    );

    expect(payload).toEqual({
      criticalUsageThreshold: 90,
      providerUsageThresholds: { codex: { high: 75 } },
    });
  });

  it("treats a matching global tier with an override conflict as switched off", () => {
    render(
      <GeneralTab
        mode="notifications"
        settings={{
          ...settings,
          highUsageThreshold: 80,
          providerUsageThresholds: { "codex:session": { high: 75 } },
        }}
        set={vi.fn()}
        saving={false}
      />,
    );
    expect(screen.getByRole("checkbox", { name: "剩余 20% 时提醒" })).not.toBeChecked();
  });
});
