import type { Language } from "../types/bridge";

const LANGUAGE_LOCALES: Record<Language, string> = {
  english: "en-US",
  chinese: "zh-CN",
  chinesetraditional: "zh-TW",
  japanese: "ja-JP",
  korean: "ko-KR",
  spanish: "es-MX",
};

/** BCP 47 locale used by the Rust Fluent bundle for a persisted UI language. */
export function localeForLanguage(language: Language): string {
  return LANGUAGE_LOCALES[language];
}
