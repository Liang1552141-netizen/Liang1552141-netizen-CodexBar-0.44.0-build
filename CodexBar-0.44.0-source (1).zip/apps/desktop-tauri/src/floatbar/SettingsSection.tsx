import { useCallback, useEffect, useState } from "react";
import { Field, Select, Toggle } from "../components/FormControls";
import { useLocale } from "../hooks/useLocale";
import type {
  FloatBarOrientation,
  FloatBarStyle,
  SettingsSnapshot,
  SettingsUpdate,
  WidgetTheme,
} from "../types/bridge";

interface Props {
  settings: SettingsSnapshot;
  saving: boolean;
  set: (patch: SettingsUpdate) => void;
}

function useDraftNumber(value: number) {
  const [draft, setDraft] = useState(value);

  useEffect(() => {
    setDraft(value);
  }, [value]);

  const commit = useCallback(
    (next: number, onCommit: (value: number) => void) => {
      // Dedupe against the committed prop value, which is the persisted
      // source of truth. The parent's save is fire-and-forget, so we can't
      // observe success/failure here — comparing to `value` (rather than an
      // optimistically-advanced marker) means a failed save leaves the prop
      // unchanged and a re-commit of the same number still fires the retry.
      if (next === value) return;
      onCommit(next);
    },
    [value],
  );

  return { draft, setDraft, commit };
}

/**
 * Settings UI block for the floating capacity bar. Rendered as one row
 * in the Display tab — kept in this module so the Display tab only
 * imports a single component.
 */
export default function FloatBarSettingsSection({ settings, saving, set }: Props) {
  const { t } = useLocale();
  const opacity = useDraftNumber(settings.floatBarOpacity);
  const scale = useDraftNumber(settings.floatBarScale);
  const commitOpacity = () => {
    opacity.commit(opacity.draft, (value) => set({ floatBarOpacity: value }));
  };
  const commitScale = () => {
    scale.commit(scale.draft, (value) => set({ floatBarScale: value }));
  };

  return (
    <>
    <section className="settings-section">
      <h3 className="settings-section__title">{t("FloatBarSectionTitle")}</h3>
      <div className="settings-section__group">
        <Field
          label={t("FloatBarShowFloatingBar")}
          description={t("FloatBarShowFloatingBarHelper")}
          leading
        >
          <Toggle
            checked={settings.floatBarEnabled}
            disabled={saving}
            onChange={(v) => set({ floatBarEnabled: v })}
          />
        </Field>
        <Field
          label={t("FloatBarOrientation")}
          description={t("FloatBarOrientationHelper")}
        >
          <Select
            value={settings.floatBarOrientation}
            disabled={saving || !settings.floatBarEnabled}
            options={[
              { value: "horizontal", label: t("FloatBarOrientationHorizontal") },
              { value: "vertical", label: t("FloatBarOrientationVertical") },
            ]}
            onChange={(v) => set({ floatBarOrientation: v as FloatBarOrientation })}
          />
        </Field>
        <Field
          label={t("FloatBarStyle")}
          description={t("FloatBarStyleHelper")}
        >
          <Select
            value={settings.floatBarStyle}
            disabled={saving || !settings.floatBarEnabled}
            options={[
              { value: "floating", label: t("FloatBarStyleFloating") },
              { value: "taskbar", label: t("FloatBarStyleTaskbar") },
            ]}
            onChange={(v) => set({ floatBarStyle: v as FloatBarStyle })}
          />
        </Field>
        <Field
          label={`${t("FloatBarOpacity")} (${opacity.draft}%)`}
          description={t("FloatBarOpacityHelper")}
        >
          <input
            type="range"
            min={30}
            max={100}
            step={5}
            value={opacity.draft}
            disabled={!settings.floatBarEnabled}
            onChange={(e) => opacity.setDraft(Number(e.target.value))}
            onPointerUp={commitOpacity}
            onTouchEnd={commitOpacity}
            onBlur={commitOpacity}
            onKeyUp={commitOpacity}
            aria-label={t("FloatBarOpacityAriaLabel")}
          />
        </Field>
        <Field
          label={`${t("FloatBarSize")} (${scale.draft}%)`}
          description={t("FloatBarSizeHelper")}
        >
          <input
            type="range"
            min={75}
            max={200}
            step={5}
            value={scale.draft}
            disabled={!settings.floatBarEnabled}
            onChange={(e) => scale.setDraft(Number(e.target.value))}
            onPointerUp={commitScale}
            onTouchEnd={commitScale}
            onBlur={commitScale}
            onKeyUp={commitScale}
            aria-label={t("FloatBarSizeAriaLabel")}
          />
        </Field>
        <Field
          label={t("FloatBarShowCost")}
          description={t("FloatBarShowCostDescription")}
          leading
        >
          <Toggle
            checked={settings.floatBarShowCost}
            disabled={saving || !settings.floatBarEnabled}
            onChange={(v) => set({ floatBarShowCost: v })}
          />
        </Field>
        <Field
          label={t("FloatBarShowResetInline")}
          description={t("FloatBarShowResetInlineHelper")}
          leading
        >
          <Toggle
            checked={settings.floatBarShowResetInline}
            disabled={saving || !settings.floatBarEnabled}
            onChange={(v) => set({ floatBarShowResetInline: v })}
          />
        </Field>
        <Field
          label={t("FloatBarInvertColors")}
          description={t("FloatBarInvertColorsHelper")}
          leading
        >
          <Toggle
            checked={settings.floatBarDarkText}
            disabled={saving || !settings.floatBarEnabled}
            onChange={(v) => set({ floatBarDarkText: v })}
          />
        </Field>
        <Field
          label={t("FloatBarClickThrough")}
          description={t("FloatBarClickThroughHelper")}
          leading
        >
          <Toggle
            checked={settings.floatBarClickThrough}
            disabled={saving || !settings.floatBarEnabled}
            onChange={(v) => set({ floatBarClickThrough: v })}
          />
        </Field>
      </div>
    </section>
    <section className="settings-section">
      <h3 className="settings-section__title">{t("WidgetSettingsTitle")}</h3>
      <div className="settings-section__group">
        <Field
          label={t("WidgetTheme")}
          description={t("WidgetThemeHelper")}
        >
          <Select
            value={settings.widgetTheme}
            disabled={saving}
            options={[
              { value: "emerald", label: t("WidgetThemeEmerald") },
              { value: "deepBlue", label: t("WidgetThemeDeepBlue") },
              { value: "system", label: t("WidgetThemeSystem") },
            ]}
            onChange={(v) => set({ widgetTheme: v as WidgetTheme })}
          />
        </Field>
        <Field
          label={t("WidgetPinned")}
          description={t("WidgetPinnedHelper")}
          leading
        >
          <Toggle
            checked={settings.widgetPinned}
            ariaLabel={t("WidgetPinned")}
            disabled={saving}
            onChange={(v) => set({ widgetPinned: v })}
          />
        </Field>
        <Field
          label={t("WidgetSmartTopmost")}
          description={t("WidgetSmartTopmostHelper")}
          leading
        >
          <Toggle
            checked={settings.widgetSmartTopmost}
            ariaLabel={t("WidgetSmartTopmost")}
            disabled={saving}
            onChange={(v) => set({ widgetSmartTopmost: v })}
          />
        </Field>
        <Field
          label={t("WidgetHideFullscreen")}
          description={t("WidgetHideFullscreenHelper")}
          leading
        >
          <Toggle
            checked={settings.widgetHideFullscreen}
            ariaLabel={t("WidgetHideFullscreen")}
            disabled={saving}
            onChange={(v) => set({ widgetHideFullscreen: v })}
          />
        </Field>
      </div>
    </section>
    </>
  );
}
