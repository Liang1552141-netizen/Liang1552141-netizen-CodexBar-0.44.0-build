import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type { SettingsSnapshot } from "../types/bridge";
import FloatBarSettingsSection from "./SettingsSection";

vi.mock("../hooks/useLocale", () => ({
  useLocale: () => ({ t: (key: string) => key }),
}));

const settings = {
  floatBarEnabled: true,
  floatBarOpacity: 90,
  floatBarScale: 100,
  floatBarOrientation: "horizontal",
  floatBarStyle: "floating",
  floatBarShowCost: false,
  floatBarShowResetInline: false,
  floatBarDarkText: false,
  floatBarClickThrough: false,
  widgetTheme: "emerald",
  widgetPinned: false,
  widgetSmartTopmost: true,
  widgetHideFullscreen: true,
} as unknown as SettingsSnapshot;

describe("FloatBar settings", () => {
  it("renders one cost toggle", () => {
    render(
      <FloatBarSettingsSection settings={settings} saving={false} set={vi.fn()} />,
    );

    expect(screen.getAllByText("FloatBarShowCost")).toHaveLength(1);
  });

  it("renders the widget theme and window policy controls", () => {
    render(
      <FloatBarSettingsSection settings={settings} saving={false} set={vi.fn()} />,
    );

    expect(screen.getByText("WidgetSettingsTitle")).toBeVisible();
    expect(screen.getByDisplayValue("WidgetThemeEmerald")).toBeVisible();
    expect(screen.getByRole("checkbox", { name: "WidgetPinned" })).not.toBeChecked();
    expect(screen.getByRole("checkbox", { name: "WidgetSmartTopmost" })).toBeChecked();
    expect(screen.getByRole("checkbox", { name: "WidgetHideFullscreen" })).toBeChecked();
  });

  it("sends the widget settings update payloads", () => {
    const set = vi.fn();
    render(
      <FloatBarSettingsSection settings={settings} saving={false} set={set} />,
    );

    fireEvent.change(screen.getByDisplayValue("WidgetThemeEmerald"), {
      target: { value: "deepBlue" },
    });
    fireEvent.click(screen.getByRole("checkbox", { name: "WidgetPinned" }));
    fireEvent.click(screen.getByRole("checkbox", { name: "WidgetSmartTopmost" }));
    fireEvent.click(screen.getByRole("checkbox", { name: "WidgetHideFullscreen" }));

    expect(set).toHaveBeenCalledWith({ widgetTheme: "deepBlue" });
    expect(set).toHaveBeenCalledWith({ widgetPinned: true });
    expect(set).toHaveBeenCalledWith({ widgetSmartTopmost: false });
    expect(set).toHaveBeenCalledWith({ widgetHideFullscreen: false });
  });
});
