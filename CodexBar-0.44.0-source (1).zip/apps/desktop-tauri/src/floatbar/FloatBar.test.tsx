import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const tauriMocks = vi.hoisted(() => ({
  getCachedProviders: vi.fn(),
  refreshProviders: vi.fn(),
  refreshProvidersIfStale: vi.fn(),
  getSettingsSnapshot: vi.fn(),
  updateSettings: vi.fn(),
  openSettingsWindow: vi.fn(),
  getLocaleStrings: vi.fn(),
  setUiLanguage: vi.fn(),
}));

const eventMocks = vi.hoisted(() => ({
  listen: vi.fn(),
}));

const startDragging = vi.hoisted(() => vi.fn().mockResolvedValue(undefined));
const windowMocks = vi.hoisted(() => ({
  getCurrentWindow: vi.fn(() => ({ startDragging })),
}));

const apiMocks = vi.hoisted(() => ({
  expandUsageWidget: vi.fn().mockResolvedValue(undefined),
  collapseUsageWidget: vi.fn().mockResolvedValue(undefined),
  setUsageWidgetPinned: vi.fn().mockResolvedValue(undefined),
  beginUsageWidgetDrag: vi.fn().mockResolvedValue(undefined),
  endUsageWidgetDrag: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("../lib/tauri", () => tauriMocks);
vi.mock("@tauri-apps/api/event", () => eventMocks);
vi.mock("@tauri-apps/api/window", () => windowMocks);
vi.mock("./api", async (importOriginal) => ({
  ...(await importOriginal<typeof import("./api")>()),
  ...apiMocks,
}));
vi.mock("../usageWidget/useWeather", () => ({
  useWeather: () => ({
    status: "ready",
    snapshot: { temperatureC: 24, condition: "晴", city: "测试城市" },
  }),
}));

import FloatBar from "./FloatBar";
import { LocaleProvider } from "../i18n/LocaleProvider";
import { buildBundle } from "../test/localeHarness";
import type {
  BootstrapState,
  ProviderUsageSnapshot,
  SettingsSnapshot,
} from "../types/bridge";

function rateWindow(usedPercent: number, resetDescription: string) {
  return {
    usedPercent,
    remainingPercent: 100 - usedPercent,
    windowMinutes: null,
    resetsAt: null,
    resetDescription,
    isExhausted: false,
    reservePercent: null,
    reserveDescription: null,
  };
}

function codexSnapshot(): ProviderUsageSnapshot {
  return {
    providerId: "codex",
    displayName: "Codex",
    primary: rateWindow(22, "4小时"),
    primaryWindowKind: "session",
    secondary: rateWindow(18, "6天1小时"),
    modelSpecific: null,
    tertiary: null,
    extraRateWindows: [],
    cost: null,
    planName: "Plus",
    accountId: null,
    accountEmail: null,
    sourceLabel: "auto",
    updatedAt: "2026-07-19T11:00:00Z",
    error: null,
    pace: null,
    accountOrganization: null,
    trayStatusLabel: null,
  };
}

function settings(overrides: Partial<SettingsSnapshot> = {}): SettingsSnapshot {
  return {
    enabledProviders: ["codex"],
    refreshIntervalSecs: 300,
    refreshAllProvidersOnMenuOpen: false,
    startAtLogin: false,
    startMinimized: false,
    showNotifications: true,
    soundEnabled: true,
    soundVolume: 100,
    highUsageThreshold: 80,
    criticalUsageThreshold: 90,
    predictivePaceWarningEnabled: false,
    trayIconMode: "single",
    switcherShowsIcons: true,
    menuBarShowsHighestUsage: false,
    menuBarShowsPercent: false,
    showAsUsed: false,
    showAllTokenAccountsInMenu: false,
    enableAnimations: true,
    resetTimeRelative: true,
    showResetWhenExhausted: false,
    menuBarDisplayMode: "detailed",
    hidePersonalInfo: false,
    updateChannel: "stable",
    autoDownloadUpdates: false,
    installUpdatesOnQuit: false,
    globalShortcut: "Ctrl+Shift+U",
    codexCustomSessionsDirs: [],
    uiLanguage: "chinese",
    widgetTheme: "emerald",
    widgetPinned: false,
    widgetSmartTopmost: true,
    widgetHideFullscreen: true,
    theme: "dark",
    windowScalePercent: 100,
    trayScalePercent: 100,
    powertoysStatusPipeEnabled: false,
    claudeAvoidKeychainPrompts: false,
    codexSparkUsageVisible: true,
    disableKeychainAccess: false,
    providerMetrics: {},
    floatBarEnabled: true,
    floatBarOpacity: 80,
    floatBarScale: 100,
    floatBarOrientation: "horizontal",
    floatBarStyle: "floating",
    floatBarClickThrough: false,
    floatBarProviderIds: [],
    floatBarDarkText: false,
    floatBarShowResetInline: false,
    floatBarShowCost: false,
    ...overrides,
  };
}

function bootstrap(overrides: Partial<SettingsSnapshot> = {}): BootstrapState {
  return {
    contractVersion: "v1",
    providers: [],
    settings: settings(overrides),
  };
}

function renderFloatBar(state = bootstrap()) {
  return render(
    <LocaleProvider>
      <FloatBar state={state} />
    </LocaleProvider>,
  );
}

describe("FloatBar usage widget composition", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    startDragging.mockResolvedValue(undefined);
    apiMocks.expandUsageWidget.mockResolvedValue(undefined);
    apiMocks.collapseUsageWidget.mockResolvedValue(undefined);
    apiMocks.setUsageWidgetPinned.mockResolvedValue(undefined);
    apiMocks.beginUsageWidgetDrag.mockResolvedValue(undefined);
    apiMocks.endUsageWidgetDrag.mockResolvedValue(undefined);
    eventMocks.listen.mockResolvedValue(() => {});
    tauriMocks.getCachedProviders.mockResolvedValue([codexSnapshot()]);
    tauriMocks.refreshProviders.mockResolvedValue(undefined);
    tauriMocks.refreshProvidersIfStale.mockResolvedValue(undefined);
    tauriMocks.getSettingsSnapshot.mockResolvedValue(settings());
    tauriMocks.updateSettings.mockResolvedValue(settings());
    tauriMocks.openSettingsWindow.mockResolvedValue(undefined);
    tauriMocks.getLocaleStrings.mockResolvedValue(
      buildBundle({
        ActionClose: "收起",
        ActionRefresh: "刷新",
        PaceBehind: "进度滞后",
        PaceOnTrack: "进度正常",
        Plan: "套餐",
        PrivacyTitle: "隐私",
        ProviderSession: "本次会话",
        ProviderWeekly: "本周",
        Status: "状态",
        TrayPopOutDashboard: "展开详细用量",
        Updated: "更新时间",
        Version: "版本",
        WidgetLoginRequired: "需要重新登录",
        WidgetOpenSettings: "打开设置",
        WidgetPin: "固定窗口",
        WidgetQuotaUnavailable: "账户暂未提供此额度",
        WidgetRefreshFailed: "数据更新失败，正在显示上次结果",
        WidgetRemaining: "剩余",
        WidgetSyncedJustNow: "刚刚同步",
        WidgetTitle: "Codex 用量",
        WidgetUnpin: "取消固定",
        WidgetUsed: "已使用",
      }),
    );
  });

  it("builds the Codex model and switches between mini and expanded surfaces", async () => {
    renderFloatBar();

    expect(await screen.findByText("82%")).toBeVisible();
    expect(screen.getByTestId("widget-drag-region")).toHaveAttribute(
      "data-widget-theme",
      "emerald",
    );
    fireEvent.click(screen.getByRole("button", { name: "展开详细用量" }));

    expect(await screen.findByText("Codex 用量")).toBeVisible();
    expect(screen.getByText("78%")).toBeVisible();
    expect(apiMocks.expandUsageWidget).toHaveBeenCalledTimes(1);

    fireEvent.click(screen.getByRole("button", { name: "收起" }));
    expect(await screen.findByRole("button", { name: "展开详细用量" })).toBeVisible();
    expect(apiMocks.collapseUsageWidget).toHaveBeenCalledTimes(1);
  });

  it("uses only the manual drag lifecycle and filters interactive controls", async () => {
    const { container } = renderFloatBar();
    const expand = await screen.findByRole("button", { name: "展开详细用量" });

    expect(container.querySelector("[data-tauri-drag-region]")).toBeNull();

    fireEvent.mouseDown(expand, { button: 0 });
    expect(apiMocks.beginUsageWidgetDrag).not.toHaveBeenCalled();
    expect(startDragging).not.toHaveBeenCalled();

    fireEvent.mouseDown(container.querySelector(".floatbar")!, { button: 0 });
    await waitFor(() => {
      expect(apiMocks.beginUsageWidgetDrag).toHaveBeenCalledTimes(1);
      expect(startDragging).toHaveBeenCalledTimes(1);
      expect(apiMocks.endUsageWidgetDrag).toHaveBeenCalledTimes(1);
    });
    expect(apiMocks.beginUsageWidgetDrag.mock.invocationCallOrder[0]).toBeLessThan(
      startDragging.mock.invocationCallOrder[0],
    );
    expect(startDragging.mock.invocationCallOrder[0]).toBeLessThan(
      apiMocks.endUsageWidgetDrag.mock.invocationCallOrder[0],
    );

    fireEvent.click(expand);
    expect(await screen.findByText("Codex 用量")).toBeVisible();
    expect(container.querySelector("[data-tauri-drag-region]")).toBeNull();
  });

  it("cleans up every successful listener when another registration rejects", async () => {
    const successfulUnlisteners = [vi.fn(), vi.fn(), vi.fn(), vi.fn()];
    let successfulIndex = 0;
    const floatBarEvents = new Set([
      "float-bar-config-changed",
      "usage-widget-expanded",
      "usage-widget-collapsed",
      "widget-visual-updates-suspended",
      "widget-visual-updates-resumed",
    ]);
    eventMocks.listen.mockImplementation((event: string) => {
      if (event === "usage-widget-collapsed") {
        return Promise.reject(new Error("listen failed"));
      }
      if (floatBarEvents.has(event)) {
        return Promise.resolve(successfulUnlisteners[successfulIndex++]);
      }
      return Promise.resolve(vi.fn());
    });

    const { unmount } = renderFloatBar();
    await screen.findByText("82%");
    await act(async () => {
      await new Promise((resolve) => window.setTimeout(resolve, 0));
    });
    unmount();
    await act(async () => {
      await Promise.resolve();
    });

    for (const unlisten of successfulUnlisteners) {
      expect(unlisten).toHaveBeenCalledTimes(1);
    }
  });

  it("persists pin controls through settings and exposes a settings button", async () => {
    renderFloatBar();
    fireEvent.click(await screen.findByRole("button", { name: "展开详细用量" }));

    fireEvent.click(await screen.findByRole("button", { name: "刷新" }));
    expect(tauriMocks.refreshProviders).toHaveBeenCalledTimes(1);

    fireEvent.click(screen.getByRole("button", { name: "固定窗口" }));
    await waitFor(() => {
      expect(apiMocks.setUsageWidgetPinned).toHaveBeenCalledWith(true);
      expect(screen.getByRole("button", { name: "取消固定" })).toHaveAttribute(
        "aria-pressed",
        "true",
      );
    });

    const settingsButton = screen.getByRole("button", { name: "打开设置" });
    expect(settingsButton.tagName).toBe("BUTTON");
    fireEvent.click(settingsButton);
    expect(tauriMocks.openSettingsWindow).toHaveBeenCalledWith("general");
  });

  it("initializes pin state from settings", async () => {
    renderFloatBar(bootstrap({ widgetPinned: true }));
    fireEvent.click(await screen.findByRole("button", { name: "展开详细用量" }));

    expect(await screen.findByRole("button", { name: "取消固定" })).toHaveAttribute(
      "aria-pressed",
      "true",
    );
  });

  it("keeps the system widget theme independent from the forced app theme", async () => {
    renderFloatBar(bootstrap({ widgetTheme: "system", theme: "dark" }));

    expect(await screen.findByTestId("widget-drag-region")).toHaveAttribute(
      "data-widget-theme",
      "system",
    );
  });

  it("preserves the existing stale-aware background refresh interval", async () => {
    vi.useFakeTimers();
    try {
      await act(async () => {
        renderFloatBar(bootstrap({ refreshIntervalSecs: 60 }));
      });

      expect(tauriMocks.refreshProvidersIfStale).toHaveBeenCalledTimes(1);
      await vi.advanceTimersByTimeAsync(60_000);
      expect(tauriMocks.refreshProvidersIfStale).toHaveBeenCalledTimes(2);
    } finally {
      vi.useRealTimers();
    }
  });

  it("reacts to detached-window setting changes without adding data fetchers", async () => {
    let configChanged: (() => void) | undefined;
    eventMocks.listen.mockImplementation((event: string, callback: () => void) => {
      if (event === "float-bar-config-changed") configChanged = callback;
      return Promise.resolve(() => {});
    });
    tauriMocks.getSettingsSnapshot.mockResolvedValue(
      settings({ widgetTheme: "deepBlue", widgetPinned: true }),
    );

    renderFloatBar();
    await screen.findByText("82%");
    act(() => configChanged?.());

    await waitFor(() => {
      expect(screen.getByTestId("widget-drag-region")).toHaveAttribute(
        "data-widget-theme",
        "deepBlue",
      );
    });

    fireEvent.click(screen.getByRole("button", { name: "展开详细用量" }));
    expect(await screen.findByRole("button", { name: "取消固定" })).toHaveAttribute(
      "aria-pressed",
      "true",
    );
    expect(tauriMocks.getSettingsSnapshot).toHaveBeenCalledTimes(1);
  });

  it("follows native collapse events after focus-loss policy decisions", async () => {
    let collapsed: (() => void) | undefined;
    eventMocks.listen.mockImplementation((event: string, callback: () => void) => {
      if (event === "usage-widget-collapsed") collapsed = callback;
      return Promise.resolve(() => {});
    });

    renderFloatBar();
    fireEvent.click(await screen.findByRole("button", { name: "展开详细用量" }));
    expect(await screen.findByText("Codex 用量")).toBeVisible();

    act(() => collapsed?.());
    expect(await screen.findByRole("button", { name: "展开详细用量" })).toBeVisible();
  });

  it("caches the newest model during native drag and commits it once on resume", async () => {
    const callbacks = new Map<string, (event: { payload: unknown }) => void>();
    eventMocks.listen.mockImplementation(
      (event: string, callback: (event: { payload: unknown }) => void) => {
        callbacks.set(event, callback);
        return Promise.resolve(() => {});
      },
    );

    renderFloatBar();
    expect(await screen.findByText("82%")).toBeVisible();
    fireEvent.click(screen.getByRole("button", { name: "展开详细用量" }));
    expect(await screen.findByTestId("crimson-assistant")).toHaveAttribute(
      "data-motion",
      "playing",
    );

    act(() => callbacks.get("widget-visual-updates-suspended")?.({ payload: null }));
    expect(screen.getByTestId("crimson-assistant")).toHaveAttribute(
      "data-motion",
      "paused",
    );
    act(() => {
      callbacks.get("provider-updated")?.({
        payload: {
          ...codexSnapshot(),
          secondary: rateWindow(60, "6天1小时"),
        },
      });
      callbacks.get("refresh-complete")?.({ payload: null });
    });

    expect(screen.getByText("82%")).toBeVisible();
    act(() => callbacks.get("widget-visual-updates-resumed")?.({ payload: null }));
    expect(await screen.findByText("40%")).toBeVisible();
    expect(screen.getByTestId("crimson-assistant")).toHaveAttribute(
      "data-motion",
      "playing",
    );
  });
});
