import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type MouseEvent,
} from "react";
import { listen } from "@tauri-apps/api/event";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { useProviders } from "../hooks/useProviders";
import {
  getSettingsSnapshot,
  openSettingsWindow,
  refreshProvidersIfStale,
} from "../lib/tauri";
import type { BootstrapState, SettingsSnapshot } from "../types/bridge";
import { ExpandedUsageDashboard } from "../usageWidget/ExpandedUsageDashboard";
import { MiniUsageCard } from "../usageWidget/MiniUsageCard";
import { buildCodexWidgetModel } from "../usageWidget/model";
import {
  beginUsageWidgetDrag,
  collapseUsageWidget,
  endUsageWidgetDrag,
  expandUsageWidget,
  FLOAT_BAR_CONFIG_CHANGED_EVENT,
  setUsageWidgetPinned,
  USAGE_WIDGET_COLLAPSED_EVENT,
  USAGE_WIDGET_EXPANDED_EVENT,
  WIDGET_VISUAL_UPDATES_RESUMED_EVENT,
  WIDGET_VISUAL_UPDATES_SUSPENDED_EVENT,
} from "./api";
import "./FloatBar.css";

/**
 * Detached Codex usage widget surface.
 *
 * Provider loading and the established stale-refresh timer stay in this
 * composition layer. The two visual components receive a pure view model and
 * only emit UI callbacks; they never invoke Tauri, network, CLI, or auth code.
 */
export default function FloatBar({ state }: { state: BootstrapState }) {
  const { providers, refresh } = useProviders({ refreshOnMount: false });
  const [settings, setSettings] = useState<SettingsSnapshot>(state.settings);
  const [expanded, setExpanded] = useState(false);
  const [pinned, setPinned] = useState(state.settings.widgetPinned);
  const [visualsPaused, setVisualsPaused] = useState(false);

  const newestModel = useMemo(
    () => buildCodexWidgetModel(providers, new Date()),
    [providers],
  );
  const [model, setModel] = useState(newestModel);
  const newestModelRef = useRef(newestModel);
  const visualUpdatesSuspendedRef = useRef(false);

  const resumeVisualUpdates = useCallback(() => {
    if (!visualUpdatesSuspendedRef.current) return;
    visualUpdatesSuspendedRef.current = false;
    setVisualsPaused(false);
    setModel(newestModelRef.current);
  }, []);

  useEffect(() => {
    newestModelRef.current = newestModel;
    if (!visualUpdatesSuspendedRef.current) {
      setModel(newestModel);
    }
  }, [newestModel]);

  const startDrag = useCallback((event: MouseEvent<HTMLElement>) => {
    if (event.button !== 0) return;
    const target = event.target;
    if (
      target instanceof Element &&
      target.closest("button, a, input, select, textarea, [role='button']")
    ) {
      return;
    }
    // Freeze only React's visual-model commits. Provider refresh and event
    // ingestion continue in the background and update newestModelRef.
    visualUpdatesSuspendedRef.current = true;
    setVisualsPaused(true);
    void (async () => {
      try {
        await beginUsageWidgetDrag();
        await getCurrentWindow().startDragging();
      } catch {
        // A failed native drag must not leave the visual surface frozen.
      } finally {
        await endUsageWidgetDrag().catch(() => {});
        // The native resumed event normally wins this race. This fallback
        // covers command/event delivery failures without a second commit.
        resumeVisualUpdates();
      }
    })();
  }, [resumeVisualUpdates]);

  useEffect(() => {
    document.body.classList.add("floatbar-window");
    return () => {
      document.body.classList.remove("floatbar-window");
    };
  }, []);

  // Keep the existing detached-window refresh cadence. The provider hook is
  // passive on mount, so this timer remains the single stale-aware driver.
  useEffect(() => {
    const intervalMs = Math.max(60_000, settings.refreshIntervalSecs * 1000);
    const tick = () => {
      void refreshProvidersIfStale().catch(() => {});
    };
    tick();
    const id = window.setInterval(tick, intervalMs);
    return () => window.clearInterval(id);
  }, [settings.refreshIntervalSecs]);

  useEffect(() => {
    const unlisteners = [
      listen(FLOAT_BAR_CONFIG_CHANGED_EVENT, () => {
        void getSettingsSnapshot()
          .then((next) => {
            setSettings(next);
            setPinned(next.widgetPinned);
          })
          .catch(() => {});
      }),
      listen(USAGE_WIDGET_EXPANDED_EVENT, () => setExpanded(true)),
      listen(USAGE_WIDGET_COLLAPSED_EVENT, () => setExpanded(false)),
      listen(WIDGET_VISUAL_UPDATES_SUSPENDED_EVENT, () => {
        visualUpdatesSuspendedRef.current = true;
        setVisualsPaused(true);
      }),
      listen(WIDGET_VISUAL_UPDATES_RESUMED_EVENT, resumeVisualUpdates),
    ];
    const noop = () => {};
    // Register rejection handlers immediately: a listener can fail long
    // before this component unmounts, and must never become unhandled.
    for (const unlistener of unlisteners) {
      void unlistener.catch(noop);
    }
    return () => {
      for (const unlistener of unlisteners) {
        void unlistener
          .then((unlisten) => unlisten())
          .catch(noop);
      }
    };
  }, [resumeVisualUpdates]);

  const updatePinned = useCallback((nextPinned: boolean) => {
    void setUsageWidgetPinned(nextPinned)
      .then(() => {
        setSettings((current) => ({
          ...current,
          widgetPinned: nextPinned,
        }));
        setPinned(nextPinned);
      })
      .catch(() => {});
  }, []);

  const expand = useCallback(() => {
    void expandUsageWidget()
      .then(() => setExpanded(true))
      .catch(() => {});
  }, []);

  const collapse = useCallback(() => {
    void collapseUsageWidget()
      .then(() => setExpanded(false))
      .catch(() => {});
  }, []);

  const openSettings = useCallback(() => {
    void openSettingsWindow("general").catch(() => {});
  }, []);

  return (
    <div className="floatbar" onMouseDown={startDrag}>
      {expanded ? (
        <ExpandedUsageDashboard
          model={model}
          pinned={pinned}
          theme={settings.widgetTheme}
          visualsPaused={visualsPaused}
          onPinChange={updatePinned}
          onRefresh={refresh}
          onCollapse={collapse}
          onOpenSettings={openSettings}
        />
      ) : (
        <MiniUsageCard
          model={model}
          theme={settings.widgetTheme}
          onExpand={expand}
        />
      )}
    </div>
  );
}
